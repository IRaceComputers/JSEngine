/****************************************************************
    Bootstrapper initiates the ASH suite when the window is ready for use.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/***********************************************************************************
* Well, we want to bootstrap the suite iff everything has been loaded ...
* ... it is not going to be _that_ great if it bootstraps prematurely.
/***********************************************************************************/
let bs = Object.create (null);

bs ["bubble"] = false;
bs ["event"]  = "DOMContentLoaded";
bs [bs.event] = Bootstrapper.bind (bs);

window.addEventListener (bs.event, bs [bs.event], bs.bubble);

/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/****
* the bootstrapping function ...
**/
function Bootstrapper () {
  "use strict";

  let that = this;
  let _    = null;
  let __   = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  let UTILS     = MakeUtilityNameSpace ();
  let ___       = UTILS.Link;
  let ____      = UTILS.MapKeyValue;
  let loader    = ___ (UTILS.CloneMap);
  let info      = ___ (UTILS.CloneMap);
  let LOADER    = ___ (MakeLoaderNameSpace, [UTILS]);
  let ID        = "begin";
  let ID_K      = "id";
  let FSTABLE   = "/sys/doc/filerecords";
  let FSTABLE_K = "fstable";
  let INIT      = __;
  let APP       = __;
  let PROCESS   = __;
  let DIRECTORY = __;

  ___ (UTILS.RemoveHandlerFor, [that.event, UTILS.WIN.SYS, that.bubble], that);
  ___ (____, [info, FSTABLE_K, FSTABLE]);
  ___ (____, [info, ID_K, ID]);
  ___ (LOADER.Create, [info], loader);

  INIT      = ___ (LOADER.Import, [LOADER.INITIATE]);
  APP       = ___ (LOADER.Import, [LOADER.APP]);
  PROCESS   = ___ (LOADER.Import, [LOADER.PROCESS]);
  DIRECTORY = APP [2];

  ___ (LOADER.Enable, [APP [1]]);
  ___ (LOADER.Enable, [APP [2]]);
  ___ (LOADER.Enable, [APP [3]]);
  ___ (LOADER.Enable, [APP [6]]);
  ___ (LOADER.Enable, [APP [8]]);
  ___ (LOADER.Enable, [APP [9]]);
  ___ (LOADER.Enable, [APP [10]]);
  ___ (LOADER.Enable, [APP [11]]);
  ___ (LOADER.Enable, [APP [12]]);
  ___ (LOADER.Enable, [APP [13]]);
  ___ (LOADER.Enable, [APP [14]]);

  ___ (INIT [DIRECTORY], _, PROCESS [DIRECTORY]);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  return __;
}