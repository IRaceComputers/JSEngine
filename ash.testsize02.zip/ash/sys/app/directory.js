/****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeNullTermNameSpace (loader) {
  "use strict";

  let nulltermspace = Object.create (null);

  function MakeNullTermName (Loader=undefined) {
    let nullterm = this;
    let _        = null;
    let __       = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let BROWSER        = __;
    let COVER          = __;
    let CURSOR         = __;
    let PAPER          = __;
    let EXIT           = __;
    let FILE           = __;
    let FILEMANAGER    = __;
    let INITIATE       = __;
    let INITDATA       = __;
    let LINE           = __;
    let LOADER         = __;
    let PAINTER        = __;
    let PROCESS        = __;
    let PressControl   = __;
    let PressEnter     = __;
    let PressShift     = __;
    let ReleaseControl = __;
    let ReleaseShift   = __;
    let SCREEN         = __;
    let ScrollLock     = __;
    let SERVER         = __;
    let UTILS          = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/ 

    function Create (info=__) {
      let that = this;

      EXIT           = info.escape;
      PressEnter     = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.ENTER, UTILS.PRESS], PAPER);
      PressControl   = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], PAPER);
      PressShift     = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.PRESS], PAPER);
      ReleaseControl = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], PAPER);
      ReleaseShift   = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.RELEASE], PAPER);
      ScrollLock     = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, UTILS.RELEASE], PAPER);

      UTILS.Link (UTILS.MapKeyValue, [that, "paper", Object.create (_)]);
      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
      UTILS.Link (PAPER.Create, [info], that.paper);
      UTILS.Link (Customize, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatnullterm   = this;
      let that           = thatnullterm.paper;
      let ENTER          = UTILS.KBD.KEY.ENTER;
      let HELP           = UTILS.KBD.KEY.F1;
      let RELOAD         = UTILS.KBD.KEY.F5;
      let oldFunction    = UTILS.Link (PAPER.GetKeyFunction, [HELP, UTILS.PRESS], that);
      let newFunction    = UTILS.Link (MakeNewHelp, [oldFunction], that);
      let commandHandler = Object.create (_);

      UTILS.Link (PAPER.SetKeyFunction, [HELP, newFunction, UTILS.PRESS], that);
      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "command", ".help."]);
      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "handler", newFunction.bind (thatnullterm)]);
      UTILS.Link (BROWSER.Create, [commandHandler], thatnullterm);

      newFunction = UTILS.WIN.SYS.location.reload.bind (UTILS.WIN.SYS);

      UTILS.Link (PAPER.SetKeyFunction, [RELOAD, newFunction, UTILS.PRESS], that);

      newFunction = RunCommand.bind (thatnullterm);

      UTILS.Link (PAPER.SetKeyFunction, [ENTER, newFunction, UTILS.PRESS], that);

      oldFunction = UTILS.Link (PAPER.GetKeyFunction, [ENTER, UTILS.PRESS], that);
      newFunction = UTILS.Link (MakeNewEnter, [oldFunction], thatnullterm);

      UTILS.Link (PAPER.SetKeyFunction, [ENTER, newFunction, UTILS.PRESS], that); 
      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "command", ".history."]);
      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "handler", History.bind (thatnullterm)]);
      UTILS.Link (BROWSER.Create, [commandHandler], thatnullterm);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=__) {
      let thatnullterm = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that    = this;
        let Command = __;
        let opline  = __;

        FILE    = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]);
        opline  = FILE [FILE.length - 1].trim (). split (UTILS.KBD.KEY.WHITESPACE);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, opline]);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, opline]);
        Command = UTILS.Link (BROWSER.Recorded, [opline[0]], thatnullterm);

        if (Command !== __) { UTILS.Link (Command, [FILE, UTILS.KBD.KEY.WHITESPACE]); }
        else { UTILS.Link (oldEnter, _, that); }

        return __;
      }

      return Enter;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Escape () {
      let that      = this;
      let date      = new Date ();
      let exitText  = new Array ();
      let finaltext = UTILS.BLANKCHAR;
      let bgcolor   = "backgroundColor";
      let bgRGBA    = UTILS.Link (PAPER.GetBgColor);
      let p         = "p";
      let lb        = "br";
      let paragraph = __;
      let linebreak = __;

      UTILS.Link (UTILS.MapKeyValue, [exitText, 0, "<br/><br/><br/><br/>"]);
      UTILS.Link (UTILS.MapKeyValue, [exitText, 1, "<p>Press [F5] or [CTRL]+[R] to start</p>"]);
      UTILS.Link (UTILS.MapKeyValue, [exitText, 2, "<br/><br/>"]);
      UTILS.Link (UTILS.MapKeyValue, [exitText, 3, "<p>Press [CTRL]+[W] to exit.</p>"]);
      UTILS.Link (UTILS.MapKeyValue, [exitText, 4, "<br/><br/>"]);
      UTILS.Link (UTILS.MapKeyValue, [exitText, 5, "<p>Ancient Creations &trade;</p>"]);
      UTILS.Link (UTILS.MapKeyValue, [exitText, 6, "<br/><br/>"]);
      UTILS.Link (UTILS.MapKeyValue, [exitText, 7, "<p>ASH &copy; 2021</p>"]);

      for (let i = 0; i < exitText.length; i ++) { finaltext = finaltext + exitText [i]; }

      UTILS.Link (UTILS.MapKeyValue, [COVER, "innerHTML", finaltext]);

      paragraph = UTILS.Link (UTILS.WIN.DOC.querySelectorAll, [p], UTILS.WIN.DOC);
      linebreak = UTILS.Link (UTILS.WIN.DOC.querySelectorAll, [lb], UTILS.WIN.DOC);

      for (let i = 0; i < paragraph.length; i ++) {
        UTILS.Link (UTILS.MapKeyValue, [paragraph [i].style, bgcolor, bgRGBA]);
      }
      for (let i = 0; i < linebreak.length; i ++) {
        UTILS.Link (UTILS.MapKeyValue, [linebreak [i].style, bgcolor, bgRGBA]);
      }

      return UTILS.Link (Destroy, _, that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function fakeEscape () { return __; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=__) {
      let thatpaper = this;

      function Help (event=__) {
        let that = this;

        UTILS.Link (Helper, [event, fakeEscape], that);
        UTILS.Link (RunCommand, _, SERVER);
        UTILS.Link (PAPER.PersistClipboardCursor);
        UTILS.Link (PAPER.PersistClipboardLine);

        return __;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function History () {
      let that             = this;
      let ArrowUp          = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.ARROWUP, UTILS.PRESS], PAPER);
      let Backspace        = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, UTILS.PRESS], PAPER);
      let End              = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], PAPER);
      let ctrlKeyDown      = UTILS.Link (PAPER.GetControlState);
      let scrollLockActive = UTILS.Link (PAPER.GetScrollLockState);
      let shiftKeyDown     = UTILS.Link (PAPER.GetShiftState);

      if (scrollLockActive) { UTILS.Link (ScrollLock, _, that.paper); }

      UTILS.Link (ReleaseControl, _, that.paper);
      UTILS.Link (ReleaseShift, _, that.paper);

      UTILS.Link (PressControl, _, that.paper);
      UTILS.Link (End, _, that.paper);
      UTILS.Link (ReleaseControl, _, that.paper);
      UTILS.Link (PAPER.PersistClipboardCursor);
      UTILS.Link (PAPER.PersistClipboardLine);

      UTILS.Link (PressEnter, _, that.paper);
      UTILS.Link (PAPER.PersistClipboardCursor);
      UTILS.Link (PAPER.PersistClipboardLine);

      for (let i = 0; i < that.history.length; i ++) {
        UTILS.Link (PressEnter, _, that.paper);
        UTILS.Link (ArrowUp, _, that.paper);
        UTILS.Link (PAPER.PersistClipboardCursor);
        UTILS.Link (PAPER.PersistClipboardLine);
      }

      UTILS.Link (PAPER.PersistFile);
      UTILS.Link (PAPER.PersistFileLine);
      UTILS.Link (PAPER.PersistFileCursor);

      FILE = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]);
      LINE = UTILS.Link (FILEMANAGER.GetFileLine);

      for (let i = 0; i < that.history.length; i ++) {
        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE + i, that.history [i]]);
      }

      UTILS.Link (FILEMANAGER.SetFile, [UTILS.WHOLE, FILE]);
      UTILS.Link (FILEMANAGER.SetFileLine, [FILE.length - 1]);
      UTILS.Link (FILEMANAGER.SetFileCursor, [0]);
      UTILS.Link (PAPER.RetrieveFile);
      UTILS.Link (PAPER.RetrieveFileLine);
      UTILS.Link (PAPER.RetrieveFileCursor);

      UTILS.Link (PressControl, _, that.paper);
      UTILS.Link (End, _, that.paper);
      UTILS.Link (ReleaseControl, _, that.paper);
      UTILS.Link (PAPER.PersistClipboardCursor);
      UTILS.Link (PAPER.PersistClipboardLine);

      UTILS.Link (PAPER.PersistViewportStart);
      UTILS.Link (PAPER.PersistViewportLength);
      UTILS.Link (PAPER.PersistViewportLineStart);
      UTILS.Link (PAPER.ReWrite, _, that.paper);

      if (ctrlKeyDown) { UTILS.Link (PressControl, _, that.paper); }
      if (shiftKeyDown) { UTILS.Link (PressSift, _, that.paper); }
      if (scrollLockActive) { UTILS.Link (ScrollLock, _, that.paper); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    /********************************************************
    * Command Recognition and Application Loader
    /*******************************************************/
    function RunCommand (pressedEnter=true) {
      let that     = this;
      let command  = 0;
      let readfile = 1;
      let identity = "id";
      let lastline = UTILS.Link (FILEMANAGER.GetFileSize) - 1;

      FILE     = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]);
      lastline = FILE [lastline].trim ();
      lastline = lastline.split (UTILS.KBD.KEY.WHITESPACE);
      lastline = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, lastline]);
      lastline = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, lastline]);
      command  = lastline [command];
      readfile = lastline [readfile];

      /**
      * Design a method that allows the source of an action to be identified 
      * through the stimulus event (keydown, keyup, etc.) and implement 
      * that design through the paper app... so we can prevent uncaught errors
      * caused by using keydown keys in a keyup event.
      */
      if (PROCESS [command] !== __) {
        UTILS.Link (UTILS.MapKeyValue, [that.history, that.history.length, INITDATA [command][identity]]);
        UTILS.Link (Destroy, _, that);
        UTILS.Link (INITIATE [command], [readfile], PROCESS [command]);
      }
      else if (pressedEnter) { UTILS.Link (PressEnter); }

      UTILS.Link (PAPER.PersistFile);
      UTILS.Link (PAPER.PersistFileLine);
      UTILS.Link (PAPER.PersistFileCursor);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;
      UTILS.Link (PAPER.Destroy, _, that.paper);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;
      let StopServer = __;

      LOADER = Loader;
      UTILS  = LOADER.UTILS;

      BROWSER     = UTILS.Link (LOADER.Import, [LOADER.BROWSER]);
      COVER       = UTILS.Link (LOADER.Import, [LOADER.COVER]);
      PAPER       = UTILS.Link (LOADER.Import, [LOADER.PAPER]);
      FILEMANAGER = UTILS.Link (LOADER.Import, [LOADER.FILEMANAGER]);
      INITDATA    = UTILS.Link (LOADER.Import, [LOADER.INITDATA]);
      INITIATE    = UTILS.Link (LOADER.Import, [LOADER.INITIATE]);
      PROCESS     = UTILS.Link (LOADER.Import, [LOADER.PROCESS]);
      SERVER      = UTILS.Link (LOADER.Import, [LOADER.SERVER]);
      StopServer  = Escape.bind (SERVER);

      UTILS.Link (UTILS.MapKeyValue, [that, "Create", Create]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Destroy", Destroy]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RunCommand", RunCommand]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Escape", StopServer]);

      return Object.create (that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    return Loader.UTILS.Link (Objectify, _, nullterm);
  }

  return loader.UTILS.Link (MakeNullTermName, [loader], nulltermspace);
}