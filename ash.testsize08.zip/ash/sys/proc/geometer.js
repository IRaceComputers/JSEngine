/****************************************************************
    Geometer inteprets mathematical structures for the crayon 
    application in the ASH suite.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeGeometerNameSpace (loader) {
  "use strict";

  let geometerspace = Object.create (null);

  function MakeGeometerName (Loader=undefined) {
    let geometer = this;
    let _        = null;
    let __       = undefined;
    let ___      = __;
    let ____     = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let ABSCISSA    = __;
    let ARC         = __;
    let BGCOLOR     = __;
    let CART        = __;
    let DATA        = __;
    let DECIMAL     = __;
    let GRID        = __;
    let GRID_CONST  = __;
    let GRID_INFO   = __;
    let GRAPH       = __;
    let GRAPHSIZE   = __;
    let LINEARANGLE = __;
    let LINEWIDTH   = __;
    let LOADER      = __;
    let ORDINATE    = __;
    let PAINTER     = __;
    let PAPER       = __;
    let STRUCTURE   = __;
    let UTILS       = __;
    let VECTOR      = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=__) {
      let that = this;

      BGCOLOR   = info.bgcolor;
      GRID_INFO = Object.create (_);
      
      if (PAPER === __) { PAPER = ___ (LOADER.Import, [LOADER.PAPER]); }

      ___ (____, [GRID_INFO, DATA [4], PAINTER]);
      ___ (____, [GRID_INFO, DATA [33], info [DATA [33]]]);
      ___ (____, [GRID_INFO, DATA [34], info [DATA [34]]]);
      ___ (____, [that, CART, Object.create (_)]);
      ___ (GRID.Create, [GRID_INFO], that [CART]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ClearBackground () {
      let that = this;

      ___ (PAPER.UnsetRequireRewrite, _, that);
      ___ (PAINTER.SetFillColorTo, [BGCOLOR]); 
      ___ (PAINTER.PaintBackGround);
      ___ (GRID.FindOrigin      , _, that [CART]);
      ___ (GRID.FindMinMaxRange , _, that [CART]);
      ___ (GRID.FindMinMaxDomain, _, that [CART]);

       return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DrawGrid (definition=__) {
      let that            = this;
      let skew            = Object.create (_);
      let COLOR           = 2;
      let LINEWIDTH       = 3;
      let UNITS           = 0;
      let rebuiltgraph    = ___ (RebuildGraph, [definition, 4]);
      let coordinates     = ___ (StripCoordinates, [rebuiltgraph, 4]);
      let formerCOLOR     = ___ (PAINTER.GetStrokeColor);
      let formerLINEWIDTH = ___ (PAINTER.GetBrushSize);

      ___ (____, [GRID_INFO.unit, ABSCISSA, ___ (UTILS.ToNumber, [DECIMAL, coordinates [UNITS][0]])]);
      ___ (____, [GRID_INFO.unit, ORDINATE, ___ (UTILS.ToNumber, [DECIMAL, coordinates [UNITS][1]])]);

      LINEWIDTH = ___ (UTILS.ToNumber, [DECIMAL, definition [LINEWIDTH]]);
      COLOR     = definition [COLOR];

      ___ (PAINTER.BeginPath);
      ___ (PAINTER.SetStrokeColorTo, [COLOR]);
      ___ (PAINTER.SetBrushSizeTo, [LINEWIDTH]);
      ___ (GRID.Create, [GRID_INFO], that [CART]);
      ___ (GRID.DrawPlane, _, that [CART]);
      ___ (PAINTER.StrokePath);
      ___ (PAINTER.ClosePath);
      ___ (PAINTER.SetStrokeColorTo, [formerCOLOR]);
      ___ (PAINTER.SetBrushSizeTo, [formerLINEWIDTH]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DrawArc (definition=__) {
      let that           = this;
      let COLOR          = 2;
      let LINEWIDTH      = 3;
      let ORIENTATION    = 4;
      let clockwise      = __;
      let circumferenceH = __;
      let circumferenceV = __;
      let oldX           = __;
      let oldY           = __;
      let point          = __;
      let formerLINECAP  = ___ (PAINTER.GetCurrentLineCap);
      let rebuiltgraph   = ___ (RebuildGraph, [definition, 5]);
      let coordinates    = ___ (StripCoordinates, [rebuiltgraph, 5]);
      let centerX        = ___ (UTILS.ToNumber, [DECIMAL, coordinates [0][0]]);
      let centerY        = ___ (UTILS.ToNumber, [DECIMAL, coordinates [0][1]]) * -1;
      let radiusH        = ___ (UTILS.ToNumber, [DECIMAL, coordinates [1][0]]);
      let radiusV        = ___ (UTILS.ToNumber, [DECIMAL, coordinates [1][1]]);
      let startRadians   = ___ (UTILS.ToNumber, [DECIMAL, coordinates [2][0]]);
      let stopRadians    = ___ (UTILS.ToNumber, [DECIMAL, coordinates [2][1]]);
      let deltaRadians   = ___ (ConvertToRadians, [1, ABSCISSA]);

      COLOR          = definition [COLOR];
      LINEWIDTH      = ___ (UTILS.ToNumber, [DECIMAL, definition [LINEWIDTH]]);
      ORIENTATION    = definition [ORIENTATION];
      point          = ___ (ScaleToOrientation, [ORIENTATION, centerX, centerY], that [CART]);
      centerX        = point.shift ();
      centerY        = point.shift ();
      point          = ___ (ScaleToUnits, [ORIENTATION, radiusH, radiusV], that [CART]);
      radiusH        = point.shift ();
      radiusV        = point.shift ();
      clockwise      = stopRadians / Math.abs (stopRadians);
      clockwise      = ___ (FindDirection, [clockwise, ORIENTATION]);
      startRadians   = ___ (ConvertToRadians, [startRadians, ORIENTATION]);
      stopRadians    = Math.abs (stopRadians);
      oldX           = (radiusH)*Math.cos (startRadians);
      oldY           = (radiusV)*Math.sin (startRadians);
      circumferenceH = centerX + oldX;// + (oldY * that [CART].skew.x);
      circumferenceV = centerY - oldY;// - (oldX * that [CART].skew.y);

      if (clockwise) { deltaRadians = -deltaRadians; }

      ___ (PAINTER.SetButtLineCap);
      ___ (PAINTER.BeginPath);
      ___ (GRID.MoveTo, [circumferenceH, circumferenceV]);

      for (let rotations = 1; rotations < stopRadians; rotations ++) {
        startRadians   = startRadians - deltaRadians;
        oldX           = (radiusH)*Math.cos (startRadians);
        oldY           = (radiusV)*Math.sin (startRadians);
        circumferenceH = centerX + oldX;// + (oldY * that [CART].skew.x);
        circumferenceV = centerY - oldY;// - (oldX * that [CART].skew.y);

        ___ (GRID.LineTo, [circumferenceH, circumferenceV]);
      }

      ___ (AddColor, [LINEWIDTH, COLOR])
      ___ (PAINTER.SetLineCap, [formerLINECAP]);

      return __;
    } 

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DrawGraph (definition=__) {
      let that          = this;
      let ID            = 1;
      let COLOR         = 2;
      let LINEWIDTH     = 3;
      let ORIENTATION   = 4;
      let connectPoints = __;
      let point         = __;
      let stopX         = __;
      let stopY         = __;
      let rebuiltgraph  = ___ (RebuildGraph, [definition, 5]);
      let coordinates   = ___ (StripCoordinates, [rebuiltgraph, 5]);
      let startX        = __;
      let startY        = __;
      let oldX          = ___ (UTILS.ToNumber, [DECIMAL, coordinates [0][0]]);
      let oldY          = ___ (UTILS.ToNumber, [DECIMAL, coordinates [0][1]]) * -1;

      COLOR       = definition [COLOR];
      LINEWIDTH   = ___ (UTILS.ToNumber, [DECIMAL, definition [LINEWIDTH]]);
      ORIENTATION = definition [ORIENTATION];

      if (LINEWIDTH < 0) {
        let pointsType      = ARC;
        let pointsGroup     = definition [ID];
        let pointsRadius    = -LINEWIDTH;
        let pointsSize      = UTILS.KBD.KEY.OPEN_PAREN + pointsRadius + UTILS.KBD.KEY.COMMA + pointsRadius + UTILS.KBD.KEY.CLOSE_PAREN;
        let pointsSlice     = UTILS.KBD.KEY.OPEN_PAREN + 0 + UTILS.KBD.KEY.COMMA + 361 + UTILS.KBD.KEY.CLOSE_PAREN;
        let endCoordinate   = coordinates.length - 1;
        let pointsStyle     = __;
        let pointDefinition = __;

        connectPoints = ___ (UTILS.ToNumber, [DECIMAL, coordinates [endCoordinate][1]]);
        pointsStyle   = coordinates [endCoordinate][0];
        LINEWIDTH     = connectPoints;

        coordinates.pop ();

        for (let o = 5; o < definition.length - 1; o ++) {
          pointDefinition = new Array ();

          ___ (pointDefinition.push, [pointsType], pointDefinition);
          ___ (pointDefinition.push, [pointsGroup], pointDefinition);
          ___ (pointDefinition.push, [COLOR], pointDefinition);
          ___ (pointDefinition.push, [pointsStyle], pointDefinition);
          ___ (pointDefinition.push, [ORIENTATION], pointDefinition);
          ___ (pointDefinition.push, [definition [o]], pointDefinition);
          ___ (pointDefinition.push, [pointsSize], pointDefinition);
          ___ (pointDefinition.push, [pointsSlice], pointDefinition);
          ___ (DrawArc, [pointDefinition], that);
        }
      }

      if ((LINEWIDTH >= 0) || (connectPoints !== __ && connectPoints >= 0)) {
        startY = oldY;// - (oldX * that [CART].skew.x);
        startX = oldX;// - (oldY * that [CART].skew.y);
        point  = ___ (ScaleToOrientation, [ORIENTATION, startX, startY], that [CART]);
        startY = point.pop ();
        startX = point.pop ();

        ___ (PAINTER.BeginPath);
        ___ (GRID.MoveTo, [startX, startY]);

        for (let i = 1; i < coordinates.length; i ++) {
          oldX  = ___ (UTILS.ToNumber, [DECIMAL, coordinates [i][0]]);
          oldY  = ___ (UTILS.ToNumber, [DECIMAL, coordinates [i][1]]) * -1;
          stopY = oldY;// - (oldX * that [CART].skew.x);
          stopX = oldX;// - (oldY * that [CART].skew.y);
          point = ___ (ScaleToOrientation, [ORIENTATION, stopX, stopY], that [CART]);
          stopY = point.pop ();
          stopX = point.pop ();

          ___ (GRID.LineTo, [stopX, stopY]);
        }

        ___ (AddColor, [LINEWIDTH, COLOR]);
      }

      return __;
    } 

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DrawVector (definition=__) {
      let that          = this;
      let COLOR         = 2;
      let LINEWIDTH     = 3;
      let ORIENTATION   = 4;
      let headH         = __;
      let headV         = __;
      let point         = __;
      let formerLINECAP = ___ (PAINTER.GetCurrentLineCap);
      let rebuiltgraph  = ___ (RebuildGraph, [definition, 5]);
      let coordinates   = ___ (StripCoordinates, [rebuiltgraph, 5]);
      let tailX         = ___ (UTILS.ToNumber, [DECIMAL, coordinates [0][0]]);
      let tailY         = ___ (UTILS.ToNumber, [DECIMAL, coordinates [0][1]]) * -1;
      let radius        = ___ (UTILS.ToNumber, [DECIMAL, coordinates [1][0]]);
      let radianAngle   = ___ (UTILS.ToNumber, [DECIMAL, coordinates [1][1]]);

      COLOR       = definition [COLOR];
      LINEWIDTH   = ___ (UTILS.ToNumber, [DECIMAL, definition [LINEWIDTH]]);
      ORIENTATION = definition [ORIENTATION];
      point       = ___ (ScaleToOrientation, [ORIENTATION, tailX, tailY], that [CART]);
      tailX       = point.shift ();
      tailY       = point.shift ();
      point       = ___ (ScaleToUnits, [ORIENTATION, radius, radius], that [CART]);
      radius      = point.shift ();
      radianAngle = ___ (ConvertToRadians, [radianAngle, ORIENTATION]);
      headH       = tailX + radius*Math.cos (radianAngle);
      headV       = tailY - radius*Math.sin (radianAngle);

      ___ (PAINTER.SetButtLineCap);
      ___ (PAINTER.BeginPath);
      ___ (GRID.MoveTo, [tailX, tailY]);
      ___ (GRID.LineTo, [headH, headV]);
      ___ (AddColor, [LINEWIDTH, COLOR])
      ___ (PAINTER.SetLineCap, [formerLINECAP]);

      return __;
    } 

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
   /********************************************************************************************************************/

    function RebuildGraph (definition=__, coordinatesStart=__) {
      let that              = this;
      let rebuiltdefinition = new Array ();
      let closeparentheses  = UTILS.KBD.KEY.CLOSE_PAREN;
      let tmpdefinition     = UTILS.BLANKCHAR;
      let coordinate        = UTILS.BLANKCHAR;
      let COORDINATESSTART  = coordinatesStart;

      for (let i = 0; i < COORDINATESSTART && i < definition.length; i ++) {
        ___ (rebuiltdefinition.push, [definition [i]], rebuiltdefinition);
      }
      for (let i = COORDINATESSTART; i < definition.length; i ++) {
        tmpdefinition = tmpdefinition + definition [i];
      }

      tmpdefinition = tmpdefinition.trim ().split (UTILS.BLANKCHAR);
      tmpdefinition = ___ (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, tmpdefinition]);
      tmpdefinition = ___ (UTILS.Filter, [UTILS.BLANKCHAR, tmpdefinition]);

      for (let i = 0; i < tmpdefinition.length; i ++) {
        coordinate = coordinate + tmpdefinition [i];

        if (tmpdefinition [i] === closeparentheses) {
          ___ (rebuiltdefinition.push, [coordinate], rebuiltdefinition);
          coordinate = UTILS.BLANKCHAR;
        }
      }

      return rebuiltdefinition;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function StripCoordinates (graph=__, startPoint=__) {
      let that             = this;
      let points           = new Array ();
      let startpoint       = startPoint;
      let endpoint         = graph.length;
      let openparentheses  = UTILS.KBD.KEY.OPEN_PAREN;
      let closeparentheses = UTILS.KBD.KEY.CLOSE_PAREN;
      let comma            = UTILS.KBD.KEY.COMMA;

      for (let i = startpoint; i < endpoint; i ++) {
        let point      = new Array ();
        let coordinate = graph [i].split (UTILS.BLANKCHAR);

        coordinate = ___ (UTILS.Filter, [openparentheses, coordinate]);
        coordinate = ___ (UTILS.Filter, [closeparentheses, coordinate]);
        coordinate = ___ (coordinate.join, [UTILS.BLANKCHAR], coordinate);
        coordinate = ___ (coordinate.split, [comma], coordinate);

        ___ (point.push, [coordinate [0]], point);
        ___ (point.push, [coordinate [1]], point);
        ___ (points.push, [point], points);
      }

      return points;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ScaleToUnits (orientation=__, stopX=__, stopY=__) {
      let that  = this;
      let point = new Array ();

      if (orientation === ABSCISSA) {
        stopX = that.unit.x * stopX;
        stopY = that.unit.y * stopY;
      }
      else if (orientation === ORDINATE) {
        let tmpStopX  = stopX;
        stopX = that.unit.x * stopY;
        stopY = that.unit.y * tmpStopX;
      }

      ___ (point.push, [stopX], point);
      ___ (point.push, [stopY], point);

      return point;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ScaleToOrientation (orientation=__, stopX=__, stopY=__) {
      let that  = this;
      let point = new Array ();

      if (orientation === ABSCISSA) {
        stopX = (that.origin.x) + (that.unit.x * stopX);
        stopY = (that.origin.y) + (that.unit.y * stopY);
      }
      else if (orientation === ORDINATE) {
        let tmpStopX  = stopX;
        stopX = (that.origin.x) - (that.unit.x * stopY);
        stopY = (that.origin.y) - (that.unit.y * tmpStopX);
      }

      ___ (point.push, [stopX], point);
      ___ (point.push, [stopY], point);

      return point;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ConvertToRadians (angle=__, orientation=__) {
      let that = this;
      if (orientation === ORDINATE) { angle = (LINEARANGLE/2) - angle; }
      return angle * (Math.PI/LINEARANGLE);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function FindDirection (direction=__, orientation=__) {
      let that      = this;
      let clockwise = true;

      if (direction < 0) { clockwise = false; }
      if (orientation === ORDINATE) { clockwise = !clockwise; }

      return clockwise;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetRotationUnits (angle=__) {
      let point = new Array ();

      //

      return point;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function AddColor (linewidth=__, color=__) {
      let that            = this;
      let formerCOLOR     = __;
      let formerLINEWIDTH = ___ (PAINTER.GetBrushSize);

      ___ (PAINTER.SetBrushSizeTo, [linewidth]);

      if (linewidth > 0) {
        formerCOLOR = ___ (PAINTER.GetStrokeColor);

        ___ (PAINTER.SetStrokeColorTo, [color]);
        ___ (PAINTER.StrokePath);
        ___ (PAINTER.SetStrokeColorTo, [formerCOLOR]);
      }
      else {
        formerCOLOR = ___ (PAINTER.GetFillColor);

        ___ (PAINTER.SetFillColorTo, [color]);
        ___ (PAINTER.FillWithColor);
        ___ (PAINTER.SetFillColorTo, [formerCOLOR]);
      }

      ___ (PAINTER.ClosePath);
      ___ (PAINTER.SetBrushSizeTo, [formerLINEWIDTH]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CleanStructures (commands=__) {
      let command       = __;
      let cleancommands = new Array ();

      for (let o = 0; o < commands.length; o ++) {
        command = commands [o].trim ().split (UTILS.KBD.KEY.WHITESPACE);
        command = ___ (UTILS.Filter, [UTILS.BLANKCHAR, command]);
        command = ___ (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, command]);
        if (STRUCTURE [command [0]] !== __) { ___ (cleancommands.push, [command], cleancommands); }
      }

      return cleancommands;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CloneStructures (file=__) {
      let that     = this;
      let commands = new Array ();

      for (let o = 0; o < file.length; o ++) { ___ (commands.push, [file [o]], commands); }

      return commands;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Line (startInterval=__, stopInterval=__, coeffs=__) {
      let that    = this;
      let padding = "10";
      let graph   = new Array ();
      let dy      = Object.create (_);
      let dx      = Object.create (_);
      let m       = Object.create (_);
      let tmp     = Object.create (_);
      let c       = Object.create (_);
      let zero    = Object.create (_);

      //calculate all the constants needed to assemble a linear function by ...
      // ... finding the vertical displacement between the given points and then ...
      ___ (DECIMAL.Create, [{"value": "0"       , "padding": padding}], zero);
      ___ (DECIMAL.Create, [{"value": "0"       , "padding": padding}], m);
      ___ (DECIMAL.Create, [{"value": coeffs [0], "padding": padding}], tmp);
      ___ (DECIMAL.Create, [{"value": coeffs [1], "padding": padding}], dy);
      dy = ___ (DECIMAL.Minus, [tmp], dy);
      // ... finding the horizontal displacement between the given points and then ...
      ___ (DECIMAL.Create, [{"value": (startInterval + ""), "padding": padding}], tmp);
      ___ (DECIMAL.Create, [{"value": (stopInterval + ""), "padding": padding}], dx);
      dx = ___ (DECIMAL.Minus, [tmp], dx);
      // ... finding the gradient (ratio of vertical displacement to horizontal displacement) and then ...
      m = ___ (DECIMAL.DividedBy, [dx], dy);
      // ... finding the y-intercept of the function
      ___ (DECIMAL.Create, [{"value": coeffs [0], "padding": padding}], c);
      tmp = ___ (DECIMAL.Times, [m], tmp);
      c   = ___ (DECIMAL.Minus, [tmp], c);

      graph.push (___ (DECIMAL.ToString, _, c));
      graph.push (___ (DECIMAL.ToString, _, m));

      graph = ___ (Linear, [startInterval, stopInterval, graph], that);
      tmp   = startInterval;
      dx    = stopInterval;

      //swap the variables if their order of magnitude is in reverse
      if (tmp > dx) {
        tmp = tmp + dx;
        dx  = tmp - dx;
        tmp = tmp - dx;
      }

      for (let x = -that [CART].domain.units; x < tmp; x ++) { ___ (____, [graph,x, __]); }
      for (let x = (dx + 1); x <= that [CART].domain.units; x ++) { ___ (____, [graph, x, __]); }

      return graph;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetStructure (type=__) {
      let that      = this;
      let structure = __;

      switch (type) {
        case ARC       : structure = DrawArc; break;
        case GRID_CONST: structure = DrawGrid; break;
        case GRAPH     : structure = DrawGraph; break;
        case VECTOR    : structure = DrawVector; break;
      }

      return structure;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetBgColor (color=__) {
      let that = this;
      BGCOLOR = color;
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetBgColor () { return BGCOLOR; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify (loaderObj=__) {
      let that = this;

      LOADER = loaderObj;
      UTILS  = LOADER.UTILS;
      ___    = UTILS.Link;
      ____   = UTILS.MapKeyValue;

      DATA    = ___ (LOADER.Import, [LOADER.DATA]);
      GRID    = ___ (LOADER.Import, [LOADER.GRID]);
      PAINTER = ___ (LOADER.Import, [LOADER.PAINTER]);

      ABSCISSA    = UTILS.KBD.KEY.LOWERCASE_X;
      ARC         = DATA [23];
      CART        = DATA [35];
      GRAPH       = DATA [24];
      GRID_CONST  = DATA [25];
      LINEARANGLE = 180;
      ORDINATE    = UTILS.KBD.KEY.LOWERCASE_Y;
      STRUCTURE   = Object.create (_);
      VECTOR      = DATA [26];

      ___ (____, [that, DATA [19], Create]);
      ___ (____, [that, DATA [20], Destroy]);
      ___ (____, [that, DATA [27], GetBgColor]);
      ___ (____, [that, DATA [28], GetStructure]);
      ___ (____, [that, DATA [29], SetBgColor]);
      ___ (____, [that, DATA [30], CleanStructures]);
      ___ (____, [that, DATA [31], CloneStructures]);
      ___ (____, [that, DATA [32], ClearBackground]);
      ___ (____, [STRUCTURE, ARC, true]);
      ___ (____, [STRUCTURE, GRID_CONST, true]);
      ___ (____, [STRUCTURE, GRAPH, true]);
      ___ (____, [STRUCTURE, VECTOR, true]);

      return Object.create (that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    return Loader.UTILS.Link (Objectify, [Loader], geometer);
  }

  return loader.UTILS.Link (MakeGeometerName, [loader], geometerspace);
}
