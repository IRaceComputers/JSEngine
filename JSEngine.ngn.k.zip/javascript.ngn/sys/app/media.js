function MakeMediaNameSpace (liink, funkbrowzng) {
  "use strict";

  let mediaspace = Object.create (null);
  let Media      = undefined;

  function MakeMediaName (LiinK=undefined, FunkBrowzng=undefined) {
    let media = Object.create (null);

    let BGCOLOR            = undefined;
    let EKKOE              = undefined;
    let EXIT               = undefined;
    let FGCOLOR            = undefined;
    let FIILTER            = undefined;
    let FUNKBROWZNG        = FunkBrowzng;
    let GRAPHICSPROCESSING = undefined;
    let PAINTER            = undefined;
    let KOVER              = undefined;
    let LIINK              = LiinK;
    let SKREEN             = undefined;
    let PLAYSRC            = undefined;
    let FONT               = "15px Monospace";
  
    function Materialize (info=undefined) {
      let that = this;

      PLAYSRC            = "/files/videos.playlist";
      BGCOLOR            = info.bgcolor;
      EKKOE              = info.ekkoe;
      EXIT               = info.escape;
      FGCOLOR            = info.fgcolor;
      FIILTER            = info.fiilter;
      FONT               = info.font || FONT;
      GRAPHICSPROCESSING = info.graphicsprocessing;
      PAINTER            = info.painter;
      KOVER              = info.cover;
      SKREEN             = info.skreen;
      that.ekkoe         = Object.create (null);
      that.id            = info.id;

      LIINK (
        EKKOE.Materialize,
        [{
          "bgcolor": BGCOLOR,
          "escape" : EXIT,
          "fgcolor": FGCOLOR,
          "font"   : FONT,
          "help"   : info.help,
          "id"     : that.id,
          "skreen" : SKREEN,
          "kover"  : KOVER,
          "painter": PAINTER,
          "stakk"  : info.stakk
        }],
        that.ekkoe
      );

      LIINK (
        GRAPHICSPROCESSING.Materialize,
        [{
          "cover"       : KOVER,
          "height"      : LIINK (PAINTER.GetCanvasHeight),
          "liink"       : LIINK,
          "skipinterval": info.skipinterval,
          "volumestep"  : info.volumestep,
          "width"       : LIINK (PAINTER.GetCanvasWidth)
        }],
        that.ekkoe
      );

      LIINK (Customize, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatmedia     = this;
      let that         = thatmedia.ekkoe;
      let control      = that.Printable;
      let action       = that.Action;
      let TOGGLEVIEW   = "v";
      let PREVIOUS     = "b";
      let NEXT         = "n";
      let AUDIODOWN    = "x";
      let AUDIOUP      = "c";
      let PLAYPAUSE    = "z";
      let REWIND       = ",";
      let ADVANCE      = "."; 
      let CLEAR        = "C";
      let OPEN         = "o";
      let ENTER        = "Enter";
      let INTERNALCALL = "InternalCall";
      let oldEnter     = that.Action [ENTER];

      that.Action[ENTER] = LIINK (MakeNewEnter, [oldEnter], thatmedia);

    /**************************************************************************************************************/
    /**************************************************************************************************************/
    /**************************************************************************************************************/

      LIINK (FUNKBROWZNG.Materialize, [{"liink": LIINK}], thatmedia);

      LIINK (
        FUNKBROWZNG.Materialize,
        [{
          "kommand" : ".playlist.",
          "funktion": PlayList.bind (that)
        }],
        thatmedia
      );

      LIINK (
        FUNKBROWZNG.Materialize,
        [{
          "kommand" : ".play.",
          "funktion": PlayMixedList.bind (that)
        }],
        thatmedia
      );

      LIINK (
        FUNKBROWZNG.Materialize,
        [{
          "kommand" : ".clear.",
          "funktion": ClearUnclear.bind (that)
        }],
        thatmedia
      );

      LIINK (GRAPHICSPROCESSING.ToggleDisplay, [], that); 
      LIINK (GRAPHICSPROCESSING.ToggleDisplay, [], that);
      LIINK (GRAPHICSPROCESSING.AddHandlerFor, ["onclick", GRAPHICSPROCESSING.TogglePlay], that);
      LIINK (GRAPHICSPROCESSING.AddHandlerFor, ["ended", GRAPHICSPROCESSING.Next], that);
      LIINK (GRAPHICSPROCESSING.AddHandlerFor, ["oncontextmenu", ContextMenu], that);
      LIINK (PAINTER.AddHandlerFor, ["onclick", ContextMenu], that);

      let oldP             = control [TOGGLEVIEW];
      control [TOGGLEVIEW] = LIINK (MakeToggleDisplay, [oldP], that);

      let oldB             = control [PREVIOUS];
      control [PREVIOUS]   = LIINK (MakePrevious, [oldB], that);

      let oldN             = control [NEXT];
      control [NEXT]       = LIINK (MakeNext, [oldN], that);

      let oldM             = control [ADVANCE];
      control [ADVANCE]    = LIINK (MakeAdvance, [oldM], that);

      let oldV             = control [REWIND];
      control [REWIND]     = LIINK (MakeRewind, [oldV], that);

      let oldX             = control [AUDIODOWN];
      control [AUDIODOWN]  = LIINK (MakeDecreaseVolume, [oldX], that);

      let oldC             = control [AUDIOUP];
      control [AUDIOUP]    = LIINK (MakeIncreaseVolume, [oldC], that);

      let oldZ             = control [PLAYPAUSE];
      control [PLAYPAUSE]  = LIINK (MakeTogglePlay, [oldZ], that);

      let oldCapC          = control [CLEAR];
      control [CLEAR]      = LIINK (MakeClear, [oldCapC], that);

      that.Action [INTERNALCALL] = that.Action [ENTER];
      that.words.push (PLAYSRC);

      LIINK (that.Printable [OPEN], [{"altKey": true}], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=undefined) {
      let thatmedia = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that      = this;
        let words     = that.words;
        let opline    = undefined;
        let blankChar = "";
        let spaceChar = "\u0020";

        opline = words[words.length - 1].trim (). split (spaceChar);

        opline = LIINK (FIILTER, [blankChar, opline]);
        opline = LIINK (FIILTER, [spaceChar, opline]);

        // if last line's first word is an internal kommand then runnit, else LIINK (oldEnter, [], that);
        if (LIINK (FUNKBROWZNG.Rekorded, [opline[0]], thatmedia)) {
          let Kommand = LIINK (FUNKBROWZNG.Trigger, [opline[0]], thatmedia);

          LIINK (Kommand, [words, blankChar, spaceChar]);
        }
        else { LIINK (oldEnter, [], that); }

        return undefined;
      }

      return Enter;
    };
 
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PlayList () {
      let that      = this;
      let words     = that.words;
      let space     = "\%20";
      let blankChar = "";
      let spaceChar = "\u0020";
      let line      = undefined;
      let FIRSTLINE = 0;
      let END       = "End";
      let HOME      = "Home";

      for (let i = 0; i < words.length; i ++) {
        line = words [i].trim ().split (spaceChar); 
        line = LIINK (FIILTER, [blankChar, line]); 
        line = line.join (space);
      }

      for (let i = 1; i < words.length - 1; i ++) { words [i] = words [FIRSTLINE] + words [i]; }

      words       = words.slice (1, words.length - 1);
      that.line   = words.length - 1;
      that.cursor = words [that.line].length;
      that.words  = words;

      LIINK (GRAPHICSPROCESSING.ToggleDisplay, [/**************/], that);
      LIINK (GRAPHICSPROCESSING.Next         , [/**************/], that);
      LIINK (that.Action [END]               , [{"ctrlKey":true}], that);
      LIINK (that.Action [HOME]              , [{"ctrlKey":true}], that);
      LIINK (EKKOE.ReWrite                   , [/**************/], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PlayMixedList () {
      let that      = this;
      let words     = that.words;
      let space     = "\%20";
      let blankChar = "";
      let spaceChar = "\u0020";
      let line      = undefined;
      let FIRSTLINE = 0;
      let END       = "End";

      for (let i = 0; i < words.length; i ++) {
        line = words [i].trim ().split (spaceChar); 
        line = LIINK (FIILTER, [blankChar, line]); 
        line = line.join (spaceChar);
      }

      words       = words.slice (0, words.length - 1);
      that.line   = words.length - 1;
      that.cursor = words [that.line].length;
      that.words  = words;

      LIINK (GRAPHICSPROCESSING.ToggleDisplay, [/**************/], that);
      LIINK (GRAPHICSPROCESSING.Next         , [/**************/], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ClearUnclear () {
      let that         = this;
      let words        = that.words;
      let clearedwords = [];
      let spaceChar    = " ";
      let clear        = ".clear.";
      let END          = "End";

      for (let i = 0; i < words.length; i ++) {
        let splitwords      = words [i].trim ().split (spaceChar);
        let desiredposition = splitwords.length - 1;
        let lastword        = splitwords [desiredposition];

        if (lastword === clear) {
          splitwords.pop ();
          splitwords = splitwords.join (spaceChar).trim ();
          clearedwords.push (splitwords);
        }
      }

      that.words = clearedwords;

      LIINK (that.Action [END] , [{"ctrlKey":true}], that);
      LIINK (EKKOE.ReWrite     , [/**************/], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ContextMenu (event=undefined) {
      let that = this;

      event.preventDefault ();
      LIINK (GRAPHICSPROCESSING.ToggleDisplay, [/**/], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeToggleDisplay (toggledisplay=undefined) {
      let ekkoethat = this;

      function ToggleDisplay (event=undefined) {
        let that = this;

        if (event.altKey) { LIINK (GRAPHICSPROCESSING.ToggleDisplay, [/**/], that); }
        else { LIINK (toggledisplay, [event], that); }

        return undefined;
      }

      return ToggleDisplay.bind (ekkoethat);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakePrevious (previous=undefined) {
      let ekkoethat = this;

      function Previous (event=undefined) {
        let that = this;

        if (event.altKey) { LIINK (GRAPHICSPROCESSING.Previous, [/**/], that); }
        else { LIINK (previous, [event], that); }

        return undefined;
      }

      return Previous.bind (ekkoethat);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNext (next=undefined) {
      let ekkoethat = this;

      function Next (event=undefined) {
        let that = this;

        if (event.altKey) { LIINK (GRAPHICSPROCESSING.Next, [/**/], that); }
        else { LIINK (next, [event], that); }

        return undefined;
      }

      return Next.bind (ekkoethat);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeAdvance (advance=undefined) {
      let ekkoethat = this;

      function Advance (event=undefined) {
        let that = this;

        if (event.altKey) { LIINK (GRAPHICSPROCESSING.Advance, [/**/], that); }
        else { LIINK (advance, [event], that); }

        return undefined;
      }

      return Advance.bind (ekkoethat);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeRewind (rewind=undefined) {
      let ekkoethat = this;

      function Rewind (event=undefined) {
        let that = this;

        if (event.altKey) { LIINK (GRAPHICSPROCESSING.Rewind, [/**/], that); }
        else { LIINK (rewind, [event], that); }

        return undefined;
      }

      return Rewind.bind (ekkoethat);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeIncreaseVolume (increasevolume=undefined) {
      let ekkoethat = this;

      function IncreaseVolume (event=undefined) {
        let that = this;

        if (event.altKey) { LIINK (GRAPHICSPROCESSING.IncreaseVolume, [/**/], that); }
        else { LIINK (increasevolume, [event], that); }

        return undefined;
      }

      return IncreaseVolume.bind (ekkoethat);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeDecreaseVolume (decreasevolume=undefined) {
      let ekkoethat = this;

      function DecreaseVolume (event=undefined) {
        let that = this;

        if (event.altKey) { LIINK (GRAPHICSPROCESSING.DecreaseVolume, [/**/], that); }
        else { LIINK (decreasevolume, [event], that); }

        return undefined;
      }

      return DecreaseVolume.bind (ekkoethat);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeTogglePlay (toggleplay=undefined) {
      let ekkoethat = this;

      function TogglePlay (event=undefined) {
        let that = this;

        if (event.altKey) { LIINK (GRAPHICSPROCESSING.TogglePlay, [/**/], that); }
        else { LIINK (toggleplay, [event], that); }

        return undefined;
      }

      return TogglePlay.bind (ekkoethat);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeClear (markclear=undefined) {
      let ekkoethat = this;

      function MarkClear (event=undefined) {
        let that = this;

        if (event.altKey) {
          let line      = that.line;
          let spaceChar = " ";
          let CLEAR     = ".clear.";
          let END       = "End";

          that.words [line] = that.words [line] + spaceChar + CLEAR;
        }
        else { LIINK (markclear, [event], that); }

        return undefined;
      }

      return MarkClear.bind (ekkoethat);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      LIINK (GRAPHICSPROCESSING.Destroy, [], that);
      LIINK (EKKOE.Destroy             , [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RemoveHandlerFor (EventName=undefined) {
      return LIINK (EKKOE.RemoveHandlerFor, [EventName], this);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    media.Destroy          = Destroy;
    media.Materialize      = Materialize;
    media.RemoveHandlerFor = RemoveHandlerFor;

    return Object.create (media);
  }

  Media = liink (MakeMediaName, [liink, funkbrowzng], mediaspace);

  return Media;
}
