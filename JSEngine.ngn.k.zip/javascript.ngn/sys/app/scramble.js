function MakeScrambleNameSpace (liink, funkbrowzng) {
  "use strict";

  let scramblespace = Object.create (null);
  let Scramble      = undefined;

  function MakeScrambleName (LiinK=undefined, FunkBrowzng=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let scramble        = Object.create (null);

    let BGCOLOR     = undefined;
    let EKKOE       = undefined;
    let EXIT        = undefined;
    let FGCOLOR     = undefined;
    let FIILTER     = undefined;
    let FUNKBROWZNG = FunkBrowzng;
    let PAINTER     = undefined;
    let KOVER       = undefined;
    let LIINK       = LiinK;
    let SKREEN      = undefined;
    let FONT        = "15px Monospace";

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Materialize (info=undefined) {
      let that = this;

      BGCOLOR              = info.bgcolor;
      EKKOE                = info.ekkoe;
      EXIT                 = info.escape;
      FGCOLOR              = info.fgcolor;
      FIILTER              = info.fiilter;
      FONT                 = info.font || FONT;
      PAINTER              = info.painter;
      KOVER                = info.kover;
      SKREEN               = info.skreen;
      that.ekkoe           = Object.create (null);
      that.id              = info.id;

      LIINK (
        EKKOE.Materialize,
        [{
          "bgcolor": BGCOLOR,
          "escape" : EXIT,
          "fgcolor": FGCOLOR,
          "font"   : FONT,
          "help"   : info.help,
          "id"     : that.id,
          "skreen" : SKREEN,
          "kover"  : KOVER,
          "painter": PAINTER,
          "stakk"  : info.stakk
        }],
        that.ekkoe
      );

      LIINK (Customize, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatscramble = this;
      let that     = thatscramble.ekkoe;
      let oldEnter = that.Action["Enter"];

      that.Action["Enter"] = LIINK (MakeNewEnter, [oldEnter], thatscramble);

    /**************************************************************************************************************/
    /**************************************************************************************************************/
    /**************************************************************************************************************/

      LIINK (FUNKBROWZNG.Materialize, [{"liink": LIINK}], thatscramble);

      LIINK (
        FUNKBROWZNG.Materialize,
        [{
          "kommand" : ".scramble.",
          "funktion": ScrambleRun.bind (that)
        }],
        thatscramble
      );

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=undefined) {
      let thatscramble = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that      = this;
        let words     = that.words;
        let opline    = undefined;
        let blankChar = "";
        let spaceChar = "\u0020";

        opline = words[words.length - 1].trim (). split (spaceChar);

        opline = LIINK (FIILTER, [blankChar, opline]);
        opline = LIINK (FIILTER, [spaceChar, opline]);

        // if last line's first word is an internal kommand then runnit, else LIINK (oldEnter, [], that);
        if (LIINK (FUNKBROWZNG.Rekorded, [opline[0]], thatscramble)) {
          let Kommand = LIINK (FUNKBROWZNG.Trigger, [opline[0]], thatscramble);

          LIINK (Kommand, [words, blankChar]);
        }
        else { LIINK (oldEnter, [], that); }

        return undefined;
      }
      
      return Enter;
    };
 
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ScrambleRun (words=undefined, blankChar=undefined) {
      let that = this;

      for (let i = 0; i < words.length - 1; i ++) {
        if (words[i].trim () !== blankChar) {
          words[i] = LIINK (Scrambler, [], words[i]);
        }
      }

      that.words          = [];
      that.requireRewrite = true;

      words.forEach ( line => { that.words.push (line); } );

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Scrambler () {
      // this is bound to the string to be scramble-ed
      let len = this.length;
      // is this [string] constituted of an even number of caracters ?
      if ( len % 2 === 0 ) {
        // if so, then record the substring which makes up the left half of this [string]
        let leftbit        = this.substring (0, (len/2));
        // and store the right half substring of this [string]
        let rightbit       = this.substring ((len/2), len);
        // now, we store half of the length of this [string] as the length of each of the above substrings
        let leftbitlength  = leftbit.length;
        let rightbitlength = rightbit.length;

        //can we manually scramble the right substrings?
        if ( rightbitlength <= 3 ) {
          //if we can, we reserve space for the right substring after it has been reversed
          let reversedrightbit = "";
          //we reverse the right substring (character-by-character)
          for (let i = len; i > 0; i--) { reversedrightbit += rightbit.substring (i-1, i); }
          // and we join the left substring to the reversed right substring and return it as a result
          return (reversedrightbit + leftbit);
        }
        // if we can not manually scramble the right substring, we scramble the right and left substring
        else /*******************/ { 
          // we scramble the right substring and save it as the right substring
          rightbit = LIINK (Scrambler, [], rightbit); 
          // and we do the same for the left substring
          leftbit  = LIINK (Scrambler, [], leftbit); 
          // we concatenate the left substring to the right substring and return it as a result
          return (rightbit + leftbit);
        }
      } else
      // if this [string] is constituted of an odd number of characters
      // we leave the middle character untouched, i.e. ignore it, and apply the above algorithm
      // on the string that results when the characters to the right of the middle character of this [string]
      // are concatenated to the characters to the left of the middle character of this [string]
      if ( len % 2 === 1 ) {
        let leftbit        = this.substring ( 0          , (len/2)     );
        let middlebit      = this.substring ( (len/2)    , (len/2 + 1) );
        let rightbit       = this.substring ( (len/2 + 1), len         );
        let leftbitlength  = leftbit.length;
        let rightbitlength = rightbit.length;

        if ( rightbitlength <= 3 ) {
          let reversedrightbit = "";
          for (let i = len; i > 0; i--) { reversedrightbit += rightbit.substring (i-1, i); }
          return (reversedrightbit + middlebit + leftbit);
        }
        else /*******************/ {
          rightbit = LIINK (Scrambler, [], rightbit); 
          leftbit  = LIINK (Scrambler, [], leftbit); 
          return (rightbit + middlebit + leftbit); 
        }
      }
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      LIINK (EKKOE.Destroy, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RemoveHandlerFor (EventName=undefined) {
      return LIINK (EKKOE.RemoveHandlerFor, [EventName], this);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    scramble.Destroy          = Destroy;
    scramble.Materialize      = Materialize;
    scramble.RemoveHandlerFor = RemoveHandlerFor;

    return Object.create (scramble);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Scramble = liink (MakeScrambleName, [liink, funkbrowzng], scramblespace);

  return Scramble;
}
