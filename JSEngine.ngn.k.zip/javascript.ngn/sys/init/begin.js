/*
    Begin initiates the JSEnging.ngn suite.
    Copyright (C) <2018>  <Sbabalwe Mchasa>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

    Email: gmeta07@gmail.com
*/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/***********************************************************************************
* Well, we want to start the whole program iff everything has been loaded ...
* ... it is not going to be _that_ great if it starts prematurely
/***********************************************************************************/
// *Narrator through the speakers* “The signal to go has been observed, and so our journey begind!”
/****
* the switch that waits for intput to be loaded to begin, which initiates the system of processes ...
**/
let Bubbling = false;
window.addEventListener ("DOMContentLoaded", Begin, Bubbling);
/***********************************************************************************/

/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/****
* the process of granting access to the system of processes from the outside of the system of processes, ...
**/
function Begin () {
"use strict";

/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/*****
* The things we will need, basically, ...
**/

/****
* the unique name used to refer to a system of processes, ...
**/
  let ID      = "begin";
/****
* the medium in which the processing will be conducted and referred to using a unique name, ...
**/
  let UTILS   = MakeUtilityNameSpace.call ();
/****
* the source of power through which input is obtained, ...
**/
  let JSNGN   = UTILS.Link (MakeJSEngineNameSpace, [UTILS]);
/****
* the definition of processes that may be carried out, ...
**/
  let PROCESS = UTILS.Link (MakeProcessNameSpace, [UTILS]);

/*****
* The Processes and The Enjin
*
* this is the place where data is stored for each process; see, there is the place where 
* functions or operations are defined and the place where the data or state is kept,
* and this is the place where data or state is defined
**/
/****
* the place where data about, or the state of, processes is kept, ...
**/
  let process  = Object.create (null);
/****
* the source of power, ...
**/
  let jsengine = Object.create (null);
/****
* the place where the data about processes that may be carried out is kept, ...
**/
  let included     = [
/****
* the process that draws lines, paths, and shapes, ...
**/
    "geometry", 
/****
* the process that accepts input and transforms it to human-readable output, ...
**/
    "ekkoe", 
/****
* the process that dispatches other processes for use and regulates order, ...
**/
    "nullterm", 
/****
* the process that exits the process that regulates order, ...
**
    ".exit.", 
/****
* the process that displays the codes of the used processes in their order of use, ...
**/
    ".history.",
/****
* the process that documents the working and use of the processes that may be used, ...
**/
    "help",
/****
* the process that documents the GNU GPL3 License, ...
**/
    "license",
/****
* the process that documents the working and use of the process of drawing methametical paths and areas, ...
**/
    "explaingeometry",
/****
* the process that documents the working and use of the input-transform-output process, ...
**/
    "explainekkoe",
/****
* the process that documents the working and use of the dispatching of processes and regulating of order, ...
**/
    "explainnullterm"
  ];

/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

// *Narrator through the speakers* “The standard key has been inserted into the slot ..., it's been turned...”
/****
* the process of requesting for the processes that may be carried out through the liink, ...
**/
  UTILS.Link (
    PROCESS.Materialize,
/****
* the input that is understood and expected by the request process, ...
**/
    [{
      "id"     : ID,
      "include": included
    }], 
/****
* the place where the output of the request process will be kept, ...
**/
    process
  );

/********************************************************************************************/
/********************************************************************************************/

// *Narrator through the speakers* “... and so, starts the jsengine enjin!”
/****
* the process of requesting for the source of power using the processes that may be carried out as the input ...
* ... and storing the output of the request in the place where the state of the source of power is kept, ...
* ... using the liink as the medium that connects the input to the request ...
* ... and also connects the request to the output place, ...
**/
  UTILS.Link (JSNGN.Materialize, [process], jsengine);

/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/****
* the process of disabling the switch that waits for input to begin, ...
**/
  window.removeEventListener ("DOMContentLoaded", Begin, Bubbling);
/****
* the process of preventing the access to the system of processes from the outside of the system of processes.
  Begin = undefined;

/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

}
