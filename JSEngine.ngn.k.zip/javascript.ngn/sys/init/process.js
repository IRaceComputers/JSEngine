/*
    Process holds and combines the default data with init functions of processes, 
    which prepares each process to be called as a command.
    Copyright (C) <2018>  <Sbabalwe Mchasa>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

    Email: gmeta07@gmail.com
*/
function MakeProcessNameSpace (utils) {
  "use strict";

  let processspace = Object.create (null);
  let Process      = undefined;

  function MakeProcessName (Utils=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let process = Object.create (null);

    /***********************************************************************************
    * All The Necessary State Variables and Konstants
    /***********************************************************************************/ 
    // Library Classes
    let UTILS      = Utils;
    let STACK      = undefined;
    // Object Template Classes
    let INTEGER     = undefined;
    let DECIMAL     = undefined;
    let BROWSER     = undefined;
    let GEOMETRY    = undefined;
    let GEOMETER    = undefined;
    let EKKOE       = undefined;
    let FILEMANAGER = undefined;
    let FILERECORDS = undefined;
    let GRID        = undefined;
    let PAINTER     = undefined;
    let NULLTERM    = undefined;
    // Data-Storage Objects
    let INITDATA    = undefined;
    let INITIATE    = undefined;
    let COVER       = undefined;
    let PROCESS     = undefined;
    let SCREEN      = undefined;
    let SERVER      = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Materialize (info=undefined) {
    // the passed info object determines which processes should be usable ... 
    // to allow for the creation of process groups ... 

      // *Narrator through the speakers* of course we won't seperate processes, ...
      // *Narrator through the speakers* ... we can only group them for convenience! 
      let that   = this;
      let listed = info.include;

      that.id     = info.id;
      FILERECORDS = "/sys/doc/filerecords";

      // Value-Removing Function

      UTILS.Link (DefineDefaultState);
      // and then the optional set of objects which the 'outside' can choose from
      if (listed !== undefined && listed.length > 0) {
        let processName = 0;

        SERVER.exceptional = Object.create (null);
        that.initdata      = INITDATA;
        that.initiate      = INITIATE;

        while (processName < listed.length) {
          UTILS.Link (Include, [listed [processName]]);
           processName = processName + 1;
        }
      }

      // the standard set of objects to make available to the 'outside'
      that.ekkoe        = EKKOE;
      that.painter      = PAINTER;
      that.nullterm     = NULLTERM;
      that.process      = PROCESS;
      that.server       = SERVER;
      that.StartProcess = UTILS.Link (BeginProcess, [NULLTERM.Materialize, INITDATA ["nullterm"]]);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefineDefaultState (info=undefined) {
      /***********************************************************************************
      * Object Template Classes
      /**********************************************************************************/
      /*
      * LIBRARY OBJECTS
      **/
      INTEGER     = UTILS.Link (MakeIntegerNameSpace    , [UTILS]);
      DECIMAL     = UTILS.Link (MakeDecimalNameSpace    , [UTILS, INTEGER]);
      BROWSER     = UTILS.Link (MakeBrowserNameSpace    , [UTILS]);
      GRID        = UTILS.Link (MakeGridNameSpace       , [UTILS]);
      PAINTER     = UTILS.Link (MakePainterNameSpace    , [UTILS]);
      GEOMETER    = UTILS.Link (MakeGeometerNameSpace   , [UTILS, DECIMAL]);
      STACK       = UTILS.Link (MakeStackNameSpace      , [UTILS]);
      FILEMANAGER = UTILS.Link (MakeFileManagerNameSpace, [UTILS, STACK, FILERECORDS]);
      /*
      * PROGRAM OBJECTS
      **/
      EKKOE    = UTILS.Link (MakeEkkoeNameSpace   , [UTILS]);
      GEOMETRY = UTILS.Link (MakeGeometryNameSpace, [UTILS, DECIMAL, BROWSER]); 
      NULLTERM = UTILS.Link (MakeNullTermNameSpace, [UTILS]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      /***********************************************************************************
      * Data-Storage Objects
      /**********************************************************************************/
      COVER    = document.querySelector ("#cover");
      INITDATA = Object.create (null);
      INITIATE = Object.create (null);
      PROCESS  = Object.create (null);
      SERVER   = Object.create (null);
      SCREEN   = Object.create (null);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      INITDATA ["BGCOLOR"] = "#000030FF";
      INITDATA ["FGCOLOR"] = "#00BAFFFF";
      INITDATA ["FONT"]    = "15px Monospace";

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      /***********************************************************************************
        * ekkoe init data
      /**********************************************************************************/

      INITDATA ["ekkoe"]                = Object.create (null);
      INITDATA ["ekkoe"]["bgcolor"]     = INITDATA ["BGCOLOR"];
      INITDATA ["ekkoe"]["fgcolor"]     = INITDATA ["FGCOLOR"];
      INITDATA ["ekkoe"]["font"]        = INITDATA ["FONT"];
      INITDATA ["ekkoe"]["help"]        = "/sys/doc/ekkoe";
      INITDATA ["ekkoe"]["id"]          = "ekkoe";
      INITDATA ["ekkoe"]["filemanager"] = FILEMANAGER;
      INITDATA ["ekkoe"]["painter"]     = PAINTER;
      INITDATA ["ekkoe"]["cover"]       = COVER;
      INITDATA ["ekkoe"]["screen"]      = SCREEN;
      INITDATA ["ekkoe"]["stack"]       = STACK;

      /***********************************************************************************
      * nullterm init data
      /**********************************************************************************/

      INITDATA ["nullterm"]                = Object.create (null);
      INITDATA ["nullterm"]["bgcolor"]     = INITDATA ["BGCOLOR"];
      INITDATA ["nullterm"]["fgcolor"]     = INITDATA ["FGCOLOR"];
      INITDATA ["nullterm"]["font"]        = INITDATA ["FONT"];
      INITDATA ["nullterm"]["help"]        = "/sys/doc/nullterm";
      INITDATA ["nullterm"]["id"]          = "nullterm";
      INITDATA ["nullterm"]["ekkoe"]       = EKKOE;
      INITDATA ["nullterm"]["filemanager"] = FILEMANAGER;
      INITDATA ["nullterm"]["painter"]     = PAINTER;
      INITDATA ["nullterm"]["cover"]       = COVER;
      INITDATA ["nullterm"]["screen"]      = SCREEN;
      INITDATA ["nullterm"]["stack"]       = STACK;

      /***********************************************************************************
      * geometry init data
      /**********************************************************************************/
      INITDATA ["geometry"]                = Object.create (null);
      INITDATA ["geometry"]["bgcolor"]     = INITDATA ["BGCOLOR"];
      INITDATA ["geometry"]["fgcolor"]     = INITDATA ["FGCOLOR"];
      INITDATA ["geometry"]["font"]        = INITDATA ["FONT"];
      INITDATA ["geometry"]["help"]        = "/sys/doc/geometry";
      INITDATA ["geometry"]["id"]          = "geometry";
      INITDATA ["geometry"]["unit"]        = Object.create (null);
      INITDATA ["geometry"]["unit"]["x"]   = 10;
      INITDATA ["geometry"]["unit"]["y"]   = 10;
      INITDATA ["geometry"]["grid"]        = GRID;
      INITDATA ["geometry"]["ekkoe"]       = EKKOE;
      INITDATA ["geometry"]["geometer"]    = GEOMETER;
      INITDATA ["geometry"]["browser"]     = BROWSER;
      INITDATA ["geometry"]["filemanager"] = FILEMANAGER;
      INITDATA ["geometry"]["painter"]     = PAINTER;
      INITDATA ["geometry"]["cover"]       = COVER;
      INITDATA ["geometry"]["screen"]      = SCREEN;
      INITDATA ["geometry"]["stack"]       = STACK;

      /***********************************************************************************
      * help init data
      /**********************************************************************************/
      INITDATA ["help"]                = Object.create (null);
      INITDATA ["help"]["bgcolor"]     = INITDATA ["BGCOLOR"];
      INITDATA ["help"]["fgcolor"]     = INITDATA ["FGCOLOR"];
      INITDATA ["help"]["font"]        = INITDATA ["FONT"];
      INITDATA ["help"]["help"]        = "/sys/doc/help";
      INITDATA ["help"]["id"]          = "help";
      INITDATA ["help"]["ekkoe"]       = EKKOE;
      INITDATA ["help"]["filemanager"] = FILEMANAGER;
      INITDATA ["help"]["painter"]     = PAINTER;
      INITDATA ["help"]["cover"]       = COVER;
      INITDATA ["help"]["screen"]      = SCREEN;
      INITDATA ["help"]["stack"]       = STACK;

      /***********************************************************************************
      * license init data
      /**********************************************************************************/
      INITDATA ["license"]                = Object.create (null);
      INITDATA ["license"]["bgcolor"]     = INITDATA ["BGCOLOR"];
      INITDATA ["license"]["fgcolor"]     = INITDATA ["FGCOLOR"];
      INITDATA ["license"]["font"]        = INITDATA ["FONT"];
      INITDATA ["license"]["help"]        = "/sys/doc/license";
      INITDATA ["license"]["id"]          = "license";
      INITDATA ["license"]["ekkoe"]       = EKKOE
      INITDATA ["license"]["filemanager"] = FILEMANAGER;
      INITDATA ["license"]["painter"]     = PAINTER;
      INITDATA ["license"]["cover"]       = COVER;
      INITDATA ["license"]["screen"]      = SCREEN;
      INITDATA ["license"]["stack"]       = STACK;

      /***********************************************************************************
      * explainnullterm init data
      /**********************************************************************************/
      INITDATA ["explainnullterm"]                = Object.create (null);
      INITDATA ["explainnullterm"]["bgcolor"]     = INITDATA ["BGCOLOR"];
      INITDATA ["explainnullterm"]["fgcolor"]     = INITDATA ["FGCOLOR"];
      INITDATA ["explainnullterm"]["font"]        = INITDATA ["FONT"];
      INITDATA ["explainnullterm"]["help"]        = "/sys/doc/explainnullterm";
      INITDATA ["explainnullterm"]["id"]          = "explainnullterm";
      INITDATA ["explainnullterm"]["ekkoe"]       = EKKOE;
      INITDATA ["explainnullterm"]["filemanager"] = FILEMANAGER;
      INITDATA ["explainnullterm"]["painter"]     = PAINTER;
      INITDATA ["explainnullterm"]["cover"]       = COVER;
      INITDATA ["explainnullterm"]["screen"]      = SCREEN;
      INITDATA ["explainnullterm"]["stack"]       = STACK;

      /***********************************************************************************
      * explainekkoe init data
      /**********************************************************************************/
      INITDATA ["explainekkoe"]                = Object.create (null);
      INITDATA ["explainekkoe"]["bgcolor"]     = INITDATA ["BGCOLOR"];
      INITDATA ["explainekkoe"]["fgcolor"]     = INITDATA ["FGCOLOR"];
      INITDATA ["explainekkoe"]["font"]        = INITDATA ["FONT"];
      INITDATA ["explainekkoe"]["help"]        = "/sys/doc/explainekkoe";
      INITDATA ["explainekkoe"]["id"]          = "explainekkoe";
      INITDATA ["explainekkoe"]["ekkoe"]       = EKKOE
      INITDATA ["explainekkoe"]["filemanager"] = FILEMANAGER;
      INITDATA ["explainekkoe"]["painter"]     = PAINTER;
      INITDATA ["explainekkoe"]["cover"]       = COVER;
      INITDATA ["explainekkoe"]["screen"]      = SCREEN;
      INITDATA ["explainekkoe"]["stack"]       = STACK;

      /***********************************************************************************
      * explaingeometry init data
      /**********************************************************************************/
      INITDATA ["explaingeometry"]                = Object.create (null);
      INITDATA ["explaingeometry"]["bgcolor"]     = INITDATA ["BGCOLOR"];
      INITDATA ["explaingeometry"]["fgcolor"]     = INITDATA ["FGCOLOR"];
      INITDATA ["explaingeometry"]["font"]        = INITDATA ["FONT"];
      INITDATA ["explaingeometry"]["help"]        = "/sys/doc/explaingeometry";
      INITDATA ["explaingeometry"]["id"]          = "explaingeometry";
      INITDATA ["explaingeometry"]["ekkoe"]       = EKKOE;
      INITDATA ["explaingeometry"]["filemanager"] = FILEMANAGER;
      INITDATA ["explaingeometry"]["painter"]     = PAINTER;
      INITDATA ["explaingeometry"]["cover"]       = COVER;
      INITDATA ["explaingeometry"]["screen"]      = SCREEN;
      INITDATA ["explaingeometry"]["stack"]       = STACK;

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      /**********************************************************************
      * The Screen Dimensions
      /**********************************************************************/
      SCREEN ["height"]    = window.innerHeight - 20;
      SCREEN ["width"]     = window.innerWidth  - 30;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Include (processName=undefined) {
      if (processName === "nullterm") {
        PROCESS  ["nullterm"] = SERVER;
        INITIATE ["nullterm"] = UTILS.Link (BeginProcess, [NULLTERM.Materialize, INITDATA.nullterm]);
      }

      if (processName === ".exit.") {
        PROCESS  [".exit."] = SERVER;               // a pseudo-process... a built-in
        INITIATE [".exit."] = EscapeNullTerm;       // a pseudo-process... a built-in
        INITDATA [".exit."] = INITDATA.nullterm;
      }

      if (processName === ".history.") {
        PROCESS  [".history."] = SERVER;            // a pseudo-process... a built-in
        INITIATE [".history."] = NULLTERM.History;  // a pseudo-process... a built-in
        INITDATA [".history."] = INITDATA.nullterm;

        SERVER.history = [];                       // preparing the built-in
        SERVER.exceptional [".history."] = true;
      }

      if (processName === "ekkoe") {
        PROCESS  ["ekkoe"] = Object.create (null);
        INITIATE ["ekkoe"] = UTILS.Link (BeginProcess, [EKKOE.Materialize, INITDATA.ekkoe]);
        INITDATA ["ekkoe"]["escape"] = UTILS.Link (EndProcess, [{"ekkoe": PROCESS.ekkoe}, EKKOE]);
      }

      if (processName === "geometry") {
        PROCESS  ["geometry"] = Object.create (null);
        INITIATE ["geometry"] = UTILS.Link (BeginProcess, [GEOMETRY.Materialize, INITDATA.geometry]);
        INITDATA ["geometry"]["escape"] = UTILS.Link (EndProcess, [PROCESS.geometry, GEOMETRY]);
      }
      
      if (processName === "help") {
        PROCESS  ["help"] = SERVER;
        INITIATE ["help"] = UTILS.Link (BeginProcess, [NULLTERM.Materialize, INITDATA.help]);
        INITDATA ["help"]["escape"] = UTILS.Link (EndProcess, [PROCESS.help, NULLTERM]).bind (PROCESS.help);
      }

      if (processName === "license") { 
        PROCESS  ["license"] = SERVER;
        INITIATE ["license"] = UTILS.Link (BeginProcess, [NULLTERM.Materialize, INITDATA.license]);
        INITDATA ["license"]["escape"] = UTILS.Link (EndProcess, [PROCESS.help, NULLTERM]).bind (PROCESS.license);
      }
      
      if (processName === "explainnullterm") {
        PROCESS  ["explainnullterm"] = SERVER;
        INITIATE ["explainnullterm"] = UTILS.Link (BeginProcess, [NULLTERM.Materialize, INITDATA.explainnullterm]);
        INITDATA ["explainnullterm"]["escape"] = UTILS.Link (EndProcess, [PROCESS.help, NULLTERM]).bind (PROCESS.explainnullterm);
      }

      if (processName === "explainekkoe") {
        PROCESS  ["explainekkoe"] = SERVER;
        INITIATE ["explainekkoe"] = UTILS.Link (BeginProcess, [NULLTERM.Materialize, INITDATA.explainekkoe]);
        INITDATA ["explainekkoe"]["escape"] = UTILS.Link (EndProcess, [PROCESS.help, NULLTERM]).bind (PROCESS.explainekkoe);
      }
      
      if (processName === "explaingeometry") {
        PROCESS  ["explaingeometry"] = SERVER;
        INITIATE ["explaingeometry"] = UTILS.Link (BeginProcess, [NULLTERM.Materialize, INITDATA.explaingeometry]);
        INITDATA ["explaingeometry"]["escape"]  = UTILS.Link (EndProcess, [PROCESS.help, NULLTERM]).bind (PROCESS.explaingeometry);
      }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /********************************************************************************************************************

    IF YOU WANT TO DEFINE ANYMORE PROCESS START AND ESCAPE FUNCTIONS, THEN ...
    ... THIS IS THE PLACE TO DO IT

  /********************************************************************************************************************/

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function BeginProcess (MaterializeProcess=undefined, ProcessData=undefined) {

      function InitProcess () {
        let that = this;

        UTILS.Link (MaterializeProcess, [ProcessData], that);

        return undefined;
      }

      return InitProcess;
    }  

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function EndProcess (ProcessName=undefined, ProcessFunctions=undefined) {
      function InitEnd () {
        let that        = this;
        let EscapeRoute = [ProcessName, ProcessFunctions];

        return UTILS.Link (EscapeUsing, EscapeRoute, that);
      }

      return InitEnd;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function EscapeUsing (ProcessName=undefined, ProcessFunctions=undefined) { 
      let that   = this;
      let words  = SERVER.ekkoe.words;
      let line   = SERVER.ekkoe.line;
      let cursor = SERVER.ekkoe.cursor;
    /**************************************************************************************************************/
    /***************************************************************************************************************
    * Do We Have A Process We Would Like To Launch Immediately After Exiting ProcessName?
    * We will read the first word on last line of ProcessName's final text...
    * If we find it, we send it to nullterm to execute...
    * Otherwise, nothing, just pass!
    /**************************************************************************************************************/
      let kommand       = undefined;
      let mywords       = ProcessName.ekkoe.words;
      let lastline      = mywords [mywords.length - 1].trim (). split (UTILS.KBD.WHITESPACE);
      let StartNullTerm = UTILS.Link (BeginProcess, [NULLTERM.Materialize, INITDATA.nullterm]);

      lastline = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, lastline]);
      lastline = UTILS.Link (UTILS.Filter, [UTILS.KBD.WHITESPACE, lastline]);
    
      kommand  = lastline [0];

      if (PROCESS [kommand]) { words [words.length - 1] = kommand; }
    /**************************************************************************************************************/
    /**************************************************************************************************************/
    /**************************************************************************************************************/

      /**********************************************************************
      * To Exit ProcessName ...
      /**********************************************************************/
      UTILS.Link (ProcessFunctions.Destroy, [], that);
      /**********************************************************************
      * ... And Return To nullterm
      /**********************************************************************/
      UTILS.Link (StartNullTerm, [], SERVER);

      SERVER.ekkoe.words  = words;
      SERVER.ekkoe.line   = line;
      SERVER.ekkoe.cursor = cursor;

      UTILS.Link (EKKOE.ReWrite, [], SERVER.ekkoe);
      /**********************************************************************/

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    process.Materialize = Materialize;

    return Object.create (process);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Process = utils.Link (MakeProcessName, [utils], processspace);

  return Process;
}