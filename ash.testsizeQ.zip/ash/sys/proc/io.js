 /****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2018 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeEkkoeNameSpace (utils, viewport) {
  "use strict";

  let ekkoespace = Object.create (null);
  let Ekkoe      = undefined;

  function MakeEkkoeName (Utils=undefined, ViewPort=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
    let ekkoe = Object.create (null);
    /************************************************************************************
    * keyboard functions
    ************************************************************************************/
    let Action    = undefined;
    let Printable = undefined;
    let Release   = undefined;
    let EXIT      = undefined;
    /************************************************************************************
    * keyboard key state modifiers
    ************************************************************************************/
    let ALTDOWN      = undefined;
    let ALTGRAPHDOWN = undefined;
    let CONTROLDOWN  = undefined;
    let INSERT       = undefined;
    let SCROLLLOCK   = undefined;
    let SHIFTDOWN    = undefined;
    let PRESS        = undefined;
    let RELEASE      = undefined;
    /************************************************************************************
    * class objects
    ************************************************************************************/
    let FILEMANAGER = undefined;
    let PAINTER     = undefined;
    let STACK       = undefined;
    let UTILS       = undefined;
    let VIEWPORT    = undefined;
    /************************************************************************************
    * filemanager states
    ************************************************************************************/
    let CURSOR = undefined;
    let FILE   = undefined;
    let LINE   = undefined;
    let WHOLE  = undefined;
    /************************************************************************************
    * viewport states
    ************************************************************************************/
    let FONT          = undefined;
    let LINEHEIGHT    = undefined;
    let FILESEGSIZE   = undefined;
    let FILESEGBEGIN  = undefined;
    let FILESEGEND    = undefined;
    let LINESTART     = undefined;
    let LINESTOP      = undefined;
    let TMARGIN       = undefined;
    let LMARGIN       = undefined;
    let BMARGIN       = undefined;
    let RMARGIN       = undefined;
    let VIEWCAPACITY  = undefined;
    /************************************************************************************
    * ekkoe global variables
    ************************************************************************************/
    let COVER   = undefined;
    let EXPLAIN = undefined;
    let FGCOLOR = undefined;
    let HELP    = undefined;
    let TABSIZE = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=undefined) {
    /************************************************************************************
    * The function which creates the ekkoe process
    ************************************************************************************/
      let that = this;

      FILEMANAGER = info.filemanager;
      PAINTER     = info.painter;
      STACK       = info.stack;
      EXIT        = info.escape;
      COVER       = info.cover;
      HELP        = info.help;
      CURSOR      = 0;
      LINE        = 0;
      TMARGIN     = 20;
      LMARGIN     = 20;
      BMARGIN     = info.height - TMARGIN;
      RMARGIN     = info.width - 10*LMARGIN;
      LINESTART   = 0;
      LINESTOP    = 100;

      if (FGCOLOR === undefined) { UTILS.Link (SetFgColor, [info.fgcolor]); }
      if (FONT === undefined) { UTILS.Link (SetFont, [info.font]); }

      UTILS.Link (UTILS.MapKeyValue, [that, "color", info.bgcolor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
    /************************************************************************************
    * create painter
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "painter", Object.create (null)]);
      UTILS.Link (UTILS.MapKeyValue, [info, "painterInfo", Object.create (null)]);
      UTILS.Link (UTILS.MapKeyValue, [info.painterInfo, "cover", info.cover]);
      UTILS.Link (UTILS.MapKeyValue, [info.painterInfo, "height", info.height]);
      UTILS.Link (UTILS.MapKeyValue, [info.painterInfo, "id", info.id]);
      UTILS.Link (UTILS.MapKeyValue, [info.painterInfo, "width", info.width]);
      UTILS.Link (PAINTER.Create, [info.painterInfo], that.painter);
    /************************************************************************************
    * create stack
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "stack", Object.create (null)]);
      UTILS.Link (STACK.Create, null, that.stack);
    /************************************************************************************
    * initialize viewport
    ************************************************************************************/
      UTILS.Link (VIEWPORT.SetTopMargin, [TMARGIN]);
      UTILS.Link (VIEWPORT.SetLeftMargin, [LMARGIN]);
      UTILS.Link (VIEWPORT.SetBottomMargin, [BMARGIN]);
      UTILS.Link (VIEWPORT.SetRightMargin, [RMARGIN]);
      UTILS.Link (VIEWPORT.SetLineStop, [LINESTOP]);
    /************************************************************************************
    * customize ekkoe
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "Action", Object.create (Action)]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Printable", Object.create (Printable)]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Release", Object.create (Release)]);
      UTILS.Link (Customize, null, that);
    /********************************************************************************************************************/
      UTILS.Link (CalculateViewCapacity);
    /************************************************************************************
    * create filemanager
    ************************************************************************************/
      UTILS.Link (FILEMANAGER.Create, null, that);
      UTILS.Link (FILEMANAGER.Read, [HELP], that);
    /********************************************************************************************************************/

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
 
    function Customize () {
      let that    = this;
      let HELP    = UTILS.KBD.KEY.F1;
      let oldHelp = UTILS.Link (GetKeyFunction, [HELP, PRESS], that);
      let newHelp = UTILS.Link (MakeNewHelp, [oldHelp], that);
      let html    = UTILS.WIN.DOC.querySelector ("html");
      let center  = UTILS.WIN.DOC.querySelector ("center");
      let head    = UTILS.WIN.DOC.querySelector ("head");
      let body    = UTILS.WIN.DOC.querySelector ("body");
      let bgcolor = "backgroundColor";

      UTILS.Link (UTILS.MapKeyValue, [COVER.style, bgcolor, that.color]);
      UTILS.Link (UTILS.MapKeyValue, [html.style, bgcolor, that.color]);
      UTILS.Link (UTILS.MapKeyValue, [center.style, bgcolor, that.color]);
      UTILS.Link (UTILS.MapKeyValue, [head.style, bgcolor, that.color]);
      UTILS.Link (UTILS.MapKeyValue, [body.style, bgcolor, that.color]);
    /********************************************************************************************************************/
      UTILS.Link (SetKeyFunction, [UTILS.KBD.KEY.ESCAPE, EXIT, RELEASE], that);
      UTILS.Link (SetKeyFunction, [HELP, newHelp, PRESS], that);
      UTILS.Link (SetKeyFunction, [UTILS.KBD.KEY.INTERNALCALL, UseFileContents, PRESS], that);
    /********************************************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that.Action, UTILS.KBD.KEY.DOWN, KeydownHandler.bind (that)]);
      UTILS.Link (UTILS.MapKeyValue, [that.Action, UTILS.KBD.KEY.UP, KeyupHandler.bind (that)]);
      UTILS.Link (UTILS.MapKeyValue, [that.Action, UTILS.WIN.RESIZE, ResizeHandler.bind (that)]);
      UTILS.Link (UTILS.MapKeyValue, [that.Action, UTILS.MWS.WHEEL, MouseWheelScrollHandler.bind (that)]);
    /********************************************************************************************************************/
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.KBD.KEY.DOWN, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.KBD.KEY.UP, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.WIN.RESIZE, UTILS.WIN.SYS] , that.Action);
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.MWS.WHEEL, UTILS.Link (PAINTER.GetCanvas)], that.Action);

      return undefined;
     }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UseFileContents (event=undefined) {
      let that = this;

      UTILS.Link (RetrieveFile);
      UTILS.Link (RetrieveFileLine);
      UTILS.Link (RetrieveFileCursor);

      FILESEGBEGIN = 0;
      FILESEGEND = LINE;
      LINESTART = FILESEGBEGIN;

      if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
      if (LINE >= VIEWCAPACITY) {
        FILESEGBEGIN = LINE - VIEWCAPACITY;
        FILESEGEND = VIEWCAPACITY;
      }

      UTILS.Link (VIEWPORT.SetSegmentBegin, [FILESEGBEGIN]);
      UTILS.Link (VIEWPORT.SetSegmentEnd, [FILESEGEND]);
      UTILS.Link (VIEWPORT.SetLineStart, [LINESTART]);
      UTILS.Link (ReWrite, null, that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=undefined) {
      let thatekkoe = this;

      function Help (event=undefined, otherEscape=undefined) {
        let that             = this;
        let scrollLockActive = UTILS.Link (GetScrollLockState);
        let ScrollLock       = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, RELEASE], that);
        let End              = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, RELEASE], thatekkoe);
        let Enter            = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ENTER, PRESS], thatekkoe);
        let Escape           = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ESCAPE, RELEASE], thatekkoe);
        let PressControl     = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, PRESS], thatekkoe);
        let ReleaseControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, RELEASE], thatekkoe);

        if (otherEscape !== undefined) { Escape = otherEscape; }

        UTILS.Link (PressControl);
        UTILS.Link (End, null, that);
        UTILS.Link (ReleaseControl);
        UTILS.Link (Eneter, null, that);
        UTILS.Link (Helper, null, that);
        UTILS.Link (Escape, null, that);

        return undefined;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LeadWithSpaces (number=undefined, max=undefined) {
      let paddedValue = UTILS.BLANKCHAR + number + UTILS.KBD.KEY.WHITESPACE;
      let maxlength = (UTILS.BLANKCHAR + max).length;
      let blocks = 1 + maxlength - paddedValue.length;

      while (blocks > 0) {
        paddedValue = UTILS.KBD.KEY.WHITESPACE + paddedValue;
        blocks = blocks - 1;
      }

      return paddedValue;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ReWrite (somewords=undefined) {
      let that         = this;
      let currententry = undefined;
      let subline      = undefined;
      let filesize     = undefined;
      let words        = somewords;
      let thisline     = FILESEGBEGIN

      if (words === undefined) { words = FILE; }

      FILESEGSIZE = FILESEGEND;
      filesize = words.length;

      UTILS.Link (PAINTER.BeginPath);
      UTILS.Link (PAINTER.SetFillColorTo, [that.color]);
      UTILS.Link (PAINTER.PaintBackGround);
      UTILS.Link (PAINTER.SetFontTo, [FONT]);
      UTILS.Link (PAINTER.SetFillColorTo, [FGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [that, "x", LMARGIN]);
      UTILS.Link (UTILS.MapKeyValue, [that, "y", TMARGIN]);

      while (thisline <= (FILESEGBEGIN + FILESEGSIZE)) {
        currententry = words [thisline];
        subline = UTILS.Link (LeadWithSpaces, [thisline, filesize]);
        subline = subline + currententry.substring (LINESTART, LINESTART + LINESTOP);

        UTILS.Link (PAINTER.FillText, [subline], that);
        UTILS.Link (NewLine, null, that);

        thisline = thisline + 1;
      }

      UTILS.Link (PAINTER.SetFillColorTo, [that.color]);
      UTILS.Link (PAINTER.PaintBackGround, [RMARGIN]);
      UTILS.Link (PAINTER.ClosePath);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define arbitrary internal functions below
  ************************************************************************************/

    function NewLine () {
    /************************************************************************************
    * The function which moves the cursor to the next line on the kanvas 
    ************************************************************************************/
      let that = this;
      UTILS.Link (UTILS.MapKeyValue, [that, "y", that.y + LINEHEIGHT]);
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SkipWordMoveCursor (spaceCharSide=undefined) {
      let that  = this;
      let chars = undefined;
      let line  = undefined;
      let LEFT  = 0;
      let RIGHT = 1

      line = FILE [LINE];

      if ((LEFT === spaceCharSide) || (spaceCharSide === RIGHT)) {
        if (spaceCharSide === RIGHT) {
          for (let o = CURSOR; o <= line.length - 2; o ++) {
            chars = line.substring (o, o+2);

            if ((chars.charAt (RIGHT) === UTILS.KBD.KEY.WHITESPACE) && (chars.charAt (LEFT) !== UTILS.KBD.KEY.WHITESPACE)) {
              return (o+1);
            }
          }

          return line.length;
        }
        else {
          for (let o = CURSOR; o >= 2; o --) {
            chars = line.substring (o-2, o);

            if ((chars.charAt (LEFT) === UTILS.KBD.KEY.WHITESPACE) && (chars.charAt (RIGHT) !== UTILS.KBD.KEY.WHITESPACE)) {
              return (o-1);
            }
          }

          return LEFT;
        }
      }

      return (-RIGHT);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function InvisibleCharacter (key=undefined) {
    /************************************************************************************
    * The function which determines whether a character is non-printable 
    ************************************************************************************/
      let invisibility = false;

      switch (key) {
        case UTILS.KBD.KEY.ALT                : invisibility = true; break;
        case UTILS.KBD.KEY.ALTGRAPH           : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWDOWN          : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWLEFT          : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWRIGHT         : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWUP            : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEDOWN    : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEMUTE    : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEUP      : invisibility = true; break;
        case UTILS.KBD.KEY.BACKSPACE          : invisibility = true; break;
        case UTILS.KBD.KEY.CAPSLOCK           : invisibility = true; break;
        case UTILS.KBD.KEY.CONTROL            : invisibility = true; break;
        case UTILS.KBD.KEY.CONTEXTMENU        : invisibility = true; break;
        case UTILS.KBD.KEY.DELETE             : invisibility = true; break;
        case UTILS.KBD.KEY.END                : invisibility = true; break;
        case UTILS.KBD.KEY.ENTER              : invisibility = true; break;
        case UTILS.KBD.KEY.ESCAPE             : invisibility = true; break;
        case UTILS.KBD.KEY.F1                 : invisibility = true; break;
        case UTILS.KBD.KEY.F2                 : invisibility = true; break;
        case UTILS.KBD.KEY.F3                 : invisibility = true; break;
        case UTILS.KBD.KEY.F4                 : invisibility = true; break;
        case UTILS.KBD.KEY.F5                 : invisibility = true; break;
        case UTILS.KBD.KEY.F6                 : invisibility = true; break;
        case UTILS.KBD.KEY.F7                 : invisibility = true; break;
        case UTILS.KBD.KEY.F8                 : invisibility = true; break;
        case UTILS.KBD.KEY.F9                 : invisibility = true; break;
        case UTILS.KBD.KEY.F10                : invisibility = true; break;
        case UTILS.KBD.KEY.F11                : invisibility = true; break;
        case UTILS.KBD.KEY.F12                : invisibility = true; break;
        case UTILS.KBD.KEY.HOME               : invisibility = true; break;
        case UTILS.KBD.KEY.INSERT             : invisibility = true; break;
        case UTILS.KBD.KEY.INTERNALCALL       : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIAPLAY          : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIATRACKNEXT     : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIATRACKPREVIOUS : invisibility = true; break;
        case UTILS.KBD.KEY.NUMLOCK            : invisibility = true; break;
        case UTILS.KBD.KEY.OS                 : invisibility = true; break;
        case UTILS.KBD.KEY.PAGEDOWN           : invisibility = true; break;
        case UTILS.KBD.KEY.PAGEUP             : invisibility = true; break;
        case UTILS.KBD.KEY.SHIFT              : invisibility = true; break;
        case UTILS.KBD.KEY.SCROLLLOCK         : invisibility = true; break;
        case UTILS.KBD.KEY.TAB                : invisibility = true; break;
        case UTILS.KBD.KEY.UNIDENTIFIED       : invisibility = true; break;
      }

      return invisibility;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CommandCharacter (key=undefined) {
    /************************************************************************************
    * The function which determines whether a character is treated as a command 
    ************************************************************************************/
      let status = false;

      switch (key) {
        case UTILS.KBD.KEY.ALT                : status = true; break;
        case UTILS.KBD.KEY.ALTGRAPH           : status = true; break;
        case UTILS.KBD.KEY.ARROWDOWN          : status = true; break;
        case UTILS.KBD.KEY.ARROWLEFT          : status = true; break;
        case UTILS.KBD.KEY.ARROWRIGHT         : status = true; break;
        case UTILS.KBD.KEY.ARROWUP            : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEDOWN    : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEMUTE    : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEUP      : status = true; break;
        case UTILS.KBD.KEY.BACKSPACE          : status = true; break;
        case UTILS.KBD.KEY.CONTEXTMENU        : status = true; break;
        case UTILS.KBD.KEY.CONTROL            : status = true; break;
        case UTILS.KBD.KEY.DELETE             : status = true; break;
        case UTILS.KBD.KEY.ENTER              : status = true; break;
        case UTILS.KBD.KEY.F1                 : status = true; break;
        case UTILS.KBD.KEY.F5                 : status = true; break;
        case UTILS.KBD.KEY.F6                 : status = true; break;
        case UTILS.KBD.KEY.F11                : status = true; break;
        case UTILS.KBD.KEY.MEDIAPLAY          : status = true; break;
        case UTILS.KBD.KEY.MEDIATRACKNEXT     : status = true; break;
        case UTILS.KBD.KEY.MEDIATRACKPREVIOUS : status = true; break;
        case UTILS.KBD.KEY.OS                 : status = true; break;
        case UTILS.KBD.KEY.PAGEDOWN           : status = true; break;
        case UTILS.KBD.KEY.PAGEUP             : status = true; break;
        case UTILS.KBD.KEY.TAB                : status = true; break;
        case UTILS.KBD.KEY.SHIFT              : status = true; break;
      // add cases to handle other command keys
      }

      return status;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandlePress (event=undefined) {
    /************************************************************************************
    * The function which handles command keys for the ekkoe process 
    ************************************************************************************/
      let that = this;
      let Command = UTILS.Link (GetKeyFunction, [event.key, PRESS], that);

      return UTILS.Link (Command, [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandleRelease (event=undefined) {
    /************************************************************************************
    * The function which handles release keys for the ekkoe process 
    ************************************************************************************/
      let that    = this;
      let Command = UTILS.Link (GetKeyFunction, [event.key, RELEASE], that);

      return UTILS.Link (Command, [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefineCommandKeyFunctions () {

    Action [UTILS.KBD.KEY.INTERNALCALL] = function () {
    /************************************************************************************
    * The function which performs arbitrary tasks wherever ...
    ************************************************************************************/
      let that = this;

      console.log ("[ internal call: ", FILE [0], " ]");

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.OS] = function () {
    /************************************************************************************
    * The function which ...
    ************************************************************************************/
      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.ALT] = function (event=undefined) {
      let that = this;

      ALTDOWN = true;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.ALTGRAPH] = function (event=undefined) {
      let that = this;

      ALTDOWN = true;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.ARROWLEFT] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the left
    ************************************************************************************/
      let that    = this;
      let ArrowUp = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWUP, PRESS], that);
      let End     = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, RELEASE], that);

      if (CONTROLDOWN) {
        let LEFT = 0;

        if (CURSOR === 0) {
          let ArrowLeft      = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWLEFT, PRESS], that);
          let PressControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, PRESS], that);
          let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, RELEASE], that);

          UTILS.Link (ReleaseControl);
          UTILS.Link (ArrowLeft, null, that); 
          UTILS.Link (PressControl);
        }
        else {
          CURSOR = UTILS.Link (SkipWordMoveCursor, [LEFT], that);
          if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        }
      }
      else {
        if (CURSOR > 0) {
          CURSOR = CURSOR - 1;
          if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        }
        else {
          let scrollLockActive = SCROLLLOCK;
          let ScrollLock       = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, RELEASE], that);

          if (scrollLockActive) { UTILS.Link (ScrollLock); }

          UTILS.Link (ArrowUp, null, that);

          if (scrollLockActive) { UTILS.Link (ScrollLock); }
        }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.ARROWUP] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the next line above 
    ************************************************************************************/
      let that = this;

      if (SCROLLLOCK && !CONTROLDOWN) {
        event.deltaY = -3;
        UTILS.Link (MouseWheelScrollHandler, [event], that);
      }
      else if (SHIFTDOWN && CONTROLDOWN) {
        let tmpline      = undefined;
        let currentline  = LINE;
        let previousline = currentline - 1;

        if (previousline >= 0) {
          tmpline = FILE [previousline];
          FILE [previousline] = FILE [currentline];
          FILE [currentline] = tmpline;
          LINE = previousline;

          if (LINE < FILESEGBEGIN) { FILESEGBEGIN = LINE; }
        }
      }
      else {
        let count = 0;
        let lastline = FILE.length - 1;

        if (LINE > 0) {
          LINE = LINE - 1;
          CURSOR = FILE [LINE].length;

          if (LINE < FILESEGBEGIN) { FILESEGBEGIN = LINE; }
          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.ARROWDOWN] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the next line below
    ************************************************************************************/
      let that = this;

      if (SCROLLLOCK && !CONTROLDOWN) {
        event.deltaY = 3;
        UTILS.Link (MouseWheelScrollHandler, [event], that);
      }
      else if (SHIFTDOWN && CONTROLDOWN) {
        let currentline = LINE;
        let nextline = currentline + 1;
        let tmpline = undefined;

        if (nextline < FILE.length) {
          tmpline = FILE [nextline];
          FILE [nextline] = FILE [currentline];
          FILE [currentline] = tmpline;
          LINE = nextline;

          if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
        }
      }
      else {
        let lastline = FILE.length - 1;

        if ((LINE + 1) < FILE.length) {
          LINE = LINE + 1;
          CURSOR = FILE [LINE].length;
        }

        if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.ARROWRIGHT] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the right 
    ************************************************************************************/
      let that      = this;
      let ArrowDown = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWDOWN, PRESS], that);
      let Home      = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.HOME, RELEASE], that);

      if (CONTROLDOWN) {
        let RIGHT = 1;

        if (CURSOR === FILE [LINE].length) {
          let ArrowRight     = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWRIGHT, PRESS], that);
          let PressControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, PRESS], that);
          let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, RELEASE], that);

          UTILS.Link (ReleaseControl);
          UTILS.Link (ArrowRight, null, that);
          UTILS.Link (PressControl);
        }
        else {
          CURSOR = UTILS.Link (SkipWordMoveCursor, [RIGHT], that);
          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        }
      }
      else {
        if (CURSOR < FILE [LINE].length) {
          CURSOR = CURSOR + 1;
          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        }
        else {
          let scrollLockActive = SCROLLLOCK;
          let ScrollLock       = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, RELEASE], that);

          if (scrollLockActive) { UTILS.Link (ScrollLock); }

          UTILS.Link (ArrowDown, null, that);

          if (scrollLockActive) { UTILS.Link (ScrollLock); }

          UTILS.Link (Home, null, that);
        }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.BACKSPACE] = function (event=undefined) {
      let that = this;

      if (SHIFTDOWN) {
        let Backspace    = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, PRESS], that);
        let DeleteLine   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.F9, RELEASE], that);
        let PressShift   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, PRESS], that);
        let ReleaseShift = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, RELEASE], that);

        UTILS.Link (ReleaseShift);
        UTILS.Link (DeleteLine, null, that);
        UTILS.Link (Backspace, null, that);
        UTILS.Link (PressShift);
      }
      else {
        let line = FILE [LINE];
        let leftbit = undefined;
        let midbit = undefined;
        let rightbit = undefined;

        if (CURSOR > 0) {
          line = FILE [LINE].substring (0, CURSOR - 1);
          line = line + FILE [LINE].substring (CURSOR, FILE [LINE].length);
          FILE [LINE] = line;
          CURSOR = CURSOR - 1;

          if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        }
        else if (LINE > 0) {
          leftbit = FILE.splice (0, LINE);
          midbit = FILE.splice (0,1);
          rightbit = FILE.splice (0);
          FILE = leftbit.concat (rightbit);
          LINE = LINE - 1;
          CURSOR = FILE [LINE].length;
          FILE [LINE] = FILE [LINE] + midbit;

          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          if (FILE.length <= VIEWCAPACITY) {
            FILESEGEND = FILESEGEND - 1;
            if ((FILESEGBEGIN - 1) >= 0) { FILESEGBEGIN = FILESEGBEGIN - 1; }
          }
        }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.CONTEXTMENU] = function (event=undefined) {
      let that = this;

      that.preventDefault  = false;
      that.stopPropagation = false;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.CONTROL] = function (event=undefined) {
      let that = this;

      CONTROLDOWN = true;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.DELETE] = function (event=undefined) {
    /************************************************************************************
    * The function which removes one character to the right of the cursor
    ************************************************************************************/
      let that = this;
      let line = FILE [LINE];

      if (CURSOR < line.length) {
        line = FILE [LINE].substring (0, CURSOR);
        line = line + FILE [LINE].substring (CURSOR + 1, FILE [LINE].length);
        FILE [LINE] = line;

        if (CURSOR > FILE [LINE].length) {
          CURSOR -= 1;
        }
      }
      else {
        let shiftKeyDown     = SHIFTDOWN;
        let scrollLockActive = SCROLLLOCK;
        let ScrollLock       = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, RELEASE], that);
        let ArrowDown        = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWDOWN, PRESS], that);
        let Backspace        = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, PRESS], that);
        let Home             = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.HOME, RELEASE], that);
        let ReleaseShift     = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, RELEASE], that);
        let PressShift       = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, PRESS], that);

        if (scrollLockActive) { UTILS.Link (ScrollLock); }
        if (shiftKeyDown) { UTILS.Link (ReleaseShift); }

        UTILS.Link (ArrowDown, null, that);

        if (scrollLockActive) { UTILS.Link (ScrollLock); }

        UTILS.Link (Home, null, that);
        UTILS.Link (Backspace, null, that);

        if (shiftKeyDown) { UTILS.Link (PressShift); }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.ENTER] = function () {
    /************************************************************************************
    * The function which moves the cursor to the next line
    ************************************************************************************/
      let that         = this;
      let leftbit      = undefined;
      let rightbit     = undefined;
      let leftsubline  = undefined;
      let rightsubline = undefined;
      let START        = 0;

      leftbit  = FILE.splice (START, LINE);
      rightbit = FILE.splice (START);

      leftbit.push (UTILS.BLANKCHAR);

      leftsubline                  = rightbit [START].substring (START, CURSOR);
      rightsubline                 = rightbit [START].substring (CURSOR, rightbit [START].length);
      leftbit [leftbit.length - 1] = leftsubline;
      rightbit [START]             = rightsubline;
      FILE                         = leftbit.concat (rightbit);
      CURSOR                       = START;
      LINESTART                    = CURSOR;
      LINE                         = LINE + 1;

      if (FILE.length <= VIEWCAPACITY) { FILESEGEND = FILESEGEND + 1; }
      else if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.F1] = function () {
    /************************************************************************************
    * The function which displays the help text for the ekkoe process
    ************************************************************************************/
      let that   = this;
      let helper = EXPLAIN + that.id;

      FILE [LINE] = FILE [LINE] + helper;
      CURSOR      = FILE [LINE].length;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.F11] = function () {
    /************************************************************************************
    * The function which requests maximum screen for the ekkoe process
    ************************************************************************************/
      let that = this;
      that.preventDefault = false;
      //UTILS.Link (LaunchFullscreen, null, that);
      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.TAB] = function (event=undefined) {
    /************************************************************************************
    * The function which adds a tab-equivalent-of-spaces to the current line
    ************************************************************************************/
      let that = this;
      let fakeEvent = Object.create (null);

      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
      UTILS.Link (UTILS.MapKeyValue, [fakeEvent, "key", UTILS.KBD.KEY.WHITESPACE]);

      for (let i = 0; i < TABSIZE; i ++) { UTILS.Link (HandlePrint, [fakeEvent], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.PAGEDOWN] = function (event=undefined) {
    /************************************************************************************
    * The function which increases the length of the kanvas
    ************************************************************************************/
      let that = this;

           if (ALTDOWN)     { UTILS.Link (PAINTER.ChangeCanvasHeightBy, [2]); }
      else if (SHIFTDOWN)   { UTILS.Link (PAINTER.ChangeCanvasWidthBy, [2]); }
      else if (CONTROLDOWN) { UTILS.Link (PAINTER.HideCanvas); }
      else {
        let nextPage = (2 * VIEWCAPACITY) + 1;

        for (let i = 0; (i < nextPage) && (LINE + 1 < FILE.length); i ++) {
          LINE = LINE + 1;
        }

        if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }

        CURSOR = FILE [LINE].length;

        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.PAGEUP] = function (event=undefined) {
    /************************************************************************************
    * The function which increases the length of the kanvas
    ************************************************************************************/
      let that = this;

           if (ALTDOWN)     { UTILS.Link (PAINTER.ChangeCanvasHeightBy, [-2]); }
      else if (SHIFTDOWN)   { UTILS.Link (PAINTER.ChangeCanvasWidthBy, [-2]); }
      else if (CONTROLDOWN) { UTILS.Link (PAINTER.ShowCanvas); }
      else {
        let nextPage = (2 * VIEWCAPACITY) + 1;

        for (let i = 0; (i < nextPage) && (LINE > 0); i ++) { LINE = LINE - 1; }

        if (LINE < FILESEGBEGIN) { FILESEGBEGIN = LINE; }

        CURSOR = FILE [LINE].length;

        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action [UTILS.KBD.KEY.SHIFT] = function (event=undefined) {
      let that = this;

      SHIFTDOWN = true;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.ALT] = function (event) {
      let that = this;

      ALTDOWN = false;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.ALTGRAPH] = function (event) {
      let that = this;

      ALTGRAPHDOWN = false;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.CONTROL] = function (event) {
      let that = this;

      CONTROLDOWN = false;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.END] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the end of the line
    ************************************************************************************/
      let that = this;

      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

      if (CONTROLDOWN) {
        LINE = FILE.length - 1;

        if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
      }

      CURSOR = FILE [LINE].length;

      if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.ESCAPE] = EXIT;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.F2] = function () {
      let that           = this;
      let filename       = UTILS.Link (FILEMANAGER.GetFileName);
      let End            = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, RELEASE], that);
      let Enter          = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ENTER, PRESS], that);
      let PressControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, PRESS], that);
      let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, RELEASE], that);
      let ctrlKeyDown    = UTILS.Link (GetControlState);

      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

      if (!ctrlKeyDown) { UTILS.Link (PressControl); }

      UTILS.Link (End, null, that);

      if (!ctrlKeyDown) { UTILS.Link (ReleaseControl); }

      UTILS.Link (Enter, null, that);

      FILE [LINE] = filename;

      UTILS.Link (End, null, that);

      if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
      else { LINESTART = 0; }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.F8] = function (event = undefined) {
      let that = this;

      if (CONTROLDOWN) {
        let End   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, RELEASE], that);
        let Enter = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ENTER, PRESS], that);

        UTILS.Link (End, null, that);
        UTILS.Link (Enter, null, that);

        FILE [LINE] = UTILS.WIN.SYS.location.href;
        CURSOR = FILE [LINE].length;

        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        else { LINESTART = 0; }
      }
      else {
        let url     = undefined;
        let urlline = FILE [FILE.length - 1].trim ();

        urlline = urlline.split (UTILS.KBD.KEY.WHITESPACE);
        urlline = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, urlline]);
        urlline = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, urlline]);
        url     = urlline [0];

        UTILS.WIN.SYS.location.assign (url);
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.F9] = function () {
      let that = this;

      FILE [LINE] = UTILS.BLANKCHAR;
      CURSOR = 0;
      LINESTART = 0;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.F10] = function () {
      let that = this;

      CURSOR = 0;
      LINE   = 0;
      FILE   = new Array (UTILS.BLANKCHAR);

      UTILS.Link (MapKeyValue, [that, "requireRewrite", true]);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.HOME] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the beginning of the line
    ************************************************************************************/
      let that = this;

      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

      if (CONTROLDOWN) {
        LINE = 0;
        FILESEGBEGIN = 0;
      }

      CURSOR = 0;

      if (CURSOR < LINESTART) { LINESTART = CURSOR; }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.INSERT] = function (event=undefined) {
      let that = this;

      INSERT = !INSERT;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.SHIFT] = function (event) {
      let that = this;

      SHIFTDOWN = false;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Release [UTILS.KBD.KEY.SCROLLLOCK] = function (event=undefined) {
      let that = this;

      SCROLLLOCK = !SCROLLLOCK;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandlePrint (event=undefined) {
    /************************************************************************************
    * The function which handles printable character keys for the ekkoe process 
    ************************************************************************************/
      let that = this;
      let Delete = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.DELETE, PRESS], that);
      let PrintKey = UTILS.Link (GetKeyFunction, [event.key], that);

      if (INSERT && (CURSOR < FILE [LINE].length)) { UTILS.Link (Delete, null, that); }

      return UTILS.Link (PrintKey, [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

   function PrintCharacter (key=undefined) {
      let that          = this;
      let currentline   = undefined;
      let endOfThisLine = undefined;
      let subline       = undefined;

      FILE          = UTILS.Link (FILEMANAGER.GetFile, [WHOLE]);
      currentline   = FILE [LINE];
      endOfThisLine = currentline.length;
      subline       = currentline.substring (0, CURSOR);
      FILE [LINE]   = subline + key;
      subline       = currentline.substring (CURSOR, endOfThisLine);
      FILE [LINE]   = FILE [LINE] + subline;
      CURSOR        = CURSOR + key.length;

      if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefinePrintKeyFunctions () {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.TWIDDLE] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.BACKTICK] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_1] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.EXCLAMATION] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_2] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.AT] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_3] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.HASH] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_4] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.DOLLAR_SIGN] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_5] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.PERCENTAGE_SIGN] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_6] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.CARET] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_7] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.AMPERSAND] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_8] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.ASTERISK] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_9] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.OPEN_PAREN] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.NUM_0] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.CLOSE_PAREN] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.MINUS_SIGN] = function (event) {
      let that      = this;
      let deltaSize = -1;

      if (CONTROLDOWN) { UTILS.Link (UpdateFontSize, [deltaSize], that); }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UNDERSCORE] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.EQUALS_SIGN] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.PLUS_SIGN] = function (event) {
      let that      = this;
      let deltaSize = 1;

      if (CONTROLDOWN) { UTILS.Link (UpdateFontSize, [deltaSize], that); }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_Q] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_Q] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_W] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_W] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_E] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_E] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_R] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_R] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_T] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

     Printable [UTILS.KBD.KEY.LOWERCASE_T] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_Y] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_Y] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_U] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_U] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_I] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_I] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_O] = function (event) {
      let that = this;

      if (CONTROLDOWN) {
        let lastline = FILE.length - 1;
        let filename = FILE [lastline].trim ();
        UTILS.Link (FILEMANAGER.Read, [filename], that);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_O] = function (event) {
      let that = this;

      if (CONTROLDOWN) {
        let lastline = FILE.length - 1;
        let filename = FILE [lastline].trim ();
        UTILS.Link (FILEMANAGER.Read, [filename], that);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_P] = function (event) {
      let that = this;

      if (CONTROLDOWN) {
        that.preventDefault   = false;
        that.stopPropagation  = false;
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_P] = function (event) {
      let that = this;

      if (CONTROLDOWN) {
        that.preventDefault   = false;
        that.stopPropagation  = false;
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.OPEN_BRACKET] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.OPEN_BRACE] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.CLOSE_BRACKET] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.CLOSE_BRACE] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.BACKSLASH] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.PIPE] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_A] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_A] = function (event) {
      let that = this;
      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_S] = function (event) {
      let that = this;

      if (CONTROLDOWN) {
        let newfile      = FILE [FILE.length - 1].trim ();
        let Backspace    = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, PRESS], that);
        let End          = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, RELEASE], that);
        let shiftKeyDown = SHIFTDOWN;
        let PressShift   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, PRESS], that);
        let ReleaseShift = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, RELEASE], that);

        if (!shiftKeyDown) { UTILS.Link (PressShift); }

        UTILS.Link (End, null, that);
        UTILS.Link (Backspace, null, that);

        if (!shiftKeyDown) { UTILS.Link (ReleaseShift); }

        CURSOR = FILE [LINE].length;

        UTILS.Link (FILEMANAGER.Write, [newfile], that);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_S] = function (event) {
      let that = this;

      if (CONTROLDOWN) { UTILS.Link (FILEMANAGER.Write, null, that); }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_D] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_D] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_F] = function (event) {
      let that = this;

      if (CONTROLDOWN) {
        let keyword     = FILE [FILE.length - 1];
        let currentline = LINE;

        if (currentline > 0) { currentline = currentline - 1; }
        else /*************/ { currentline = FILE.length - 1; }

        for (let i = currentline; i > -1; i = (i - 1)) {
          i = UTILS.Link (ThoroughSearch, [keyword, UTILS.BLANKCHAR, i, -1], that);
        }
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ThoroughSearch (keyword=undefined, blank=undefined, linenumber=undefined, eof=undefined) {
      let that        = this;
      let wordchars   = FILE [linenumber].split (blank);
      let k           = keyword.length;
      let searchstart = 0;

      for (let j = searchstart; (wordchars.length >= k) && (j + k <= wordchars.length); j ++) {
        let comparisonString = FILE [linenumber].substring (j, j + k);

        if (keyword === comparisonString) {
          LINE   = linenumber;
          CURSOR = j + k;
          j           = wordchars.length;
          linenumber  = eof;
        }
      }

      return linenumber;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_F] = function (event) {
      let that = this;

      if (CONTROLDOWN) { 
        let keyword     = FILE [FILE.length - 1];
        let currentline = LINE;

        if ((currentline + 1) < FILE.length) {
          currentline = currentline + 1;
        }
        else { currentline = 0; }

        for (let i = currentline; i < FILE.length; i = (i + 1)) {
          i = UTILS.Link (ThoroughSearch, [keyword, UTILS.BLANKCHAR, i, FILE.length], that);
        }
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_G] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_G] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_H] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_H] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_J] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_J] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_K] = function (event) {
      let that = this;

      if (CONTROLDOWN) {
        let currentline = FILE [LINE];
        FILE.push (UTILS.BLANKCHAR);
        FILE.push (currentline);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_K] = function (event) {
      let that = this;

      if (CONTROLDOWN) {
        let PasteLineAfterLast = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.UPPERCASE_K], that);

        UTILS.Link (PasteLineAfterLast, null, that);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_L] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_L] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.SEMICOLON] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.COLON] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.SINGLE_QUOTE_A1] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.DOUBLE_QUOTE_A1] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_Z] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_Z] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_X] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_X] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_C] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_C] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_V] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_V] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_B] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_B] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_N] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_N] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.UPPERCASE_M] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LOWERCASE_M] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.COMMA] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.LESS_THAN_SIGN] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.FULL_STOP] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.GREATER_THAN_SIGN] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.FORWARDSLASH] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.QUESTIONMARK] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.WHITESPACE] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.DOUBLE_QUOTE_B1] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [UTILS.KBD.KEY.DOUBLE_QUOTE_B2] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¹"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¥"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["£"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["€"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ł"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ë"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ê"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ṱ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["û"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ü"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ï"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ö"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ä"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["š"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ḓ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["đ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ŋ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ħ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ĸ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ḽ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["«"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["»"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¢"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ṋ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ṅ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¬"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¡"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["⅛"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["⅜"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["⅝"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["⅞"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["™"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["±"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["°"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¿"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ω"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ł"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ë"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ê"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ṱ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Û"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ü"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ï"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ö"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ô"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ä"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Š"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ḓ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ª"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ŋ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ħ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ḽ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["©"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["‘"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["’"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ṋ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ṅ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["×"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["÷"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define event handlers below
  ************************************************************************************/

    function KeydownHandler (event=undefined) {
      let that = this;

      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
      UTILS.Link (RetrieveFile);
      UTILS.Link (RetrieveFileLine);
      UTILS.Link (RetrieveFileCursor);
      UTILS.Link (RetrieveSegmentBegin);
      UTILS.Link (RetrieveSegmentEnd);
      UTILS.Link (RetrieveLineStart);

      if (UTILS.Link (InvisibleCharacter, [event.key], null)) {
        if (UTILS.Link (CommandCharacter, [event.key], null)) {
          UTILS.Link (HandlePress, [event], that);
        }
      }
      else { UTILS.Link (HandlePrint, [event], that); }

      UTILS.Link (PersistSegmentBegin);
      UTILS.Link (PersistSegmentEnd);
      UTILS.Link (PersistLineStart);

      if (that.requireRewrite) { UTILS.Link (ReWrite, null, that); }
      if (that.preventDefault) { UTILS.Link (event.preventDefault, null, event); }
      if (that.stopPropagation) { UTILS.Link (event.stopPropagation, null, event); }

      UTILS.Link (PersistFile);
      UTILS.Link (PersistFileLine);
      UTILS.Link (PersistFileCursor);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function KeyupHandler (event=undefined) {
      let that = this;
      let executableCommand = false;

      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
      UTILS.Link (RetrieveFile);
      UTILS.Link (RetrieveFileLine);
      UTILS.Link (RetrieveFileCursor);
      UTILS.Link (RetrieveSegmentBegin);
      UTILS.Link (RetrieveSegmentEnd);
      UTILS.Link (RetrieveLineStart);

      switch (event.key) {
        case UTILS.KBD.KEY.ALT       : executableCommand = true; break;
        case UTILS.KBD.KEY.ALTGRAPH  : executableCommand = true; break;
        case UTILS.KBD.KEY.CONTROL   : executableCommand = true; break;
        case UTILS.KBD.KEY.END       : executableCommand = true; break;
        case UTILS.KBD.KEY.ESCAPE    : executableCommand = true; break;
        case UTILS.KBD.KEY.F2        : executableCommand = true; break;
        case UTILS.KBD.KEY.F8        : executableCommand = true; break;
        case UTILS.KBD.KEY.F9        : executableCommand = true; break;
        case UTILS.KBD.KEY.F10       : executableCommand = true; break;
        case UTILS.KBD.KEY.HOME      : executableCommand = true; break;
        case UTILS.KBD.KEY.INSERT    : executableCommand = true; break;
        case UTILS.KBD.KEY.SHIFT     : executableCommand = true; break;
        case UTILS.KBD.KEY.SCROLLLOCK: executableCommand = true; break;
      }

      if (executableCommand) {UTILS.Link (HandleRelease, [event], that); }

      UTILS.Link (PersistSegmentBegin);
      UTILS.Link (PersistSegmentEnd);
      UTILS.Link (PersistLineStart);

      if (that.requireRewrite) { UTILS.Link (ReWrite, null, that); }
      if (that.preventDefault) { UTILS.Link (event.preventDefault, null, event); }
      if (that.stopPropagation) { UTILS.Link (event.stopPropagation, null, event); }

      UTILS.Link (PersistFile);
      UTILS.Link (PersistFileLine);
      UTILS.Link (PersistFileCursor);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ResizeHandler (event) {
      let that = this;

      UTILS.Link (PAINTER.SetCanvasHeightTo, [UTILS.WIN.SYS.innerHeight - 20]);
      UTILS.Link (PAINTER.SetCanvasWidthTo, [UTILS.WIN.SYS.innerWidth - 20]);

      RMARGIN = UTILS.Link (PAINTER.GetCanvasWidth) - 10*LMARGIN;

      UTILS.Link (VIEWPORT.SetRightMargin, [RMARGIN]);
      UTILS.Link (ReWrite, null, that);
    }


  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LaunchFullscreen () {
      let that    = this;
      let element = UTILS.WIN.DOC.documentElement;

      if (element.requestFullscreen      ) { element.requestFullscreen      (); } else
      if (element.mozRequestFullScreen   ) { element.mozRequestFullScreen   (); } else
      if (element.webkitRequestFullscreen) { element.webkitRequestFullscreen(); } else
      if (element.msRequestFullscreen    ) { element.msRequestFullscreen    (); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ExitFullscreen () {
      if (UTILS.WIN.DOC.exitFullscreen      ) { UTILS.WIN.DOC.exitFullscreen      (); } else
      if (UTILS.WIN.DOC.mozCancelFullScreen ) { UTILS.WIN.DOC.mozCancelFullScreen (); } else
      if (UTILS.WIN.DOC.webkitExitFullscreen) { UTILS.WIN.DOC.webkitExitFullscreen(); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MouseWheelScrollHandler (event=undefined) {
      let that         = this;
      let SCROLLAMOUNT = 3;
      let deltaSize    = -event.deltaY;

      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

      if (SCROLLLOCK && !CONTROLDOWN) {
        SCROLLAMOUNT = 1;
      }

      if (CONTROLDOWN) { UTILS.Link (UpdateFontSize, [deltaSize], that); }
      else if (deltaSize < 0) {
        for (let o = 0; (o < SCROLLAMOUNT); o ++) {
        }
      }
      else {
        for (let o = 0; (o < SCROLLAMOUNT); o ++) {
        }
      }

      if (that.requireRewrite) { UTILS.Link (ReWrite, null, that); }

      event.preventDefault ();
      event.stopPropagation ();

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UpdateFontSize (amount=undefined) {
      let that      = this;
      let fontUnits = UTILS.BLANKCHAR;
      let fontArray = FONT.split (UTILS.KBD.KEY.WHITESPACE);
      let fontSize  = fontArray [0].split (UTILS.BLANKCHAR);
      let deltaSize = amount / amount;
      let tmpFont   = undefined;

      fontUnits = fontSize.pop () + fontUnits;
      fontUnits = fontSize.pop () + fontUnits;
      fontSize  = fontSize.join (UTILS.BLANKCHAR);
      fontSize  = UTILS.Link (UTILS.ToNumber, [undefined, fontSize]);

      if (amount < 0) { deltaSize = -1 * deltaSize; }

      fontSize   = fontSize + deltaSize;
      tmpFont    = fontSize + fontUnits + UTILS.KBD.KEY.WHITESPACE + fontArray [1];

      UTILS.Link (SetLineHeight, [LINEHEIGHT + deltaSize]);
      UTILS.Link (SetFont, [tmpFont]);
//      UTILS.Link (CalculateViewCapacity);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetFgColor (color=undefined) {
      let that = this;
      FGCOLOR = color;
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetFont (font=undefined) {
      let that = this;
      FONT = font;
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetKeyFunction (key=undefined, keyHandler=undefined, index=undefined) {
      let that = this;

      if (UTILS.Link (InvisibleCharacter, [key])) {
        if (index === PRESS) { that.Action [key] = keyHandler; }
        else if (index === RELEASE) { that.Release [key] = keyHandler; }
      }
      else { that.Printable [key] = keyHandler; }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetLineHeight (height=undefined) {
      let that = this;
      LINEHEIGHT = height;
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetAltState () { return ALTDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetAltGraphState () { return ALTGRAPHDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetControlState () { return CONTROLDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFgColor () { return FGCOLOR; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFont () { return FONT; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetKeyFunction (key=undefined, index=undefined) {
      let that       = this;
      let keyHandler = undefined;

      if (UTILS.Link (InvisibleCharacter, [key])) {
        if (index === PRESS) { keyHandler = that.Action [key]; }
        else if (index === RELEASE) { keyHandler = that.Release [key]; }
      }
      else { keyHandler = that.Printable [key]; }

      return keyHandler;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetLineHeight () { return LINEHEIGHT; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetScrollLockState () { return SCROLLLOCK; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetShiftState () { return SHIFTDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CalculateViewCapacity () {
      let that = this;

      BMARGIN      = UTILS.Link (PAINTER.GetCanvasHeight) - 2 * LINEHEIGHT;
      VIEWCAPACITY = (BMARGIN - (BMARGIN % LINEHEIGHT)) / LINEHEIGHT;

      return undefined;
    }    

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFile () { UTILS.Link (FILEMANAGER.SetFile, [WHOLE, FILE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFileCursor () { UTILS.Link (FILEMANAGER.SetFileCursor, [CURSOR]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFileLine () { UTILS.Link (FILEMANAGER.SetFileLine, [LINE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistSegmentBegin () { UTILS.Link (VIEWPORT.SetSegmentBegin, [FILESEGBEGIN]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistSegmentEnd () { UTILS.Link (VIEWPORT.SetSegmentEnd, [FILESEGEND]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistLineStart () { UTILS.Link (VIEWPORT.SetLineStart, [LINESTART]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFile () { FILE = UTILS.Link (FILEMANAGER.GetFile, [WHOLE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFileCursor () { CURSOR = UTILS.Link (FILEMANAGER.GetFileCursor); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFileLine () { LINE = UTILS.Link (FILEMANAGER.GetFileLine); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveSegmentBegin () { FILESEGBEGIN = UTILS.Link (VIEWPORT.GetSegmentBegin); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveSegmentEnd () { FILESEGEND = UTILS.Link (VIEWPORT.GetSegmentEnd); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveLineStart () { LINESTART = UTILS.Link (VIEWPORT.GetLineStart); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
    /************************************************************************************
    * The function which destroys the ekkoe process
    ************************************************************************************/
      let that = this;

      while (that.stack.size > 0) {
        UTILS.Link (STACK.Pop, null, that.stack);
        that.stack.popped.abort ();
      }

      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.KBD.KEY.DOWN, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.KBD.KEY.UP, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.WIN.RESIZE, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.MWS.WHEEL, UTILS.Link (PAINTER.GetCanvas)], that.Action);
      UTILS.Link (PAINTER.Destroy, null, that.painter);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;

      Action        = Object.create (null);
      Printable     = Object.create (null);
      Release       = Object.create (null);
      ALTDOWN       = false;
      ALTGRAPHDOWN  = false;
      CONTROLDOWN   = false;
      EXPLAIN       = "explain";
      INSERT        = false;
      LINEHEIGHT    = 17;
      PRESS         = 0;
      RELEASE       = 1;
      WHOLE         = -1;
      SCROLLLOCK    = false;
      SHIFTDOWN     = false;
      TABSIZE       = 2;
      UTILS         = Utils;
      VIEWCAPACITY  = 0;
      VIEWPORT      = ViewPort;

      UTILS.Link (DefineCommandKeyFunctions);
      UTILS.Link (DefinePrintKeyFunctions);
      UTILS.Link (UTILS.MapKeyValue, [that, "Create", Create]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Action", Action]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Destroy", Destroy]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistFile", PersistFile]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistFileCursor", PersistFileCursor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistFileLine", PersistFileLine]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistSegmentBegin", PersistSegmentBegin]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistSegmentEnd", PersistSegmentEnd]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistLineStart", PersistLineStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Printable", Printable]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Release", Release]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveFile", RetrieveFile]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveFileCursor", RetrieveFileCursor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveFileLine", RetrieveFileLine]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveSegmentBegin", RetrieveSegmentBegin]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveSegmentEnd", RetrieveSegmentEnd]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveLineStart", RetrieveLineStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "ReWrite", ReWrite]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetFgColor", SetFgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetFont", SetFont]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetKeyFunction", SetKeyFunction]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetLineHeight", SetLineHeight]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetAltState", GetAltState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetAltGraphState", GetAltGraphState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetControlState", GetControlState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetFgColor", GetFgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetFont", GetFont]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetKeyFunction", GetKeyFunction]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetLineHeight", GetLineHeight]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetScrollLockState", GetScrollLockState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetShiftState", GetShiftState]);

      return Object.create (that);
    }

    return Utils.Link (Objectify, null, ekkoe);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Ekkoe = utils.Link (MakeEkkoeName, [utils, viewport], ekkoespace);

  return Ekkoe;
}