/****************************************************************
    Geometer inteprets mathematical structures for the geometry 
    application in the ASH suite.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2018 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeGeometerNameSpace (utils, decimal) {
  "use strict";

  let geometerspace = Object.create (null);
  let Geometer      = undefined;

  function MakeGeometerName (Utils=undefined, Decimal=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let geometer    = Object.create (null);
    let ABSCISSA    = undefined;
    let ARC         = undefined;
    let DECIMAL     = Decimal;
    let BGCOLOR     = undefined;
    let GRID        = undefined;
    let GRID_CONST  = undefined;
    let GRID_INFO   = undefined;
    let GRAPH       = undefined;
    let GRAPHSIZE   = undefined;
    let LINEARANGLE = undefined;
    let LINEWIDTH   = undefined;
    let ORDINATE    = undefined;
    let PAINTER     = undefined;
    let STRUCTURE   = undefined;
    let UTILS       = Utils;
    let VECTOR      = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=undefined) {
      let that = this;

      ARC         = "arc";
      ABSCISSA    = UTILS.KBD.KEY.LOWERCASE_X;
      BGCOLOR     = info.bgcolor;
      GRAPH       = "graph";
      GRID        = info.grid;
      GRID_CONST  = "grid";
      GRID_INFO   = Object.create (null);
      LINEARANGLE = 180;
      ORDINATE    = UTILS.KBD.KEY.LOWERCASE_Y;
      PAINTER     = info.painter;
      STRUCTURE   = Object.create (null);
      VECTOR      = "vector";

      UTILS.Link (UTILS.MapKeyValue, [GRID_INFO, "painter", info.painter]);
      UTILS.Link (UTILS.MapKeyValue, [GRID_INFO, "unit", info.unit]);
      UTILS.Link (UTILS.MapKeyValue, [GRID_INFO, "skew", info.skew]);
      UTILS.Link (UTILS.MapKeyValue, [that, "cartesianplane", Object.create (null)]);
      UTILS.Link (UTILS.MapKeyValue, [STRUCTURE, ARC, true]);
      UTILS.Link (UTILS.MapKeyValue, [STRUCTURE, GRID_CONST, true]);
      UTILS.Link (UTILS.MapKeyValue, [STRUCTURE, GRAPH, true]);
      UTILS.Link (UTILS.MapKeyValue, [STRUCTURE, VECTOR, true]);

      UTILS.Link (GRID.Create, [GRID_INFO], that.cartesianplane);
      UTILS.Link (Customize, null, that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatgeometer = this;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function AddHandlerFor (EventName=undefined, EventHandlerFunction=undefined) {
      let that = this;
      let EventHandler = undefined;

      switch (EventName) {
        case "mousemove":
          EventHandler = EventHandlerFunction;
          that.mouseMoveHandler = EventHandler;
        break;
      }

      window.addEventListener (EventName, EventHandler, false);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RemoveHandlerFor (EventName=undefined) {
      let that = this;
      let EventHandler = undefined;

      switch (EventName) {
        case "mousemove":
          EventHandler = that.mouseMoveHandler;
        break;
      }

      window.removeEventListener (EventName, EventHandler, false);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ClearBackground () {
      let that = this;

      that.requireRewrite = false;

      UTILS.Link (PAINTER.SetFillColorTo, [BGCOLOR]); 
      UTILS.Link (PAINTER.PaintBackGround);
      UTILS.Link (GRID.FindOrigin      , null, that.cartesianplane);
      UTILS.Link (GRID.FindMinMaxRange , null, that.cartesianplane);
      UTILS.Link (GRID.FindMinMaxDomain, null, that.cartesianplane);

       return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DrawGrid (definition=undefined) {
      let that            = this;
      let skew            = Object.create (null);
      let COLOR           = 2;
      let LINEWIDTH       = 3;
      let UNITS           = 0;
      let rebuiltgraph    = UTILS.Link (RebuildGraph, [definition, 4]);
      let coordinates     = UTILS.Link (StripCoordinates, [rebuiltgraph, 4]);
      let formerCOLOR     = UTILS.Link (PAINTER.GetStrokeColor);
      let formerLINEWIDTH = UTILS.Link (PAINTER.GetBrushSize);

      GRID_INFO.unit [ABSCISSA] = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [UNITS][0]]);
      GRID_INFO.unit [ORDINATE] = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [UNITS][1]]);
      LINEWIDTH                 = UTILS.Link (UTILS.ToNumber, [DECIMAL, definition [LINEWIDTH]]);
      COLOR                     = definition [COLOR];

      UTILS.Link (PAINTER.BeginPath);
      UTILS.Link (PAINTER.SetStrokeColorTo, [COLOR]);
      UTILS.Link (PAINTER.SetBrushSizeTo, [LINEWIDTH]);
      UTILS.Link (GRID.Create, [GRID_INFO], that.cartesianplane);
      UTILS.Link (GRID.DrawPlane, null, that.cartesianplane);
      UTILS.Link (PAINTER.StrokePath);
      UTILS.Link (PAINTER.ClosePath);
      UTILS.Link (PAINTER.SetStrokeColorTo, [formerCOLOR]);
      UTILS.Link (PAINTER.SetBrushSizeTo, [formerLINEWIDTH]);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DrawArc (definition=undefined) {
      let that           = this;
      let COLOR          = 2;
      let LINEWIDTH      = 3;
      let ORIENTATION    = 4;
      let clockwise      = undefined;
      let circumferenceH = undefined;
      let circumferenceV = undefined;
      let oldX           = undefined;
      let oldY           = undefined;
      let point          = undefined;
      let formerLINECAP  = UTILS.Link (PAINTER.GetCurrentLineCap);
      let rebuiltgraph   = UTILS.Link (RebuildGraph, [definition, 5]);
      let coordinates    = UTILS.Link (StripCoordinates, [rebuiltgraph, 5]);
      let centerX        = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [0][0]]);
      let centerY        = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [0][1]]) * -1;
      let radiusH        = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [1][0]]);
      let radiusV        = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [1][1]]);
      let startRadians   = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [2][0]]);
      let stopRadians    = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [2][1]]);
      let deltaRadians   = UTILS.Link (ConvertToRadians, [1, ABSCISSA]);

      COLOR          = definition [COLOR];
      LINEWIDTH      = UTILS.Link (UTILS.ToNumber, [DECIMAL, definition [LINEWIDTH]]);
      ORIENTATION    = definition [ORIENTATION];
      point          = UTILS.Link (ScaleToOrientation, [ORIENTATION, centerX, centerY], that.cartesianplane);
      centerX        = point.shift ();
      centerY        = point.shift ();
      point          = UTILS.Link (ScaleToUnits, [ORIENTATION, radiusH, radiusV], that.cartesianplane);
      radiusH        = point.shift ();
      radiusV        = point.shift ();
      clockwise      = stopRadians / Math.abs (stopRadians);
      clockwise      = UTILS.Link (FindDirection, [clockwise, ORIENTATION]);
      startRadians   = UTILS.Link (ConvertToRadians, [startRadians, ORIENTATION]);
      stopRadians    = Math.abs (stopRadians);
      oldX           = (radiusH)*Math.cos (startRadians);
      oldY           = (radiusV)*Math.sin (startRadians);
      circumferenceH = centerX + oldX;// + (oldY * that.cartesianplane.skew.x);
      circumferenceV = centerY - oldY;// - (oldX * that.cartesianplane.skew.y);

      if (clockwise) { deltaRadians = -deltaRadians; }

      UTILS.Link (PAINTER.SetButtLineCap);
      UTILS.Link (PAINTER.BeginPath);
      UTILS.Link (GRID.MoveTo, [circumferenceH, circumferenceV]);

      for (let rotations = 1; rotations < stopRadians; rotations ++) {
        startRadians   = startRadians - deltaRadians;
        oldX           = (radiusH)*Math.cos (startRadians);
        oldY           = (radiusV)*Math.sin (startRadians);
        circumferenceH = centerX + oldX;// + (oldY * that.cartesianplane.skew.x);
        circumferenceV = centerY - oldY;// - (oldX * that.cartesianplane.skew.y);

        UTILS.Link (GRID.LineTo, [circumferenceH, circumferenceV]);
      }

      UTILS.Link (AddColor, [LINEWIDTH, COLOR])
      UTILS.Link (PAINTER.SetLineCap, [formerLINECAP]);

      return undefined;
    } 

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DrawGraph (definition=undefined) {
      let that          = this;
      let ID            = 1;
      let COLOR         = 2;
      let LINEWIDTH     = 3;
      let ORIENTATION   = 4;
      let connectPoints = undefined;
      let point         = undefined;
      let stopX         = undefined;
      let stopY         = undefined;
      let rebuiltgraph  = UTILS.Link (RebuildGraph, [definition, 5]);
      let coordinates   = UTILS.Link (StripCoordinates, [rebuiltgraph, 5]);
      let startX        = undefined;
      let startY        = undefined;
      let oldX          = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [0][0]]);
      let oldY          = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [0][1]]) * -1;

      COLOR       = definition [COLOR];
      LINEWIDTH   = UTILS.Link (UTILS.ToNumber, [DECIMAL, definition [LINEWIDTH]]);
      ORIENTATION = definition [ORIENTATION];

      if (LINEWIDTH < 0) {
        let pointsType      = ARC;
        let pointsGroup     = definition [ID];
        let pointsRadius    = -LINEWIDTH;
        let pointsSize      = UTILS.KBD.KEY.OPEN_PAREN + pointsRadius + "," + pointsRadius + UTILS.KBD.KEY.CLOSE_PAREN;
        let pointsSlice     = "(0,361)";
        let endCoordinate   = coordinates.length - 1;
        let pointsStyle     = undefined;
        let pointDefinition = undefined;

        connectPoints = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [endCoordinate][1]]);
        pointsStyle   = coordinates [endCoordinate][0];
        LINEWIDTH     = connectPoints;

        coordinates.pop ();

        for (let o = 5; o < definition.length - 1; o ++) {
          pointDefinition = new Array ();

          pointDefinition.push (pointsType);
          pointDefinition.push (pointsGroup);
          pointDefinition.push (COLOR);
          pointDefinition.push (pointsStyle);
          pointDefinition.push (ORIENTATION);
          pointDefinition.push (definition [o]);
          pointDefinition.push (pointsSize);
          pointDefinition.push (pointsSlice);

          UTILS.Link (DrawArc, [pointDefinition], that);
        }
      }

      if ((LINEWIDTH >= 0) || (connectPoints !== undefined && connectPoints >= 0)) {
        startY = oldY;// - (oldX * that.cartesianplane.skew.x);
        startX = oldX;// - (oldY * that.cartesianplane.skew.y);
        point  = UTILS.Link (ScaleToOrientation, [ORIENTATION, startX, startY], that.cartesianplane);
        startY = point.pop ();
        startX = point.pop ();

        UTILS.Link (PAINTER.BeginPath);
        UTILS.Link (GRID.MoveTo, [startX, startY]);

        for (let i = 1; i < coordinates.length; i ++) {
          oldX  = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [i][0]]);
          oldY  = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [i][1]]) * -1;
          stopY = oldY;// - (oldX * that.cartesianplane.skew.x);
          stopX = oldX;// - (oldY * that.cartesianplane.skew.y);
          point = UTILS.Link (ScaleToOrientation, [ORIENTATION, stopX, stopY], that.cartesianplane);
          stopY = point.pop ();
          stopX = point.pop ();

          UTILS.Link (GRID.LineTo, [stopX, stopY]);
        }

        UTILS.Link (AddColor, [LINEWIDTH, COLOR]);
      }

      return undefined;
    } 

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DrawVector (definition=undefined) {
      let that          = this;
      let COLOR         = 2;
      let LINEWIDTH     = 3;
      let ORIENTATION   = 4;
      let headH         = undefined;
      let headV         = undefined;
      let point         = undefined;
      let formerLINECAP = UTILS.Link (PAINTER.GetCurrentLineCap);
      let rebuiltgraph  = UTILS.Link (RebuildGraph, [definition, 5]);
      let coordinates   = UTILS.Link (StripCoordinates, [rebuiltgraph, 5]);
      let tailX         = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [0][0]]);
      let tailY         = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [0][1]]) * -1;
      let radius        = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [1][0]]);
      let radianAngle   = UTILS.Link (UTILS.ToNumber, [DECIMAL, coordinates [1][1]]);

      COLOR       = definition [COLOR];
      LINEWIDTH   = UTILS.Link (UTILS.ToNumber, [DECIMAL, definition [LINEWIDTH]]);
      ORIENTATION = definition [ORIENTATION];
      point       = UTILS.Link (ScaleToOrientation, [ORIENTATION, tailX, tailY], that.cartesianplane);
      tailX       = point.shift ();
      tailY       = point.shift ();
      point       = UTILS.Link (ScaleToUnits, [ORIENTATION, radius, radius], that.cartesianplane);
      radius      = point.shift ();
      radianAngle = UTILS.Link (ConvertToRadians, [radianAngle, ORIENTATION]);
      headH       = tailX + radius*Math.cos (radianAngle);
      headV       = tailY - radius*Math.sin (radianAngle);

      UTILS.Link (PAINTER.SetButtLineCap);
      UTILS.Link (PAINTER.BeginPath);
      UTILS.Link (GRID.MoveTo, [tailX, tailY]);
      UTILS.Link (GRID.LineTo, [headH, headV]);

      UTILS.Link (AddColor, [LINEWIDTH, COLOR])
      UTILS.Link (PAINTER.SetLineCap, [formerLINECAP]);

      return undefined;
    } 

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RebuildGraph (definition=undefined, coordinatesStart=undefined) {
      let that              = this;
      let rebuiltdefinition = new Array ();
      let closeparentheses  = UTILS.KBD.KEY.CLOSE_PAREN;
      let tmpdefinition     = UTILS.BLANKCHAR;
      let coordinate        = UTILS.BLANKCHAR;
      let COORDINATESSTART  = coordinatesStart;

      for (let i = 0; i < COORDINATESSTART && i < definition.length; i ++) {
        rebuiltdefinition.push (definition [i]);
      }
      for (let i = COORDINATESSTART; i < definition.length; i ++) {
        tmpdefinition = tmpdefinition + definition [i];
      }

      tmpdefinition = tmpdefinition.trim ().split (UTILS.BLANKCHAR);
      tmpdefinition = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, tmpdefinition]);
      tmpdefinition = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, tmpdefinition]);

      for (let i = 0; i < tmpdefinition.length; i ++) {
        coordinate = coordinate + tmpdefinition [i];

        if (tmpdefinition [i] === closeparentheses) {
          rebuiltdefinition.push (coordinate);
          coordinate = UTILS.BLANKCHAR;
        }
      }

      return rebuiltdefinition;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function StripCoordinates (graph=undefined, startPoint=undefined) {
      let that             = this;
      let points           = new Array ();
      let startpoint       = startPoint;
      let endpoint         = graph.length;
      let openparentheses  = UTILS.KBD.KEY.OPEN_PAREN;
      let closeparentheses = UTILS.KBD.KEY.CLOSE_PAREN;
      let comma            = UTILS.KBD.KEY.COMMA;

      for (let i = startpoint; i < endpoint; i ++) {
        let point      = new Array ();
        let coordinate = graph [i].split (UTILS.BLANKCHAR);

        coordinate = UTILS.Link (UTILS.Filter, [openparentheses, coordinate]);
        coordinate = UTILS.Link (UTILS.Filter, [closeparentheses, coordinate]);
        coordinate = coordinate.join (UTILS.BLANKCHAR);
        coordinate = coordinate.split (comma);

        point.push (coordinate [0]);
        point.push (coordinate [1]);
        points.push (point);
      }

      return points;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ScaleToUnits (orientation=undefined, stopX=undefined, stopY=undefined) {
      let that  = this;
      let point = new Array ();

      if (orientation === ABSCISSA) {
        stopX = that.unit.x * stopX;
        stopY = that.unit.y * stopY;
      }
      else if (orientation === ORDINATE) {
        let tmpStopX  = stopX;
        stopX = that.unit.x * stopY;
        stopY = that.unit.y * tmpStopX;
      }

      point.push (stopX);
      point.push (stopY);

      return point;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ScaleToOrientation (orientation=undefined, stopX=undefined, stopY=undefined) {
      let that  = this;
      let point = new Array ();

      if (orientation === ABSCISSA) {
        stopX = (that.origin.x) + (that.unit.x * stopX);
        stopY = (that.origin.y) + (that.unit.y * stopY);
      }
      else if (orientation === ORDINATE) {
        let tmpStopX  = stopX;
        stopX = (that.origin.x) - (that.unit.x * stopY);
        stopY = (that.origin.y) - (that.unit.y * tmpStopX);
      }

      point.push (stopX);
      point.push (stopY);

      return point;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ConvertToRadians (angle=undefined, orientation=undefined) {
      let that = this;

      if (orientation === ORDINATE) { angle = (LINEARANGLE/2) - angle; }

      return angle * (Math.PI/LINEARANGLE);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function FindDirection (direction=undefined, orientation=undefined) {
      let that      = this;
      let clockwise = true;

      if (direction < 0) { clockwise = false; }
      if (orientation === ORDINATE) { clockwise = !clockwise; }

      return clockwise;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetRotationUnits (angle=undefined) {
      let point = new Array ();

      //

      return point;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function AddColor (linewidth=undefined, color=undefined) {
      let that            = this;
      let formerCOLOR     = undefined;
      let formerLINEWIDTH = UTILS.Link (PAINTER.GetBrushSize);

      UTILS.Link (PAINTER.SetBrushSizeTo, [linewidth]);

      if (linewidth > 0) {
        formerCOLOR = UTILS.Link (PAINTER.GetStrokeColor);

        UTILS.Link (PAINTER.SetStrokeColorTo, [color]);
        UTILS.Link (PAINTER.StrokePath);
        UTILS.Link (PAINTER.SetStrokeColorTo, [formerCOLOR]);
      }
      else {
        formerCOLOR = UTILS.Link (PAINTER.GetFillColor);

        UTILS.Link (PAINTER.SetFillColorTo, [color]);
        UTILS.Link (PAINTER.FillWithColor);
        UTILS.Link (PAINTER.SetFillColorTo, [formerCOLOR]);
      }

      UTILS.Link (PAINTER.ClosePath);
      UTILS.Link (PAINTER.SetBrushSizeTo, [formerLINEWIDTH]);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CleanStructures (commands=undefined) {
      let command       = undefined;
      let cleancommands = new Array ();

      for (let o = 0; o < commands.length; o ++) {
        command = commands [o].trim ().split (UTILS.KBD.KEY.WHITESPACE);
        command = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, command]);
        command = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, command]);
        if (STRUCTURE [command [0]] !== undefined) { cleancommands.push (command); }
      }

      return cleancommands;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CloneStructures (file=undefined) {
      let that     = this;
      let commands = new Array ();

      for (let o = 0; o < file.length; o ++) { commands.push (file [o]); }

      return commands;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Line (startInterval=undefined, stopInterval=undefined, coeffs=undefined) {
      let that    = this;
      let padding = "10";
      let graph   = new Array ();
      let dy      = Object.create (null);
      let dx      = Object.create (null);
      let m       = Object.create (null);
      let tmp     = Object.create (null);
      let c       = Object.create (null);
      let zero    = Object.create (null);

      //calculate all the constants needed to assemble a linear function by ...
      // ... finding the vertical displacement between the given points and then ...
      UTILS.Link (DECIMAL.Create, [{"value": "0"       , "padding": padding}], zero);
      UTILS.Link (DECIMAL.Create, [{"value": "0"       , "padding": padding}], m);
      UTILS.Link (DECIMAL.Create, [{"value": coeffs [0], "padding": padding}], tmp);
      UTILS.Link (DECIMAL.Create, [{"value": coeffs [1], "padding": padding}], dy);
      dy = UTILS.Link (DECIMAL.Minus, [tmp], dy);
      // ... finding the horizontal displacement between the given points and then ...
      UTILS.Link (DECIMAL.Create, [{"value": (startInterval + ""), "padding": padding}], tmp);
      UTILS.Link (DECIMAL.Create, [{"value": (stopInterval + ""), "padding": padding}], dx);
      dx = UTILS.Link (DECIMAL.Minus, [tmp], dx);
      // ... finding the gradient (ratio of vertical displacement to horizontal displacement) and then ...
      m = UTILS.Link (DECIMAL.DividedBy, [dx], dy);
      // ... finding the y-intercept of the function
      UTILS.Link (DECIMAL.Create, [{"value": coeffs [0], "padding": padding}], c);
      tmp = UTILS.Link (DECIMAL.Times, [m], tmp);
      c   = UTILS.Link (DECIMAL.Minus, [tmp], c);

      graph.push (UTILS.Link (DECIMAL.ToString, null, c));
      graph.push (UTILS.Link (DECIMAL.ToString, null, m));

      graph = UTILS.Link (Linear, [startInterval, stopInterval, graph], that);
      tmp   = startInterval;
      dx    = stopInterval;

      //swap the variables if their order of magnitude is in reverse
      if (tmp > dx) {
        tmp = tmp + dx;
        dx  = tmp - dx;
        tmp = tmp - dx;
      }

      for (let x = -that.cartesianplane.domain.units; x < tmp; x ++) { graph [x] = undefined; }
      for (let x = (dx + 1); x <= that.cartesianplane.domain.units; x ++) { graph [x] = undefined; }

      return graph;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetStructure (type=undefined) {
      let that      = this;
      let structure = undefined;

      switch (type) {
        case ARC       : structure = DrawArc; break;
        case GRID_CONST: structure = DrawGrid; break;
        case GRAPH     : structure = DrawGraph; break;
        case VECTOR    : structure = DrawVector; break;
      }

      return structure;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    geometer.Create      = Create;
    geometer.Destroy          = Destroy;
    geometer.AddHandlerFor    = AddHandlerFor;
    geometer.RemoveHandlerFor = RemoveHandlerFor;
    geometer.CleanStructures  = CleanStructures;
    geometer.CloneStructures  = CloneStructures;
    geometer.ClearBackground  = ClearBackground;
    geometer.GetStructure     = GetStructure;

    return Object.create (geometer);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Geometer = utils.Link (MakeGeometerName, [utils, decimal], geometerspace);

  return Geometer;
}
