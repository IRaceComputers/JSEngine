/****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2018 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeLogicNameSpace (liink, funkbrowzng) {
  "use strict";

  let logicspace = Object.create (null);
  let Logic      = undefined;

  function MakeLogicName (LiinK=undefined, FunkBrowzng=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let logic              = Object.create (null);

    let Expression        = undefined;
    let BGCOLOR           = undefined;
    let EKKOE             = undefined;
    let EXIT              = undefined;
    let FGCOLOR           = undefined;
    let FIILTER           = undefined;
    let FUNKBROWZNG       = FunkBrowzng;
    let PAINTER           = undefined;
    let KOVER             = undefined;
    let LIINK             = LiinK;
    let OCTAL             = undefined;
    let SKREEN            = undefined;
    let FONT              = "15px Monospace";
    let FALSE             = undefined;
    let TRUE              = undefined;
    let OR                = undefined;
    let AND               = undefined;
    let GS                = undefined;
    let NOT               = undefined;
    let CGS               = undefined;
    let GE                = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=undefined) {
      let that = this;

      BGCOLOR                     = info.bgcolor;
      EKKOE                       = info.ekkoe;
      EXIT                        = info.escape;
      FGCOLOR                     = info.fgcolor;
      FIILTER                     = info.fiilter;
      FONT                        = info.font || FONT;
      PAINTER                     = info.painter;
      KOVER                       = info.kover;
      SKREEN                      = info.skreen;
      that.ekkoe                  = Object.create (null);
      that.id                     = info.id;
      OCTAL                       = Object.create (null);
      Expression                  = Object.create (null);
      FALSE                       = "F";
      TRUE                        = "T";
      OR                          = "|";
      AND                         = "&";
      GS                          = "(";
      CGS                         = "]";
      GE                          = ")";
      NOT                         = "!";
      OCTAL        [FALSE]        = "0";
      OCTAL        [ TRUE]        = "1";
      OCTAL        [   OR]        = "2";
      OCTAL        [  AND]        = "3";
      OCTAL        [   GS]        = "4";
      OCTAL        [  NOT]        = "5";
      OCTAL        [   GE]        = "6";
      OCTAL        [  CGS]        = "7";
      Expression  [OCTAL [FALSE]] = FALSE;
      Expression  [OCTAL [ TRUE]] = TRUE;
      Expression  [OCTAL [   OR]] = OR;
      Expression  [OCTAL [  AND]] = AND;
      Expression  [OCTAL [   GS]] = GS;
      Expression  [OCTAL [  CGS]] = CGS;
      Expression  [OCTAL [   GE]] = GE;
      Expression  [OCTAL [  NOT]] = NOT;

      LIINK (
        EKKOE.Create,
        [{
          "bgcolor": BGCOLOR,
          "escape" : EXIT,
          "fgcolor": FGCOLOR,
          "font"   : FONT,
          "help"   : info.help,
          "id"     : that.id,
          "skreen" : SKREEN,
          "kover"  : KOVER,
          "painter": PAINTER,
          "stakk"  : info.stakk
        }],
        that.ekkoe
      );

      LIINK (Customize, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatlogic = this;
      let that     = thatlogic.ekkoe;
      let ENTER    = "Enter";
      let oldEnter = that.Action [ENTER];

      that.Action [ENTER]  = LIINK (MakeNewEnter, [oldEnter], thatlogic);

    /**************************************************************************************************************/
    /**************************************************************************************************************/
    /**************************************************************************************************************/

      LIINK (FUNKBROWZNG.Create, [{"liink": LIINK}], thatlogic);

      LIINK (
        FUNKBROWZNG.Create,
        [{
          "kommand" : ".evaluate.",
          "funktion": LogicRun.bind (that)
        }],
        thatlogic
      );

      LIINK (
        FUNKBROWZNG.Create,
        [{
          "kommand" : ".evaluateline.",
          "funktion": LogicLineRun.bind (that)
        }],
        thatlogic
      );

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=undefined) {
      let thatlogic = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that      = this;
        let words     = that.words;
        let opline    = undefined;
        let blankChar = "";
        let spaceChar = "\u0020";

        opline = words[words.length - 1].trim (). split (spaceChar);

        opline = LIINK (FIILTER, [blankChar, opline]);
        opline = LIINK (FIILTER, [spaceChar, opline]);

        // if last line's first word is an internal kommand then runnit, else LIINK (oldEnter, [], that);
        if (LIINK (FUNKBROWZNG.Rekorded, [opline[0]], thatlogic)) {
          let Kommand = LIINK (FUNKBROWZNG.Trigger, [opline[0]], thatlogic);

          LIINK (Kommand, [words, blankChar, spaceChar]);
        }
        else { LIINK (oldEnter, [], that); }

        return undefined;
      }
      
      return Enter;
    };
 
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LogicRun (words=undefined, blankChar=undefined, spaceChar=undefined) {
      let that       = this;
      let event      = Object.create (null);
      let ARROWDOWN  = "ArrowDown";
      let BACKSPACE  = "Backspace";
      let DELETELINE = "F9";

      event ["shiftKey"] = true;

      LIINK (that.Action [BACKSPACE], [event], that);
      LIINK (OctalExpression, [words, blankChar, spaceChar], that);

      for (let i = (that.words.length - 1); i > 0; i --) {
        that.words [i-1] = that.words[i-1] + that.words [i];
        LIINK (that.Action [DELETELINE], [event], that);
        LIINK (that.Action [BACKSPACE] , [event], that);
      }

      let word = that.words [0].split (blankChar); 
      let sum = 0;

      for (let i = 0; i < word.length; i ++) { sum = sum + (word [i] / 1); }

      sum = (sum % 2);
      that.words [0] = (sum + blankChar);

      LIINK (LogicExpression, [words, blankChar, spaceChar], that);

      event ["shiftKey"] = false;

      LIINK (that.Action [ARROWDOWN], [event], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LogicLineRun (words=undefined, blankChar=undefined, spaceChar=undefined) {
      let that       = this;
      let event      = Object.create (null);
      let ARROWDOWN  = "ArrowDown";
      let BACKSPACE  = "Backspace";
      let DELETELINE = "F9";

      event ["shiftKey"] = true;

      LIINK (that.Action [BACKSPACE], [event], that);
      LIINK (OctalExpression, [words, blankChar, spaceChar], that);

      for (let i = (that.words.length - 1); i >= 0; i --) {
        let word = that.words [i].split (blankChar);
        let sum = 0;

        for (let j = 0; j < word.length; j ++) { sum = sum + (word [j] / 1); }

        sum = (sum % 2);
        that.words [i] = (sum + blankChar);
      }

      LIINK (LogicExpression, [words, blankChar, spaceChar], that);

      event ["shiftKey"] = false;

      LIINK (that.Action [ARROWDOWN], [event], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function OctalExpression (words=undefined, blankChar=undefined, spaceChar=undefined) {
      let that       = this;
      let mixedwords = words;

      for (let i = 0; i < that.words.length; i ++) {
        mixedwords = that.words [i].trim ().split (spaceChar);

        for (let j = 0; j < mixedwords.length; j ++) {
          if (OCTAL [mixedwords [j]]) { mixedwords [j] = OCTAL [mixedwords [j]]; }
        }

        that.words [i] = mixedwords.join (blankChar);
      }      

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LogicExpression (words=undefined, blankChar=undefined, spaceChar=undefined) {
      let that       = this;
      let mixedwords = words;

      for (let i = 0; i < that.words.length; i ++) {
        mixedwords = that.words [i].trim ().split (spaceChar);

        for (let j = 0; j < mixedwords.length; j ++) {
          if (Expression [mixedwords [j]]) { mixedwords [j] = Expression [mixedwords [j]]; }
        }

        that.words [i] = mixedwords.join (blankChar);
      }      

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function EvaluateLogic () {
      let that = this;

      //

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      LIINK (EKKOE.Destroy, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RemoveHandlerFor (EventName=undefined) {
      return LIINK (EKKOE.RemoveHandlerFor, [EventName], this);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    logic.Destroy          = Destroy;
    logic.Create      = Create;
    logic.RemoveHandlerFor = RemoveHandlerFor;

    return Object.create (logic);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Logic = liink (MakeLogicName, [liink, funkbrowzng], logicspace);

  return Logic;
}