function MakeGeometryNameSpace (utils, decimal, browser) {
  "use strict";

  let geometryspace = Object.create (null);
  let Geometry      = undefined;

  function MakeGeometryName (Utils=undefined, Decimal=undefined, Browser=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let geometry    = Object.create (null);

    let DECIMAL     = Decimal;
    let BGCOLOR     = undefined;
    let BROWSER     = Browser;
    let COVER       = undefined;
    let EKKOE       = undefined;
    let EXIT        = undefined;
    let FGCOLOR     = undefined;
    let FILEMANAGER = undefined;
    let FONT        = "15px Monospace";
    let GRID        = undefined;
    let PAINTER     = undefined;
    let GEOMETER    = undefined;
    let SCREEN      = undefined;
    let STACK       = undefined;
    let UTILS       = Utils;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Materialize (info=undefined) {
      let that = this;

      BGCOLOR     = info.bgcolor;
      GRID        = info.grid;
      EKKOE       = info.ekkoe;
      EXIT        = info.escape;
      FGCOLOR     = info.fgcolor;
      FILEMANAGER = info.filemanager;
      FONT        = info.font || FONT;
      PAINTER     = info.painter;
      COVER       = info.cover;
      GEOMETER    = info.geometer;
      SCREEN      = info.screen;
      STACK       = info.stack;
      that.id     = info.id;
      that.ekkoe  = Object.create (null);

      UTILS.Link (
        EKKOE.Materialize,
        [{
          "bgcolor"    : BGCOLOR,
          "cover"      : COVER,
          "escape"     : EXIT,
          "fgcolor"    : FGCOLOR,
          "filemanager": FILEMANAGER,
          "font"       : FONT,
          "help"       : info.help,
          "id"         : that.id,
          "painter"    : PAINTER,
          "screen"     : SCREEN,
          "stack"      : info.stack
        }],
        that.ekkoe
      );

      UTILS.Link (
        GEOMETER.Materialize,
        [{
          "bgcolor" : BGCOLOR,
          "grid"    : GRID,
          "painter" : PAINTER,
          "unit"    : info.unit
        }],
        that
      );

      UTILS.Link (Customize, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatgeometry  = this;
      let that          = thatgeometry.ekkoe;
      let ENTER         = UTILS.KBD.KEY.ENTER;
      let oldEnter      = that.Action [ENTER];

      that.Action [ENTER]  = UTILS.Link (MakeNewEnter, [oldEnter], thatgeometry);

    /**************************************************************************************************************/
    /**************************************************************************************************************/
    /**************************************************************************************************************/

      UTILS.Link (
        BROWSER.Materialize,
        [{
          "command" : ".create.",
          "funktion": Create.bind (thatgeometry)
        }],
        thatgeometry
      );

      return undefined;
    } 

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=undefined) {
      let thatgeometry = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that      = this;
        let command   = undefined;
        let opline    = undefined;
        let words     = that.words;

        opline  = words[words.length - 1].trim (). split (UTILS.KBD.KEY.WHITESPACE);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, opline]);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, opline]);
        command = UTILS.Link (BROWSER.Recorded, [opline[0]], thatgeometry);

        // if last line's first word is an internal kommand then runnit, else UTILS.Link (oldEnter, [], that);
        if (command !== undefined) { UTILS.Link (command, [words, UTILS.KBD.KEY.WHITESPACE]); }
        else { UTILS.Link (oldEnter, [], that); }

        return undefined;
      }

      return Enter;
    };
 
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create () {
      let thatgeometry = this;
      let TYPE         = 0;
      let components   = undefined;
      let structures   = undefined;
      let type         = undefined;
      let Structure    = undefined;

      structures = UTILS.Link (GEOMETER.CloneStructures, [], thatgeometry);
      structures = UTILS.Link (GEOMETER.CleanStructures, [structures]);

      UTILS.Link (GEOMETER.ClearBackground, [], thatgeometry);

      for (let i =  0; i < structures.length; i ++) {
        components = structures [i];
        type       = components [TYPE];
        Structure  = UTILS.Link (GEOMETER.GetStructure, [type]);

        if (Structure !== undefined) {
          UTILS.Link (Structure, [components], thatgeometry);
        }
      }

      thatgeometry.ekkoe.requireRewrite = false;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      UTILS.Link (EKKOE.Destroy, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    geometry.Materialize = Materialize;
    geometry.Destroy     = Destroy;

    return Object.create (geometry);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Geometry = utils.Link (MakeGeometryName, [utils, decimal, browser], geometryspace);

  return Geometry;
}
