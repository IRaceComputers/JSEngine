/****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeNullTermNameSpace (utils) {
  "use strict";

  let nulltermspace = Object.create (null);
  let NullTerm      = undefined;

  function MakeNullTermName (Utils=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let nullterm       = Object.create (null);
    let BGCOLOR        = undefined;
    let COVER          = undefined;
    let CURSOR         = undefined;
    let EKKOE          = undefined;
    let EXIT           = undefined;
    let FILE           = undefined;
    let FILEMANAGER    = undefined;
    let FGCOLOR        = undefined;
    let FONT           = undefined;
    let INITIATE       = undefined;
    let INITDATA       = undefined;
    let LINE           = undefined;
    let PAINTER        = undefined;
    let PROCESS        = undefined;
    let PRESS          = undefined;
    let PressControl   = undefined;
    let PressShift     = undefined;
    let RELEASE        = undefined;
    let ReleaseControl = undefined;
    let ReleaseShift   = undefined;
    let SCREEN         = undefined;
    let ScrollLock     = undefined;
    let SERVER         = undefined;
    let UTILS          = undefined;
    let WHOLE          = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/ 

    function Create (info=undefined) {
      let that = this;

      BGCOLOR           = info.bgcolor;
      COVER             = info.cover;
      EKKOE             = info.ekkoe;
      EXIT              = info.escape;
      FGCOLOR           = info.fgcolor;
      FILEMANAGER       = info.filemanager;
      FONT              = info.font || FONT;
      INITDATA          = info.initdata;
      INITIATE          = info.initiate;
      PAINTER           = info.painter;
      PROCESS           = info.process;
      SERVER            = PROCESS [info.id];
      SCREEN            = info.screen;
      PressControl      = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.CONTROL, PRESS], EKKOE);
      PressShift        = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.SHIFT, PRESS], EKKOE);
      ReleaseControl    = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.CONTROL, RELEASE], EKKOE);
      ReleaseShift      = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.SHIFT, RELEASE], EKKOE);
      ScrollLock        = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, RELEASE], EKKOE);

      UTILS.Link (UTILS.MapKeyValue, [that, "ekkoe", Object.create (null)]);
      UTILS.Link (UTILS.MapKeyValue, [that.ekkoe, "exists", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
      UTILS.Link (EKKOE.Create, [info], that.ekkoe);
      UTILS.Link (Customize, null, that);
      UTILS.Link (UTILS.Animate, [CommandRecognition], UTILS.WIN.SYS);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatnullterm = this;
      let RELEASE      = 1;
      let that         = thatnullterm.ekkoe;
      let ESCAPE       = UTILS.KBD.KEY.ESCAPE;
      let HELP         = UTILS.KBD.KEY.F1; 
      let RELOAD       = UTILS.KBD.KEY.F5;
      let oldFunction  = UTILS.Link (EKKOE.GetKeyFunction, [HELP, PRESS], that);
      let newFunction  = UTILS.Link (MakeNewHelp, [oldFunction], that);

      UTILS.Link (EKKOE.SetKeyFunction, [HELP, newFunction, PRESS], that);

      newFunction = UTILS.WIN.SYS.location.reload.bind (UTILS.WIN.SYS);

      UTILS.Link (EKKOE.SetKeyFunction, [RELOAD, newFunction, PRESS], that)

      newFunction = UTILS.Link (MakeNewEscape, null, thatnullterm);

      UTILS.Link (EKKOE.SetKeyFunction, [ESCAPE, newFunction, RELEASE], that);

      return undefined;
    }

  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/
  
    function MakeNewEscape () {
      let thatnullterm  = this;
      let that          = thatnullterm.ekkoe;
      let RELEASE       = 1;
      let defaultEscape = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.ESCAPE, RELEASE], that);

      if (defaultEscape === undefined) { return LoopBack.bind (that); }
      else { return Escape.bind (thatnullterm); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LoopBack () {
      let that             = this;
      let parent           = "nullterm";
      let End              = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.END, RELEASE], that);
      let Enter            = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.ENTER, PRESS], that);
      let ScrollLock       = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, RELEASE], that);
      let ctrlKeyDown      = UTILS.Link (EKKOE.GetControlState);
      let scrollLockActive = UTILS.Link (EKKOE.GetScrollLockState);

      if (!ctrlKeyDown) { UTILS.Link (PressControl, null, that); }

      UTILS.Link (End, null, that);

      if (!ctrlKeyDown) { UTILS.Link (ReleaseControl); }
      if (scrollLockActive) { UTILS.Link (ScrollLock, null, that); }

      UTILS.Link (Enter, null, that);

      if (scrollLockActive) { UTILS.Link (ScrollLock, null, that); }

      UTILS.Link (EKKOE.PersistFile);
      UTILS.Link (EKKOE.PersistFileLine);

      FILE = UTILS.Link (FILEMANAGER.GetFile, [WHOLE]);
      LINE = UTILS.Link (FILEMANAGER.GetFileLine);
      UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, parent]);
      CURSOR = FILE [LINE].length;

      UTILS.Link (FILEMANAGER.SetFileCursor, [CURSOR]);
      UTILS.Link (FILEMANAGER.SetFile, [WHOLE, FILE]);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Escape () {
      let that      = this;
      let date      = new Date ();
      let exitText  = new Array ();
      let finaltext = UTILS.BLANKCHAR;

      exitText.push ("<br/><br/><br/><br/>");
      exitText.push ("<p>Press [F5] or [CTRL]+[R] to start</p>");
      exitText.push ("<br/><br/>");
      exitText.push ("<p>Press [CTRL]+[W] to exit.</p>");
      exitText.push ("<br/><br/>");
      exitText.push ("<p>Ancient Creations &trade;</p>");
      exitText.push ("<br/><br/>");
      exitText.push ("<p>ASH &copy; 2021</p>");

      for (let i = 0; i < exitText.length; i ++) { finaltext = finaltext + exitText [i]; }

      UTILS.Link (UTILS.MapKeyValue, [COVER, "innerHTML", finaltext]);

      return UTILS.Link (Destroy, null, that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function fakeEscape () { return undefined; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=undefined) {
      let thatekkoe = this;
      let End       = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.END, RELEASE], EKKOE);
      let Enter     = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.ENTER, PRESS], EKKOE);

      function Help (event=undefined) {
        let that             = this;
        let scrollLockActive = UTILS.Link (EKKOE.GetScrollLockState);
        let ctrlKeyDown      = UTILS.Link (EKKOE.GetControlState);

        if (scrollLockActive) { UTILS.Link (ScrollLock, null, that); }

        if (!ctrlKeyDown) { UTILS.Link (PressControl, null, that) }

        UTILS.Link (End, null, that);

        if (!ctrlKeyDown) { UTILS.Link (ReleaseControl) }

        UTILS.Link (Enter, null, that);
        UTILS.Link (Helper, [event, fakeEscape], that);

        if (scrollLockActive) { UTILS.Link (ScrollLock, null, that); }

        return undefined;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function History () {
      let that             = this;
      let ellipsis         = "...";
      let ArrowUp          = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.ARROWUP, PRESS], EKKOE);
      let Backspace        = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, PRESS], EKKOE);
      let End              = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.END, RELEASE], EKKOE);
      let Enter            = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.ENTER, PRESS], EKKOE);
      let ctrlKeyDown      = UTILS.Link (EKKOE.GetControlState);
      let scrollLockActive = UTILS.Link (EKKOE.GetScrollLockState);
      let shiftKeyDown     = UTILS.Link (EKKOE.GetShiftState);
      let tmp              = undefined;

      UTILS.Link (Backspace, null, that.ekkoe);

      if (!shiftKeyDown) { UTILS.Link (PressShift, null, that); }

      UTILS.Link (Backspace, null, that.ekkoe);

      if (!shiftKeyDown) { UTILS.Link (ReleaseShift); }

      UTILS.Link (Enter, null, that.ekkoe);
      UTILS.Link (EKKOE.PersistFile);
      UTILS.Link (EKKOE.PersistFileLine);
      UTILS.Link (EKKOE.PersistFileCursor);

      FILE = UTILS.Link (FILEMANAGER.GetFile, [WHOLE]);
      LINE = UTILS.Link (FILEMANAGER.GetFileLine);

      UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, ellipsis]);

      for (let i = 0; i < that.history.length; i ++) {
        tmp = FILE [LINE] + UTILS.KBD.KEY.WHITESPACE + that.history [i];
        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, tmp]);
      }

      UTILS.Link (FILE.push, [UTILS.BLANKCHAR], FILE);
      UTILS.Link (FILEMANAGER.SetFile, [WHOLE, FILE]);
      UTILS.Link (FILEMANAGER.SetFileLine, [FILE.length - 1]);
      UTILS.Link (FILEMANAGER.SetFileCursor, [0]);
      UTILS.Link (EKKOE.RetrieveFile);
      UTILS.Link (EKKOE.RetrieveFileLine);
      UTILS.Link (EKKOE.RetrieveFileCursor);

      if (!ctrlKeyDown) { UTILS.Link (PressControl, null, that); }

      UTILS.Link (End, null, that.ekkoe);

      if (!ctrlKeyDown) { UTILS.Link (ReleaseControl); }

      UTILS.Link (EKKOE.PersistSegmentBegin);
      UTILS.Link (EKKOE.PersistSegmentEnd);
      UTILS.Link (EKKOE.PersistLineStart);
      UTILS.Link (EKKOE.ReWrite, null, that.ekkoe);

      if (scrollLockActive) { UTILS.Link (ScrollLock, null, that); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    /********************************************************
    * Command Recognition and Application Loader
    /*******************************************************/
    function CommandRecognition () {
      let command          = undefined;
      let identity         = "id";
      let End              = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.END, RELEASE], EKKOE);
      let Enter            = UTILS.Link (EKKOE.GetKeyFunction, [UTILS.KBD.KEY.ENTER, PRESS], EKKOE);
      let ctrlKeyDown      = UTILS.Link (EKKOE.GetControlState);
      let scrollLockActive = UTILS.Link (EKKOE.GetScrollLockState);
      let lastline         = undefined;

      FILE     = UTILS.Link (FILEMANAGER.GetFile, [WHOLE]);
      lastline = FILE [FILE.length - 1].trim ();
      lastline = lastline.split (UTILS.KBD.KEY.WHITESPACE);
      lastline = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, lastline]);
      lastline = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, lastline]);
      command  = lastline [0];

      if (PROCESS [command] !== undefined) { 
        SERVER.history.push (INITDATA [command][identity]);

        if (scrollLockActive) { UTILS.Link (ScrollLock, null, SERVER.ekkoe); }

        if (!ctrlKeyDown) { UTILS.Link (PressControl, null, SERVER.ekkoe); }

        UTILS.Link (End, null, SERVER.ekkoe);

        if (!ctrlKeyDown) { UTILS.Link (ReleaseControl); }

        UTILS.Link (Enter, null, SERVER.ekkoe);
        UTILS.Link (EKKOE.PersistFile);
        UTILS.Link (EKKOE.PersistFileLine);
        UTILS.Link (EKKOE.PersistFileCursor);

        if (scrollLockActive) { UTILS.Link (ScrollLock, null, SERVER.ekkoe); }

        if (SERVER.exceptional [command] === undefined) {
          UTILS.Link (Destroy, null, SERVER);
        }

        UTILS.Link (INITIATE [command], null, PROCESS [command]);
      }

      if (SERVER.ekkoe.exists) {
        UTILS.Link (UTILS.Animate, [CommandRecognition], UTILS.WIN.SYS);
      }
      
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      that.ekkoe.exists = false;

      UTILS.Link (EKKOE.Destroy, [], that.ekkoe);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;

      PRESS   = 0;
      RELEASE = 1;
      UTILS   = Utils;
      WHOLE   = -1;

      UTILS.Link (UTILS.MapKeyValue, [that, "Create", Create]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Destroy", Destroy]);
      UTILS.Link (UTILS.MapKeyValue, [that, "History", History]);

      return Object.create (that);
    }

    return Utils.Link (Objectify, null, nullterm);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  NullTerm = utils.Link (MakeNullTermName, [utils], nulltermspace);

  return NullTerm;
}
