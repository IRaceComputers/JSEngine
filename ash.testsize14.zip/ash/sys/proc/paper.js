  /****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakePaperNameSpace (loader) {
  "use strict";

  let paperspace = Object.create (null);

  function MakePaperName (Loader=undefined) {
    let paper = this;
    let _     = null;
    let __    = undefined;
    let ___   = __;
    let ____  = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    /************************************************************************************
    * keyboard functions/objects
    ************************************************************************************/
    let Press     = __;
    let Printable = __;
    let Release   = __;
    let EXIT      = __;
    /************************************************************************************
    * keyboard key state modifiers
    ************************************************************************************/
    let ALTDOWN      = __;
    let ALTGRAPHDOWN = __;
    let CONTROLDOWN  = __;
    let INSERT       = __;
    let SCROLLLOCK   = __;
    let SHIFTDOWN    = __;
    /************************************************************************************
    * class objects
    ************************************************************************************/
    let CLIPBOARD   = __;
    let FILEMANAGER = __;
    let LOADER      = __;
    let PAINTER     = __;
    let STACK       = __;
    let UTILS       = __;
    let VIEWPORT    = __;
    /************************************************************************************
    * filemanager states
    ************************************************************************************/
    let CURSOR = __;
    let FILE   = __;
    let LINE   = __;
    /************************************************************************************
    * viewport states
    ************************************************************************************/
    let FONT         = __;
    let LINEHEIGHT   = __;
    let FILESEGSIZE  = __;
    let FILESEGBEGIN = __;
    let FILESEGEND   = __;
    let LINESTART    = __;
    let LINESTOP     = __;
    let TMARGIN      = __;
    let LMARGIN      = __;
    let BMARGIN      = __;
    let RMARGIN      = __;
    let VIEWCAPACITY = __;
    /************************************************************************************
    * paper states
    ************************************************************************************/
    let COVER    = __;
    let DATA     = __;
    let EXPLAIN  = __;
    let BGCOLOR  = __;
    let FGCOLOR  = __;
    let HELP     = __;
    let PROGRAMS = __;
    let TABSIZE  = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=__) {
    /************************************************************************************
    * The function which creates the paper process
    ************************************************************************************/
      let that = this;

      CURSOR       = 0;
      EXIT         = info.escape;
      FILE         = new Array (UTILS.BLANKCHAR);
      FILESEGBEGIN = 0;
      FILESEGEND   = 0;
      HELP         = info.help;
      LINE         = 0;
      LINESTART    = 0;
      LINESTOP     = 120;
      BMARGIN      = info.height - TMARGIN;
      LMARGIN      = 20;
      RMARGIN      = info.width * 0.8;
      TMARGIN      = 20;

      if (BGCOLOR === __) { ___ (SetBgColor, [info.bgcolor]); }
      if (FGCOLOR === __) { ___ (SetFgColor, [info.fgcolor]); }
      if (FONT === __) { ___ (SetFont, [info.font]); }

      ___ (____, [that, "id", info.id]);
    /************************************************************************************
    * create painter
    ************************************************************************************/
      ___ (____, [that, "painter", ___ (UTILS.CloneMap)]);
      ___ (____, [info, "painter", ___ (UTILS.CloneMap)]);
      ___ (____, [info.painter, "id", info.id]);
      ___ (____, [info.painter, "cover", COVER]);
      ___ (____, [info.painter, "height", UTILS.WIN.SYS.innerHeight - TMARGIN]);
      ___ (____, [info.painter, "width", UTILS.WIN.SYS.innerWidth  - LMARGIN]);
      ___ (PAINTER.Create, [info.painter ], that.painter);
    /************************************************************************************
    * create stack
    ************************************************************************************/
      ___ (____, [that, "stack", ___ (UTILS.CloneMap)]);
      ___ (STACK.Create, _, that.stack);
    /************************************************************************************
    * customize paper
    ************************************************************************************/
      ___ (____, [that, "Press", ___ (UTILS.CloneMap, [Press])]);
      ___ (____, [that, "Printable", ___ (UTILS.CloneMap, [Printable])]);
      ___ (____, [that, "Release", ___ (UTILS.CloneMap, [Release])]);
      ___ (Customize, _, that);
    /********************************************************************************************************************/
      ___ (CalculateViewCapacity);
    /************************************************************************************
    * initialize viewport
    ************************************************************************************/
      ___ (VIEWPORT.Create);
      ___ (VIEWPORT.SetTopMargin, [TMARGIN]);
      ___ (VIEWPORT.SetLeftMargin, [LMARGIN]);
      ___ (VIEWPORT.SetBottomMargin, [BMARGIN]);
      ___ (VIEWPORT.SetRightMargin, [RMARGIN]);
      ___ (VIEWPORT.SetLineStop, [LINESTOP]);
      ___ (VIEWPORT.SetCapacity, [VIEWCAPACITY]);
    /************************************************************************************
    * read help file
    ************************************************************************************/
      ___ (FILEMANAGER.Read, [HELP], that);
    /********************************************************************************************************************/
    /************************************************************************************
    * set system flags
    ************************************************************************************/
      ___ (SetEditing, _, that);
      ___ (SetPreventDefault, _, that);
      ___ (SetRequireRewrite, _, that);
      ___ (SetStopPropagation, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
 
    function Customize () {
      let that    = this;
      let HELP    = UTILS.KBD.KEY.F1;
      let oldHelp = ___ (GetKeyFunction, [HELP, UTILS.PRESS], that);
      let newHelp = ___ (MakeNewHelp, [oldHelp], that);

      ___ (UpdateDocumentBgColor);
    /********************************************************************************************************************/
      ___ (SetKeyFunction, [UTILS.KBD.KEY.ESCAPE, EXIT, UTILS.RELEASE], that);
      ___ (SetKeyFunction, [HELP, newHelp, UTILS.PRESS], that);
      ___ (SetKeyFunction, [UTILS.KBD.KEY.INTERNALCALL, UseFileContents, UTILS.PRESS], that);
    /********************************************************************************************************************/
      ___ (____, [that.Press, UTILS.KBD.KEY.DOWN, KeydownHandler.bind (that)]);
      ___ (____, [that.Press, UTILS.KBD.KEY.UP, KeyupHandler.bind (that)]);
      ___ (____, [that.Press, UTILS.WIN.RESIZE, ResizeHandler.bind (that)]);
      ___ (____, [that.Press, UTILS.MWS.WHEEL, MouseWheelScrollHandler.bind (that)]);
    /********************************************************************************************************************/
      ___ (UTILS.AddHandlerFor, [UTILS.KBD.KEY.DOWN, UTILS.WIN.SYS], that.Press);
      ___ (UTILS.AddHandlerFor, [UTILS.KBD.KEY.UP, UTILS.WIN.SYS], that.Press);
      ___ (UTILS.AddHandlerFor, [UTILS.WIN.RESIZE, UTILS.WIN.SYS] , that.Press);
      ___ (UTILS.AddHandlerFor, [UTILS.MWS.WHEEL, ___ (PAINTER.GetCanvas)], that.Press);

      return __;
     }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define event handlers below
  ************************************************************************************/

    function KeydownHandler (event=__) {
      let that = this;

      ___ (SetEditing, _, that);
      ___ (SetPreventDefault, _, that);
      ___ (SetRequireRewrite, _, that);
      ___ (SetStopPropagation, _, that);
      ___ (RetrieveFile);
      ___ (RetrieveFileLine);
      ___ (RetrieveFileCursor);

      if (___ (NonPrintCharacter, [event.key], _)) {
        if (___ (PressKey, [event.key], _)) { ___ (HandlePress, [event], that); }
      }
      else { ___ (HandlePrint, [event], that); }
      if (that.justifyViewport) { ___ (JustifyViewport); }
      else {
        ___ (PersistViewportStart);
        ___ (PersistViewportEnd);
        ___ (PersistViewportLineStart);
      }
      if (that.editing) {
        ___ (PersistClipboardCursor);
        ___ (PersistClipboardLine);
      }
      if (that.requireRewrite) { ___ (ReWrite, _, that); }
      if (that.preventDefault) { ___ (event.preventDefault, _, event); }
      if (that.stopPropagation) { ___ (event.stopPropagation, _, event); }

      ___ (PersistFile);
      ___ (PersistFileLine);
      ___ (PersistFileCursor);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function KeyupHandler (event=__) {
      let that = this;

      ___ (SetPreventDefault, _, that);
      ___ (UnsetRequireRewrite, _, that);
      ___ (SetStopPropagation, _, that);
      ___ (RetrieveFile);
      ___ (RetrieveFileLine);
      ___ (RetrieveFileCursor);

      if (___ (ReleaseKey, [event.key])) { ___ (HandleRelease, [event], that); }
      if (that.justifyViewport) { ___ (JustifyViewport); }
      else {
        ___ (PersistViewportStart);
        ___ (PersistViewportEnd);
        ___ (PersistViewportLineStart);
      }
      if (that.editing) {
        ___ (PersistClipboardCursor);
        ___ (PersistClipboardLine);
      }
      if (that.requireRewrite) { ___ (ReWrite, _, that); }
      if (that.preventDefault) { ___ (event.preventDefault, _, event); }
      if (that.stopPropagation) { ___ (event.stopPropagation, _, event); }

      ___ (PersistFile);
      ___ (PersistFileLine);
      ___ (PersistFileCursor);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DisplaceViewportVertically (displacement=__) {
      let that         = this;
      let SCROLLAMOUNT = 3;

      if (displacement < 0) {
        for (let o = 0; (o < SCROLLAMOUNT); o ++) {
          if ((FILESEGEND + 1) < FILE.length) {
            FILESEGBEGIN = FILESEGBEGIN + 1;
            FILESEGEND   = FILESEGEND + 1;
          }
          else { o = SCROLLAMOUNT; }
        }
      }
      else {
        for (let o = 0; (o < SCROLLAMOUNT); o ++) {
          if (FILESEGBEGIN > 0) {
            FILESEGBEGIN = FILESEGBEGIN - 1;
            FILESEGEND   = FILESEGEND - 1;
          }
          else { o = SCROLLAMOUNT; }
        }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MouseWheelScrollHandler (event=__) {
      let that      = this;
      let deltaSize = -event.deltaY;

      if (CONTROLDOWN) { ___ (UpdateFontSize, [deltaSize], that); }
      else if (FILE.length >= VIEWCAPACITY) { ___ (DisplaceViewportVertically, [deltaSize]); }
      if (that.requireRewrite) { ___ (ReWrite, _, that); }

      ___ (event.preventDefault, _, event);
      ___ (event.stopPropagation, _, event );
      ___ (SetRequireRewrite, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ResizeHandler (event) {
      let that = this;

      ___ (PAINTER.SetCanvasHeightTo, [UTILS.WIN.SYS.innerHeight - TMARGIN]);
      ___ (PAINTER.SetCanvasWidthTo, [UTILS.WIN.SYS.innerWidth - LMARGIN]);

      RMARGIN = ___ (PAINTER.GetCanvasWidth) * 0.8;

      ___ (VIEWPORT.SetRightMargin, [RMARGIN]);
      ___ (ReWrite, _, that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Various internal functions
  ************************************************************************************/

    function NewLine () {
    /************************************************************************************
    * The function which moves the cursor to the next line on the kanvas 
    ************************************************************************************/
      let that = this;
      ___ (____, [that, "y", that.y + LINEHEIGHT]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefineNonPrintKeyFunctions () {

      ___ (____, [Press, UTILS.KBD.KEY.INTERNALCALL, InternalCall]);
      ___ (____, [Press, UTILS.KBD.KEY.ALT, PressAlt]);
      ___ (____, [Press, UTILS.KBD.KEY.ALTGRAPH, PressAltGraph]);
      ___ (____, [Press, UTILS.KBD.KEY.ARROWLEFT, ArrowLeft]);
      ___ (____, [Press, UTILS.KBD.KEY.ARROWUP, ArrowUp]);
      ___ (____, [Press, UTILS.KBD.KEY.ARROWDOWN, ArrowDown]);
      ___ (____, [Press, UTILS.KBD.KEY.ARROWRIGHT, ArrowRight]);
      ___ (____, [Press, UTILS.KBD.KEY.BACKSPACE, Backspace]);
      ___ (____, [Press, UTILS.KBD.KEY.CONTEXTMENU, ContextMenu]);
      ___ (____, [Press, UTILS.KBD.KEY.CONTROL, PressControl]);
      ___ (____, [Press, UTILS.KBD.KEY.DELETE, Delete]);
      ___ (____, [Press, UTILS.KBD.KEY.ENTER, Enter]);
      ___ (____, [Press, UTILS.KBD.KEY.F1, F1]);
      ___ (____, [Press, UTILS.KBD.KEY.F11, F11]);
      ___ (____, [Press, UTILS.KBD.KEY.TAB, Tab]);
      ___ (____, [Press, UTILS.KBD.KEY.PAGEDOWN, PageDown]);
      ___ (____, [Press, UTILS.KBD.KEY.PAGEUP, PageUp]);
      ___ (____, [Press, UTILS.KBD.KEY.SHIFT, PressShift]);

      ___ (____, [Release, UTILS.KBD.KEY.OS, OS]);
      ___ (____, [Release, UTILS.KBD.KEY.ALT, ReleaseAlt]);
      ___ (____, [Release, UTILS.KBD.KEY.ALTGRAPH, ReleaseAltGraph]);
      ___ (____, [Release, UTILS.KBD.KEY.CONTROL, ReleaseControl]);
      ___ (____, [Release, UTILS.KBD.KEY.END, End]);
      ___ (____, [Release, UTILS.KBD.KEY.F2, F2]);
      ___ (____, [Release, UTILS.KBD.KEY.F8, F8]);
      ___ (____, [Release, UTILS.KBD.KEY.F9, F9]);
      ___ (____, [Release, UTILS.KBD.KEY.F10, F10]);
      ___ (____, [Release, UTILS.KBD.KEY.HOME, Home]);
      ___ (____, [Release, UTILS.KBD.KEY.INSERT, Insert]);
      ___ (____, [Release, UTILS.KBD.KEY.SHIFT, ReleaseShift]);
      ___ (____, [Release, UTILS.KBD.KEY.SCROLLLOCK, ScrollLock]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefinePrintKeyFunctions () {
      let startPrintKeys = 32;
      let stopPrintKeys  = 126;

      ___ (GenerateKeyFunctions, [startPrintKeys, stopPrintKeys, PrintKey], Printable);
      ___ (____, [Printable, UTILS.KBD.KEY.MINUS_SIGN, MinusSign]);
      ___ (____, [Printable, UTILS.KBD.KEY.PLUS_SIGN, PlusSign]);
      ___ (____, [Printable, UTILS.KBD.KEY.LOWERCASE_C, LowercaseC]);
      ___ (____, [Printable, UTILS.KBD.KEY.LOWERCASE_F, LowercaseF]);
      ___ (____, [Printable, UTILS.KBD.KEY.LOWERCASE_I, LowercaseI]);
      ___ (____, [Printable, UTILS.KBD.KEY.LOWERCASE_K, LowercaseK]);
      ___ (____, [Printable, UTILS.KBD.KEY.LOWERCASE_O, LowercaseO]);
      ___ (____, [Printable, UTILS.KBD.KEY.LOWERCASE_P, LowercaseP]);
      ___ (____, [Printable, UTILS.KBD.KEY.LOWERCASE_S, LowercaseS]);
      ___ (____, [Printable, UTILS.KBD.KEY.LOWERCASE_V, LowercaseV]);
      ___ (____, [Printable, UTILS.KBD.KEY.LOWERCASE_X, LowercaseX]);
      ___ (____, [Printable, UTILS.KBD.KEY.UPPERCASE_C, UppercaseC]);
      ___ (____, [Printable, UTILS.KBD.KEY.UPPERCASE_F, UppercaseF]);
      ___ (____, [Printable, UTILS.KBD.KEY.UPPERCASE_I, UppercaseI]);
      ___ (____, [Printable, UTILS.KBD.KEY.UPPERCASE_K, UppercaseK]);
      ___ (____, [Printable, UTILS.KBD.KEY.UPPERCASE_O, UppercaseO]);
      ___ (____, [Printable, UTILS.KBD.KEY.UPPERCASE_P, UppercaseP]);
      ___ (____, [Printable, UTILS.KBD.KEY.UPPERCASE_S, UppercaseS]);
      ___ (____, [Printable, UTILS.KBD.KEY.UPPERCASE_V, UppercaseV]);
      ___ (____, [Printable, UTILS.KBD.KEY.UPPERCASE_X, UppercaseX]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandlePress (event=__) {
    /************************************************************************************
    * The function which handles command keys for the paper process 
    ************************************************************************************/
      let that = this;
      let Command = ___ (GetKeyFunction, [event.key, UTILS.PRESS], that);

      ___ (SetJustifyViewport, _, that);
      ___ (Command, [event], that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandleRelease (event=__) {
    /************************************************************************************
    * The function which handles release keys for the paper process 
    ************************************************************************************/
      let that    = this;
      let Command = ___ (GetKeyFunction, [event.key, UTILS.RELEASE], that);
      return ___ (Command, [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandlePrint (event=__) {
    /************************************************************************************
    * The function which handles printable character keys for the paper process 
    ************************************************************************************/
      let that = this;
      let PrintableKey = ___ (GetKeyFunction, [event.key], that);

      ___ (SetJustifyViewport, _, that);

      return ___ (PrintableKey, [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CalculateViewCapacity () {
      let that = this;

      BMARGIN      = ___ (PAINTER.GetCanvasHeight) - 2 * LINEHEIGHT;
      VIEWCAPACITY = (BMARGIN - (BMARGIN % LINEHEIGHT)) / LINEHEIGHT;

      return __;
    }    

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UseFileContents (event=__) {
      let that = this;

      ___ (RetrieveFile);
      ___ (RetrieveFileLine);
      ___ (RetrieveFileCursor);

      FILESEGEND   = LINE;
      FILESEGBEGIN = 1 + (FILESEGEND - VIEWCAPACITY);
      LINESTART    = 0;

      if (FILESEGBEGIN < 0) { FILESEGBEGIN = 0; }

      ___ (PersistClipboardCursor);
      ___ (PersistClipboardLine);
      ___ (PersistViewportStart);
      ___ (PersistViewportEnd);
      ___ (PersistViewportLineStart);
      ___ (ReWrite, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=__) {
      let thatpaper = this;

      function Help (event=__, otherEscape=__) {
        let that = this;
        let Exit = ___ (GetKeyFunction, [UTILS.KBD.KEY.ESCAPE, UTILS.RELEASE], thatpaper);

        if (otherEscape !== __) { Exit = otherEscape; }

        ___ (PersistFile);
        ___ (PersistFileLine);
        ___ (PersistFileCursor);
        ___ (PressControl, _, that);
        ___ (End, _, that);
        ___ (ReleaseControl, _, that);
        ___ (PersistClipboardCursor);
        ___ (PersistClipboardLine);
        ___ (Enter, _, that);
        ___ (Helper, _, that);
        ___ (Exit, _, that);

        return __;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LeadWithSpaces (number=__, max=__) {
      let paddedValue = number + UTILS.KBD.KEY.WHITESPACE;
      let maxlength = (UTILS.BLANKCHAR + max).length;
      let blocks = 1 + maxlength - paddedValue.length;

      while (blocks > 0) {
        paddedValue = UTILS.KBD.KEY.WHITESPACE + paddedValue;
        blocks = blocks - 1;
      }

      return paddedValue;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SkipWordMoveCursor (spaceCharSide=__) {
      let that      = this;
      let chars     = __;
      let line      = __;
      let spaceChar = UTILS.KBD.KEY.WHITESPACE;
      let LEFT      = 0;
      let RIGHT     = 1;

      line = FILE [LINE];

      if ((LEFT === spaceCharSide) || (spaceCharSide === RIGHT)) {
        if (spaceCharSide === RIGHT) {
          for (let o = CURSOR; o <= line.length - 2; o ++) {
            chars = line.substring (o, o+2);

            if ((chars.charAt (RIGHT) === spaceChar) && (chars.charAt (LEFT) !== spaceChar)) {
              return (o+1);
            }
          }

          return line.length;
        }
        else {
          for (let o = CURSOR; o >= 2; o --) {
            chars = line.substring (o-2, o);

            if ((chars.charAt (LEFT) === spaceChar) && (chars.charAt (RIGHT) !== spaceChar)) {
              return (o-1);
            }
          }

          return LEFT;
        }
      }

      return (-RIGHT);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function TextSelected () {
      let fromLine = ___ (CLIPBOARD.GetLine);
      let fromCursor = ___ (CLIPBOARD.GetCursor);
      let differentLines = (fromLine !== LINE);
      let differentCursors = (fromCursor !== CURSOR);

      return (differentLines || differentCursors);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DeleteSelectionFromFile () {
      let fromLine = ___ (CLIPBOARD.GetLine);
      let fromCursor = ___ (CLIPBOARD.GetCursor);
      let toLine = fromLine;
      let toCursor = fromCursor;
      let shorterFile = new Array ();
      let differentLines = __;
      let differentCursors = __;

      if (fromLine !== LINE) {
        if (fromLine > LINE) {
          fromLine = LINE;
          fromCursor = CURSOR;
        }
        else {
          toLine = LINE;
          toCursor = CURSOR;
        }

        FILE [fromLine] = FILE [fromLine].substring (0, fromCursor);
        FILE [toLine] = FILE [toLine].substring (toCursor, FILE [toLine].length);

        ___ (____, [FILE, LINE, (FILE [fromLine] + FILE [toLine])]);
      }
      else {
        let sublineA = FILE [fromLine];
        let sublineB = FILE [toLine];

        toCursor = CURSOR;

        if (fromCursor > toCursor) {
          fromCursor = fromCursor + toCursor;
          toCursor = fromCursor - toCursor;
          fromCursor = fromCursor - toCursor;
        }

        sublineA = sublineA.substring (0, fromCursor);
        sublineB = sublineB.substring (toCursor, sublineB.length);

        ___ (____, [FILE, LINE, (sublineA + sublineB)]);
      }

      LINE = fromLine;
      CURSOR = fromCursor;
      differentCursors = (fromCursor !== toCursor);
      differentLines = (fromLine !== toLine);

      if (differentLines || differentCursors) {
        for (let i = 0; i <FILE.length; i ++) {
          if ((i <= fromLine) || (i > toLine)) { shorterFile.push (FILE [i]); }
        }

        FILE = shorterFile;
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFirstWordOnLastLine () {
      let index = FILE.length - 1;
      let text = FILE [index].split (UTILS.KBD.KEY.WHITESPACE);

      text = ___ (UTILS.Filter, [UTILS.BLANKCHAR, text]);
      text = ___ (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, text]);
      text = text [0];

      return text;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ReportUpdateSuccess (evt=__) {
      let that = this;
      console.log ("External clipboard updated sucessfully!");
      return __;
    }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function CopyTextToClipboard () {
        let that = this;
        let fromLine = ___ (CLIPBOARD.GetLine);
        let toLine = fromLine + 1;
        let fromCursor = ___ (CLIPBOARD.GetCursor);
        let toCursor = fromCursor;
        let clippedText = __;
        let clippedLine = __;

        if (fromLine < LINE) {
          toLine = LINE + 1;
          toCursor = CURSOR;
        }
        else if (fromLine > LINE) {
          fromLine = LINE;
          fromCursor = CURSOR;
        }

        if ((fromLine + 1) === toLine) {
          toCursor = CURSOR;

          if (fromCursor > toCursor) {
            fromCursor = fromCursor + toCursor;
            toCursor = fromCursor - toCursor;
            fromCursor = fromCursor - toCursor;
          }

          clippedText = FILE.slice (fromLine, toLine);
          fromLine = clippedText [0];
          clippedLine = fromLine.substring (fromCursor, toCursor);

          ___ (____, [clippedText, 0, clippedLine]);
        }
        else {
          clippedText = FILE.slice (fromLine, toLine);
          fromLine = clippedText [0];
          clippedLine = fromLine.substring (fromCursor, fromLine.length);

          ___ (____, [clippedText, 0, clippedLine]);

          toLine = clippedText [clippedText.length - 1];
          clippedLine = toLine.substring (0, toCursor);
          toCursor = clippedText.length - 1;

          ___ (____, [clippedText, toCursor, clippedLine]);
        }

        ___ (CLIPBOARD.SetText, [clippedText]);

        return __;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function SearchFileFromTopToBottom () {
        let that = this;
        let filesize = FILE.length;
        let keyword = FILE [filesize - 1];
        let initCursor = CURSOR;
        let initLine = LINE;
        let currentCursor = initCursor;
        let currentLine = initLine;
        let EOF = filesize;
        let BOF = 0;
        let delta = 1;
        let searchArguments = new Array ();

        ___ (____, [searchArguments, 0, keyword]);
        ___ (____, [searchArguments, 1, currentLine]);
        ___ (____, [searchArguments, 2, currentCursor]);
        ___ (____, [searchArguments, 3, initLine]);
        ___ (SearchLineFromLeftToRight, searchArguments, that);

        if ((LINE === initLine) && (CURSOR === initCursor)) {

          currentLine = initLine + delta;
          currentCursor = 0;

          while (currentLine !== initLine) {
            if (currentLine === EOF) { currentLine = BOF; }

            ___ (____, [searchArguments, 1, currentLine]);
            ___ (____, [searchArguments, 2, currentCursor]);

            currentLine = ___ (SearchLineFromLeftToRight, searchArguments, that);

            if (currentLine !== initLine) {
              currentCursor = 0;
              currentLine = currentLine + delta;
            }
            else {
              ___ (JustifyViewport);
              ___ (HighlightKeyword, [keyword, filesize], that);
            }
          }
        }
        else {
          ___ (JustifyViewport);
          ___ (HighlightKeyword, [keyword, filesize], that);
        }

        return __;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function SearchLineFromLeftToRight (keyword=__, linenumber=__, cursorPosition=__, eoc=__) {
        let that        = this;
        let sentence    = FILE [linenumber];
        let k           = keyword.length;
        let textSegment = __;

        for (let j = cursorPosition; (sentence.length >= k) && (j + k <= sentence.length); j ++) {
          textSegment = sentence.substring (j, j + k);

          if (keyword === textSegment) {
            LINE       = linenumber;
            CURSOR     = j + k;
            j          = sentence.length;
            linenumber = eoc;
          }
        }

        return linenumber;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function SearchFileFromBottomToTop () {
        let that = this;
        let filesize = FILE.length;
        let keyword = FILE [filesize - 1];
        let initCursor = CURSOR;
        let initLine = LINE;
        let currentCursor = initCursor;
        let currentLine = initLine;
        let EOF = -1;
        let BOF = filesize - 1;
        let delta = -1;
        let searchArguments = new Array ();

        ___ (____, [searchArguments, 0, keyword]);
        ___ (____, [searchArguments, 1, currentLine]);
        ___ (____, [searchArguments, 2, currentCursor]);
        ___ (____, [searchArguments, 3, initLine]);
        ___ (SearchLineFromRightToLeft, searchArguments, that);

        if ((LINE === initLine) && (CURSOR === initCursor)) {

          currentLine = initLine + delta;

          if (currentLine === EOF) { currentLine = BOF; }

          currentCursor = FILE [currentLine].length;

          while (currentLine !== initLine) {
            ___ (____, [searchArguments, 1, currentLine]);
            ___ (____, [searchArguments, 2, currentCursor]);
            currentLine = ___ (SearchLineFromRightToLeft, searchArguments, that);

            if (currentLine !== initLine) {
              currentLine = currentLine + delta;

              if (currentLine === EOF) { currentLine = BOF; }  

              currentCursor = FILE [currentLine].length;
            }
            else {
              ___ (JustifyViewport);
              ___ (HighlightKeyword, [keyword, filesize, -delta], that);
            }
          }
        }
        else {
          ___ (JustifyViewport);
          ___ (HighlightKeyword, [keyword, filesize, -delta], that);
        }

        return __;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function SearchLineFromRightToLeft (keyword=__, linenumber=__, cursorPosition=__, eoc=__) {
        let that        = this;
        let sentence    = FILE [linenumber];
        let k           = keyword.length;
        let textSegment = __;

        for (let j = cursorPosition; (sentence.length >= k) && (j >= k); j = j - 1) {
          textSegment = sentence.substring (j - k, j);

          if (keyword === textSegment) {
            LINE       = linenumber;
            CURSOR     = j - k;
            j          = -1;
            linenumber = eoc;
          }
        }

        return linenumber;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function HighlightKeyword (keyword=__, filesize=__, displacement=__) {
        let that = this;

        if (displacement === __) { displacement = 0; }

        ___ (UnsetRequireRewrite, _, that);
        // TO HIGHLIGHT keyword FOUND:
        // figure out the width of the text from the start of the current line to the CURSOR
        let startOfKeyword = CURSOR + displacement - keyword.length;
        let padding = ___ (LeadWithSpaces, [LINE, filesize]);
        let subLine = padding + FILE [LINE].substring (LINESTART, startOfKeyword);
        let keywordX = LMARGIN + ___ (PAINTER.MeasureText, [subLine]);
        let keywordY = TMARGIN + (LINE - FILESEGBEGIN) * LINEHEIGHT;
        // figure out the width of the keyword
        let keywordWidth = ___ (PAINTER.MeasureText, [keyword]);
        let keywordHeight = LINEHEIGHT;
        // extract the background color, and then extract the foreground color
        let formerBGColor = ___ (PAINTER.GetFillColor);
        let formerFGColor = ___ (PAINTER.GetStrokeColor);
        // rewrite the entire text on the screen
        ___ (ReWrite, _, that);
        // set the background color to the extracted foreground color
        ___ (PAINTER.SetFillColorTo, [FGCOLOR]);
        // set the foreground color to the extracted background color
        ___ (PAINTER.SetStrokeColorTo, [BGCOLOR]);
        // draw a rectangle and fill it in with the set background color
        ___ (PAINTER.PaintBackGround, [keywordX, keywordY - (keywordHeight/5), keywordWidth, keywordHeight]);
        // reset the background color to the extracted background color
        ___ (PAINTER.SetFillColorTo, [BGCOLOR]);
        // reset the foreground color to the extracted foreground color
        ___ (PAINTER.SetStrokeColorTo, [FGCOLOR]);
        // write the keyword so that it is colored with the set foreground color
        ___ (PAINTER.FillText, [keyword, keywordX, keywordY]);

        return __;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function PasteTextFromClipboard () {
        let that = this;
        let preCut = FILE.slice (0, LINE + 1);
        let postCut = FILE.slice (LINE, FILE.length);
        let clippedText = ___ (CLIPBOARD.GetText);
        let splitLine = preCut [LINE];

        if (clippedText.length === 1) {
          splitLine = splitLine.substring (0, CURSOR);
          splitLine = splitLine + clippedText [0];
          clippedText = postCut [0];
          clippedText = clippedText.substring (CURSOR, clippedText.length);
          CURSOR = splitLine.length;
          splitLine = splitLine + clippedText;

          preCut.pop ();

          preCut = preCut.concat (postCut);

          ___ (____, [preCut, LINE, splitLine]);

          FILE = preCut;
        }
        else {
          splitLine = splitLine.substring (0, CURSOR);
          splitLine = splitLine + clippedText [0];
          ___ (____, [preCut, LINE, splitLine]);

          splitLine = postCut [0];
          splitLine = splitLine.substring (CURSOR, splitLine.length);
          CURSOR = clippedText.length - 1;
          splitLine = clippedText [CURSOR] + splitLine;
          ___ (____, [postCut, 0, splitLine]);

          CURSOR = clippedText [CURSOR].length;
          LINE = (LINE + clippedText.length) - 1;
          clippedText = clippedText.slice (1, clippedText.length - 1);
          clippedText = preCut.concat (clippedText);
          FILE = clippedText.concat (postCut);
        }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LaunchFullscreen () {
      let that    = this;
      let element = UTILS.WIN.DOC.documentElement;

      if (element.requestFullscreen      ) { element.requestFullscreen      (); } else
      if (element.mozRequestFullScreen   ) { element.mozRequestFullScreen   (); } else
      if (element.webkitRequestFullscreen) { element.webkitRequestFullscreen(); } else
      if (element.msRequestFullscreen    ) { element.msRequestFullscreen    (); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ExitFullscreen () {
      let that = this;

      if (UTILS.WIN.DOC.exitFullscreen      ) { UTILS.WIN.DOC.exitFullscreen      (); } else
      if (UTILS.WIN.DOC.mozCancelFullScreen ) { UTILS.WIN.DOC.mozCancelFullScreen (); } else
      if (UTILS.WIN.DOC.webkitExitFullscreen) { UTILS.WIN.DOC.webkitExitFullscreen(); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UpdateFontSize (amount=__) {
      let that      = this;
      let fontUnits = UTILS.BLANKCHAR;
      let fontArray = FONT.split (UTILS.KBD.KEY.WHITESPACE);
      let fontSize  = fontArray [0].split (UTILS.BLANKCHAR);
      let deltaSize = amount / amount;
      let tmpFont   = __;

      fontUnits = fontSize.pop () + fontUnits;
      fontUnits = fontSize.pop () + fontUnits;
      fontSize  = fontSize.join (UTILS.BLANKCHAR);
      fontSize  = ___ (UTILS.ToNumber, [__, fontSize]);

      if (amount < 0) { deltaSize = -1 * deltaSize; }

      fontSize   = fontSize + deltaSize;
      tmpFont    = fontSize + fontUnits + UTILS.KBD.KEY.WHITESPACE + fontArray [1];

      ___ (SetLineHeight, [LINEHEIGHT + deltaSize]);
      ___ (SetFont, [tmpFont]);
      ___ (CalculateViewCapacity);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function JustifyViewport () {
      let that = this;

      ___ (VIEWPORT.AdjustPosition, [FILE.length, LINE, CURSOR]);
      ___ (RetrieveViewportStart);
      ___ (RetrieveViewportEnd);
      ___ (RetrieveViewportLineStart);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

   function PrintCharacter (key=__) {
      let that          = this;
      let currentline   = __;
      let endOfThisLine = __;
      let subline       = __;

      if (INSERT && (CURSOR < FILE [LINE].length)) { ___ (Delete, _, that); }
      else if (___ (TextSelected)) { ___ (DeleteSelectionFromFile); }

      currentline = FILE [LINE];
      endOfThisLine = currentline.length;
      subline = currentline.substring (0, CURSOR);

      ___ (____, [FILE, LINE, subline + key]);

      subline = currentline.substring (CURSOR, endOfThisLine);

      ___ (____, [FILE, LINE, FILE [LINE] + subline]);

      CURSOR = CURSOR + key.length;

      if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PrintKey (event) {
      let that = this;
      ___ (PrintCharacter, [event.key], that);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function NonPrintCharacter (key=__) {
    /************************************************************************************
    * The function which determines whether a character is non-printable 
    ************************************************************************************/
      let invisibility = false;

      switch (key) {
        case UTILS.KBD.KEY.ALT                : invisibility = true; break;
        case UTILS.KBD.KEY.ALTGRAPH           : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWDOWN          : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWLEFT          : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWRIGHT         : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWUP            : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEDOWN    : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEMUTE    : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEUP      : invisibility = true; break;
        case UTILS.KBD.KEY.BACKSPACE          : invisibility = true; break;
        case UTILS.KBD.KEY.CAPSLOCK           : invisibility = true; break;
        case UTILS.KBD.KEY.CONTROL            : invisibility = true; break;
        case UTILS.KBD.KEY.CONTEXTMENU        : invisibility = true; break;
        case UTILS.KBD.KEY.DELETE             : invisibility = true; break;
        case UTILS.KBD.KEY.END                : invisibility = true; break;
        case UTILS.KBD.KEY.ENTER              : invisibility = true; break;
        case UTILS.KBD.KEY.ESCAPE             : invisibility = true; break;
        case UTILS.KBD.KEY.F1                 : invisibility = true; break;
        case UTILS.KBD.KEY.F2                 : invisibility = true; break;
        case UTILS.KBD.KEY.F3                 : invisibility = true; break;
        case UTILS.KBD.KEY.F4                 : invisibility = true; break;
        case UTILS.KBD.KEY.F5                 : invisibility = true; break;
        case UTILS.KBD.KEY.F6                 : invisibility = true; break;
        case UTILS.KBD.KEY.F7                 : invisibility = true; break;
        case UTILS.KBD.KEY.F8                 : invisibility = true; break;
        case UTILS.KBD.KEY.F9                 : invisibility = true; break;
        case UTILS.KBD.KEY.F10                : invisibility = true; break;
        case UTILS.KBD.KEY.F11                : invisibility = true; break;
        case UTILS.KBD.KEY.F12                : invisibility = true; break;
        case UTILS.KBD.KEY.HOME               : invisibility = true; break;
        case UTILS.KBD.KEY.INSERT             : invisibility = true; break;
        case UTILS.KBD.KEY.INTERNALCALL       : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIAPLAY          : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIATRACKNEXT     : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIATRACKPREVIOUS : invisibility = true; break;
        case UTILS.KBD.KEY.NUMLOCK            : invisibility = true; break;
        case UTILS.KBD.KEY.OS                 : invisibility = true; break;
        case UTILS.KBD.KEY.PAGEDOWN           : invisibility = true; break;
        case UTILS.KBD.KEY.PAGEUP             : invisibility = true; break;
        case UTILS.KBD.KEY.SHIFT              : invisibility = true; break;
        case UTILS.KBD.KEY.SCROLLLOCK         : invisibility = true; break;
        case UTILS.KBD.KEY.TAB                : invisibility = true; break;
        case UTILS.KBD.KEY.UNIDENTIFIED       : invisibility = true; break;
      }

      return invisibility;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PressKey (key=__) {
    /************************************************************************************
    * The function which determines whether a character is treated as a command 
    ************************************************************************************/
      let status = false;

      switch (key) {
        case UTILS.KBD.KEY.ALT                : status = true; break;
        case UTILS.KBD.KEY.ALTGRAPH           : status = true; break;
        case UTILS.KBD.KEY.ARROWDOWN          : status = true; break;
        case UTILS.KBD.KEY.ARROWLEFT          : status = true; break;
        case UTILS.KBD.KEY.ARROWRIGHT         : status = true; break;
        case UTILS.KBD.KEY.ARROWUP            : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEDOWN    : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEMUTE    : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEUP      : status = true; break;
        case UTILS.KBD.KEY.BACKSPACE          : status = true; break;
        case UTILS.KBD.KEY.CONTEXTMENU        : status = true; break;
        case UTILS.KBD.KEY.CONTROL            : status = true; break;
        case UTILS.KBD.KEY.DELETE             : status = true; break;
        case UTILS.KBD.KEY.ENTER              : status = true; break;
        case UTILS.KBD.KEY.F1                 : status = true; break;
        case UTILS.KBD.KEY.F5                 : status = true; break;
        case UTILS.KBD.KEY.F6                 : status = true; break;
        case UTILS.KBD.KEY.F11                : status = true; break;
        case UTILS.KBD.KEY.MEDIAPLAY          : status = true; break;
        case UTILS.KBD.KEY.MEDIATRACKNEXT     : status = true; break;
        case UTILS.KBD.KEY.MEDIATRACKPREVIOUS : status = true; break;
        case UTILS.KBD.KEY.PAGEDOWN           : status = true; break;
        case UTILS.KBD.KEY.PAGEUP             : status = true; break;
        case UTILS.KBD.KEY.TAB                : status = true; break;
        case UTILS.KBD.KEY.SHIFT              : status = true; break;
      // add cases to handle other command keys
      }

      return status;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ReleaseKey (key=__) {
      let that   = this;
      let status = false;

      switch (key) {
        case UTILS.KBD.KEY.ALT       : status = true; break;
        case UTILS.KBD.KEY.ALTGRAPH  : status = true; break;
        case UTILS.KBD.KEY.CONTROL   : status = true; break;
        case UTILS.KBD.KEY.END       : status = true; break;
        case UTILS.KBD.KEY.ESCAPE    : status = true; break;
        case UTILS.KBD.KEY.F2        : status = true; break;
        case UTILS.KBD.KEY.F8        : status = true; break;
        case UTILS.KBD.KEY.F9        : status = true; break;
        case UTILS.KBD.KEY.F10       : status = true; break;
        case UTILS.KBD.KEY.HOME      : status = true; break;
        case UTILS.KBD.KEY.INSERT    : status = true; break;
        case UTILS.KBD.KEY.OS        : status = true; break;
        case UTILS.KBD.KEY.SHIFT     : status = true; break;
        case UTILS.KBD.KEY.SCROLLLOCK: status = true; break;
      }

      return status;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function InternalCall () {
    /************************************************************************************
    * The function which performs arbitrary tasks wherever ...
    ************************************************************************************/
      let that = this;
      console.log ("[INTERNAL CALL]", FILE [0]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PressAlt (event=__) {
      let that = this;

      ALTDOWN = true;

      ___ (UnsetEditing, _, that);
      ___ (UnsetJustifyViewport, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PressAltGraph (event=__) {
      let that = this;

      ALTGRAPHDOWN = true;

      ___ (UnsetEditing, _, that);
      ___ (UnsetJustifyViewport, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ArrowLeft (event=__) {
    /************************************************************************************
    * The function which moves the cursor to the left
    ************************************************************************************/
      let that = this;

      if (CONTROLDOWN) {
        let LEFT = 0;

        if (CURSOR === 0) {
          ___ (ReleaseControl, _, that);
          ___ (ArrowLeft, _, that); 
          ___ (PressControl, _, that);
        }
        else { CURSOR = ___ (SkipWordMoveCursor, [LEFT], that); }
      }
      else {
        if (CURSOR > 0) { CURSOR = CURSOR - 1; }
        else {
          let scrollLockActive = SCROLLLOCK;

          if (scrollLockActive) { ___ (ScrollLock, _, that); }

          ___ (ArrowUp, _, that);
          ___ (End, _, that);

          if (scrollLockActive) { ___ (ScrollLock, _, that); }
        }
      }

      if (SHIFTDOWN) { ___ (UnsetEditing, _, that); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ArrowUp (event=__) {
    /************************************************************************************
    * The function which moves the cursor to the next line above 
    ************************************************************************************/
      let that = this;

      if (SCROLLLOCK && !CONTROLDOWN) {
        ___ (DisplaceViewportVertically, [3], that);
        ___ (UnsetJustifyViewport, _, that);
      }
      else if (SHIFTDOWN && CONTROLDOWN) {
        let tmpline      = __;
        let currentline  = LINE;
        let previousline = currentline - 1;

        if (previousline >= 0) {
          tmpline = FILE [previousline];

          ___ (____, [FILE, previousline, FILE [currentline]]);
          ___ (____, [FILE, currentline, tmpline]);

          LINE = previousline;
        }
      }
      else if (CONTROLDOWN) {
        ___ (ReleaseControl, _, that);
        ___ (DisplaceViewportVertically, [3], that);
        ___ (PressControl, _, that);
        ___ (UnsetJustifyViewport, _, that);

        if (LINE > FILESEGEND) { LINE = FILESEGEND; }
        if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }

        ___ (PersistClipboardCursor);
        ___ (PersistClipboardLine);
      }
      else {
        if (LINE > 0) {
          LINE = LINE - 1;
          if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }
        }

        if (SHIFTDOWN) { ___ (UnsetEditing, _, that); }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ArrowDown (event=__) {
    /************************************************************************************
    * The function which moves the cursor to the next line below
    ************************************************************************************/
      let that = this;

      if (SCROLLLOCK && !CONTROLDOWN) {
        ___ (DisplaceViewportVertically, [-3], that);
        ___ (UnsetJustifyViewport, _, that);
      }
      else if (SHIFTDOWN && CONTROLDOWN) {
        let currentline = LINE;
        let nextline = currentline + 1;

        if (nextline < FILE.length) {
          let tmpline = FILE [nextline];

          ___ (____, [FILE, nextline, FILE [currentline]]);
          ___ (____, [FILE, currentline, tmpline]);

          LINE = nextline;
        }
      }
      else if (CONTROLDOWN) {
        ___ (ReleaseControl, _, that);
        ___ (DisplaceViewportVertically, [-3], that);
        ___ (PressControl, _, that);
        ___ (UnsetJustifyViewport, _, that);

        if (LINE < FILESEGBEGIN) { LINE = FILESEGBEGIN; }
        if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }

        ___ (PersistClipboardCursor);
        ___ (PersistClipboardLine);
      }
      else {
        if ((LINE + 1) < FILE.length) {
          LINE = LINE + 1; 
          if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }
        }

        if (SHIFTDOWN) { ___ (UnsetEditing, _, that); }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ArrowRight (event=__) {
    /************************************************************************************
    * The function which moves the cursor to the right 
    ************************************************************************************/
      let that = this;

      if (CONTROLDOWN) {
        let RIGHT = 1;

        if (CURSOR === FILE [LINE].length) {
          ___ (ReleaseControl, _, that);
          ___ (ArrowRight, _, that);
          ___ (PressControl, _, that);
        }
        else { CURSOR = ___ (SkipWordMoveCursor, [RIGHT], that); }
      }
      else {
        if (CURSOR < FILE [LINE].length) { CURSOR = CURSOR + 1; }
        else {
          let scrollLockActive = SCROLLLOCK;

          if (scrollLockActive) { ___ (ScrollLock, _, that); }

          ___ (ArrowDown, _, that);
          ___ (Home, _, that);

          if (scrollLockActive) { ___ (ScrollLock, _, that); }

          ___ (Home, _, that);
        }
      }

      if (SHIFTDOWN) { ___ (UnsetEditing, _, that); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Backspace (event=__) {
      let that = this;

      if (___ (TextSelected)) { ___ (DeleteSelectionFromFile); }
      else if (SHIFTDOWN) {
        let DeleteLine = F9;

        ___ (ReleaseShift, _, that);
        ___ (DeleteLine, _, that);
        ___ (PersistClipboardCursor);
        ___ (PersistClipboardLine);
        ___ (Backspace, _, that);
        ___ (PersistClipboardCursor);
        ___ (PersistClipboardLine);
        ___ (PressShift, _, that);
        ___ (SetJustifyViewport, _, that);
      }
      else {
        let leftbit = __;
        let midbit = __;
        let rightbit = __;

        if (CURSOR > 0) {
          let line = FILE [LINE].substring (0, CURSOR - 1);

          line = line + FILE [LINE].substring (CURSOR, FILE [LINE].length);
          CURSOR = CURSOR - 1;

          ___ (____, [FILE, LINE, line]);
        }
        else if (LINE > 0) {
          leftbit = FILE.splice (0, LINE);
          midbit = FILE.splice (0,1);
          rightbit = FILE.splice (0);
          FILE = leftbit.concat (rightbit);
          LINE = LINE - 1;
          CURSOR = FILE [LINE].length;

          ___ (____, [FILE, LINE, FILE [LINE] + midbit]);
        }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ContextMenu (event=__) {
      let that = this;

      ___ (UnsetEditing, _, that);
      ___ (UnsetJustifyViewport, _, that);
      ___ (UnsetPreventDefault, _, that);
      ___ (UnsetRequireRewrite, _, that);
      ___ (UnsetStopPropagation, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PressControl (event=__) {
      let that = this;

      CONTROLDOWN = true;

      ___ (UnsetEditing, _, that);
      ___ (UnsetJustifyViewport, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Delete (event=__) {
    /************************************************************************************
    * The function which removes one character to the right of the cursor
    ************************************************************************************/
      let that = this;
      let line = FILE [LINE];

      if (___ (TextSelected)) { ___ (DeleteSelectionFromFile); }
      else if (CURSOR < line.length) {
        line = FILE [LINE].substring (0, CURSOR);
        line = line + FILE [LINE].substring (CURSOR + 1, FILE [LINE].length);

        ___ (____, [FILE, LINE, line]);

        if (CURSOR > FILE [LINE].length) { CURSOR -= 1; }
      }
      else if ((LINE + 1) < FILE.length) {
        let shiftKeyDown     = SHIFTDOWN;
        let scrollLockActive = SCROLLLOCK;

        if (shiftKeyDown) { ___ (ReleaseShift, _, that); }
        if (scrollLockActive) { ___ (ScrollLock, _, that); }

        ___ (ArrowDown, _, that);
        ___ (End, _, that);

        if (scrollLockActive) { ___ (ScrollLock, _, that); }

        ___ (Home, _, that);
        ___ (PersistClipboardCursor);
        ___ (PersistClipboardLine);
        ___ (Backspace, _, that);

        if (shiftKeyDown) { ___ (PressShift, _, that); }
      }

      ___ (PersistClipboardCursor);
      ___ (PersistClipboardLine);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Enter () {
    /************************************************************************************
    * The function which moves the cursor to the next line
    ************************************************************************************/
      let that         = this;
      let leftbit      = __;
      let rightbit     = __;
      let leftsubline  = __;
      let rightsubline = __;
      let START        = 0;

      if (___ (TextSelected)) { ___ (DeleteSelectionFromFile); }

      leftbit  = FILE.splice (START, LINE);
      rightbit = FILE.splice (START);

      leftbit.push (UTILS.BLANKCHAR);

      leftsubline  = rightbit [START].substring (START, CURSOR);
      rightsubline = rightbit [START].substring (CURSOR, rightbit [START].length);

      ___ (____, [leftbit, (leftbit.length - 1), leftsubline]);
      ___ (____, [rightbit, START, rightsubline]);

      FILE      = leftbit.concat (rightbit);
      CURSOR    = START;
      LINESTART = CURSOR;
      LINE      = LINE + 1;

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F1 () {
      /************************************************************************************
      * The function which displays the help text for the paper process
      ************************************************************************************/
        let that     = this;
        let helper   = EXPLAIN + that.id;
        let NOTFOUND = -1;

        if (that.id.indexOf (EXPLAIN) === NOTFOUND) {
          ___ (____, [FILE, LINE, FILE [LINE] + helper]);
        }

        CURSOR = FILE [LINE].length;

        ___ (PersistFile);
        ___ (PersistFileLine);
        ___ (PersistFileCursor);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F11 () {
      /************************************************************************************
      * The function which requests maximum screen for the paper process
      ************************************************************************************/
        let that = this;

        ___ (CalculateViewCapacity);
        ___ (UnsetEditing, _, that);
        ___ (UnsetPreventDefault, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function Tab (event=__) {
      /************************************************************************************
      * The function which adds a tab-equivalent-of-spaces to the current line
      ************************************************************************************/
        let that = this;
        let fakeEvent = ___ (UTILS.CloneMap);

        if (___ (TextSelected)) { ___ (DeleteSelectionFromFile); }

        ___ (____, [fakeEvent, "key", UTILS.KBD.KEY.WHITESPACE]);

        for (let i = 0; i < TABSIZE; i ++) {
          ___ (PersistClipboardLine);
          ___ (PersistClipboardCursor)
          ___ (HandlePrint, [fakeEvent], that);
        }

        ___ (SetPreventDefault, _, that);
        ___ (SetStopPropagation, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function PageDown (event=__) {
      /************************************************************************************
      * The function which increases the length of the kanvas
      ************************************************************************************/
        let that = this;

        if (ALTDOWN) { ___ (PAINTER.ChangeCanvasHeightBy, [LINEHEIGHT]); }
        else if (CONTROLDOWN) { ___ (PAINTER.HideCanvas); }
        else {
          let linesFromEnd = FILESEGEND - LINE;
          let i = __;

          LINE = FILESEGEND;

          for (i = 0; ((LINE + 1) < FILE.length) && (i < VIEWCAPACITY); i ++) { LINE = LINE + 1; }

          if (i === VIEWCAPACITY) {
            ___ (JustifyViewport);

            LINE = LINE - linesFromEnd;
          }
          if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }
          if (SHIFTDOWN) { ___ (UnsetEditing, _, that); }
        }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function PageUp (event=__) {
      /************************************************************************************
      * The function which increases the length of the kanvas
      ************************************************************************************/
        let that = this;

        if (ALTDOWN) { ___ (PAINTER.ChangeCanvasHeightBy, [-LINEHEIGHT]); }
        else if (CONTROLDOWN) { ___ (PAINTER.ShowCanvas); }
        else {
          let linesFromStart = LINE - FILESEGBEGIN;
          let i = __;

          LINE = FILESEGBEGIN;

          for (i = 0; (LINE > 0) && (i < VIEWCAPACITY); i ++) { LINE = LINE - 1; }

          if (i === VIEWCAPACITY) {
            ___ (JustifyViewport);

            LINE = LINE + linesFromStart;
          }
          if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }
          if (SHIFTDOWN) { ___ (UnsetEditing, _, that); }
        }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function PressShift (event=__) {
        let that = this;

        SHIFTDOWN = true;

        ___ (UnsetEditing, _, that);
        ___ (UnsetJustifyViewport, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function OS () {
      /************************************************************************************
      * The function which ...
      ************************************************************************************/
        let that = this;

        ___ (FILEMANAGER.Read, [PROGRAMS], that);
        ___ (UnsetRequireRewrite, _, that);
        ___ (UnsetJustifyViewport, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ReleaseAlt (event) {
        let that = this;

        ALTDOWN = false;

        ___ (UnsetEditing, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ReleaseAltGraph (event) {
        let that = this;

        ALTGRAPHDOWN = false;

        ___ (UnsetEditing, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ReleaseControl (event) {
        let that = this;

        CONTROLDOWN = false;

        ___ (UnsetEditing, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function End (event=__) {
      /************************************************************************************
      * The function which moves the cursor to the end of the line
      ************************************************************************************/
        let that = this;

        if (CONTROLDOWN) {
          LINE = FILE.length - 1;

          ___ (SetJustifyViewport, _, that);
        }

        CURSOR = FILE [LINE].length;

        if (SHIFTDOWN) { ___ (UnsetEditing, _, that); }

        ___ (SetRequireRewrite, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F2 () {
        let that        = this;
        let filename    = ___ (FILEMANAGER.GetFileName);
        let ctrlKeyDown = CONTROLDOWN;

        if (!ctrlKeyDown) { ___ (PressControl, _, that); }

        ___ (End, _, that);

        if (!ctrlKeyDown) { ___ (ReleaseControl, _, that); }

        ___ (SetEditing, _, that);
        ___ (PersistClipboardCursor);
        ___ (PersistClipboardLine);
        ___ (Enter, _, that);
        ___ (____, [FILE, LINE, filename]);
        ___ (End, _, that);
        ___ (SetJustifyViewport, _, that);
        ___ (SetRequireRewrite, _, that);
        ___ (SetEditing, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F8 (event = __) {
        let that = this;

        if (CONTROLDOWN) {
          ___ (End, _, that);
          ___ (PersistClipboardCursor);
          ___ (PersistClipboardLine);
          ___ (Enter, _, that);
          ___ (____, [FILE, LINE, UTILS.WIN.SYS.location.href]);

          CURSOR = FILE [LINE].length;

          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          else { LINESTART = 0; }

          ___ (SetJustifyViewport, _, that);
        }
        else {
          let url     = __;
          let urlline = FILE [FILE.length - 1].trim ();

          urlline = urlline.split (UTILS.KBD.KEY.WHITESPACE);
          urlline = ___ (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, urlline]);
          urlline = ___ (UTILS.Filter, [UTILS.BLANKCHAR, urlline]);
          url     = urlline [0];

          UTILS.WIN.SYS.location.assign (url);
        }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F9 () {
        let that = this;

        ___ (____, [FILE, LINE, UTILS.BLANKCHAR]);

        CURSOR = 0;
        LINESTART = 0;

        ___ (SetRequireRewrite, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F10 () {
        let that = this;

        CURSOR = 0;
        LINE = 0;
        FILESEGEND = 0;
        FILE = new Array (UTILS.BLANKCHAR);

        ___ (SetJustifyViewport, _, that);
        ___ (SetRequireRewrite, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function Home (event=__) {
      /************************************************************************************
      * The function which moves the cursor to the beginning of the line
      ************************************************************************************/
        let that = this;

        if (CONTROLDOWN) {
          LINE = 0;

          ___ (SetJustifyViewport, _, that);
        }

        CURSOR = 0;

        if (SHIFTDOWN) { ___ (UnsetEditing, _, that); }

        ___ (SetRequireRewrite, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function Insert (event=__) {
        let that = this;

        if (!CONTROLDOWN) { INSERT = !INSERT; }

        ___ (UnsetEditing, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ReleaseShift (event) {
        let that = this;

        SHIFTDOWN = false;

        ___ (UnsetEditing, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ScrollLock (event=__) {
        let that = this;

        if (!CONTROLDOWN) { SCROLLLOCK = !SCROLLLOCK; }

        ___ (UnsetEditing, _, that);
        ___ (UnsetJustifyViewport, _, that);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function MinusSign (event) {
        let that      = this;
        let deltaSize = -1;

        if (CONTROLDOWN) {
          ___ (UpdateFontSize, [deltaSize], that);
          ___ (UnsetEditing, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function PlusSign (event) {
        let that      = this;
        let deltaSize = 1;

        if (CONTROLDOWN) {
          ___ (UpdateFontSize, [deltaSize], that);
          ___ (UnsetEditing, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseC (event) {
        let that = this;

        if (CONTROLDOWN) {
          let inClipbardText= __;
          let updateExClipboard = __;

          ___ (CopyTextToClipboard);

          inClipbardText = ___ (CLIPBOARD.GetText);
          inClipbardText = inClipbardText.join (UTILS.NEWLINECHAR);
          updateExClipboard = navigator.clipboard.writeText (inClipbardText);

          ___ (updateExClipboard.then, [ReportUpdateSuccess], updateExClipboard);
          ___ (UnsetEditing, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseC (event) {
        let that = this;

        if (CONTROLDOWN) {
          ___ (CopyTextToClipboard);
          ___ (UnsetEditing, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseF (event) {
        let that = this;

        if (CONTROLDOWN) { ___ (SearchFileFromBottomToTop, _, that); }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseF (event) {
        let that = this;

        if (CONTROLDOWN) { ___ (SearchFileFromTopToBottom, _, that); }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseI (event) {
        let that = this;

        if (CONTROLDOWN && SHIFTDOWN) {
          ___ (UnsetEditing, _, that);
          ___ (UnsetJustifyViewport, _, that);
          ___ (UnsetPreventDefault, _, that);
          ___ (UnsetStopPropagation, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseI (event) {
        let that = this;

        if (CONTROLDOWN && SHIFTDOWN) {
          ___ (UnsetEditing, _, that);
          ___ (UnsetJustifyViewport, _, that);
          ___ (UnsetPreventDefault, _, that);
          ___ (UnsetStopPropagation, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseK (event=__) {
        let that = this;

        if (CONTROLDOWN && (!SHIFTDOWN)) {
          let currententry = FILE [LINE];

          ___ (End, _, that);
          ___ (PersistClipboardCursor);
          ___ (PersistClipboardLine);
          ___ (Enter, _, that);
          ___ (____, [FILE, LINE, currententry])
          ___ (End, _, that);
          ___ (SetPreventDefault, _, that);
          ___ (SetStopPropagation, _, that);
          ___ (SetEditing, _, that);
        }
        else if (CONTROLDOWN && SHIFTDOWN) {
          ___ (UnsetEditing, _, that);
          ___ (UnsetJustifyViewport, _, that);
          ___ (UnsetPreventDefault, _, that);
          ___ (UnsetStopPropagation, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseK (event=__) {
        let that = this;
        ___ (UppercaseK, [event], that);      
        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseO (event) {
        let that = this;

        if (CONTROLDOWN) {
          let lastline = FILE.length - 1;
          let filename = FILE [lastline].trim ();
          ___ (FILEMANAGER.Read, [filename], that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseO (event) {
        let that = this;

        if (CONTROLDOWN) {
          let lastline = FILE.length - 1;
          let filename = FILE [lastline].trim ();
          ___ (FILEMANAGER.Read, [filename], that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseP (event) {
        let that = this;
  
        if (CONTROLDOWN) {
          ___ (UnsetEditing, _, that);
          ___ (UnsetJustifyViewport, _, that);
          ___ (UnsetPreventDefault, _, that);
          ___ (UnsetRequireRewrite, _, that);
          ___ (SetStopPropagation, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseP (event) {
        let that = this;

        if (CONTROLDOWN) {
          ___ (UnsetEditing, _, that);
          ___ (UnsetJustifyViewport, _, that);
          ___ (UnsetPreventDefault, _, that);
          ___ (UnsetRequireRewrite, _, that);
          ___ (SetStopPropagation, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseS (event) {
        let that = this;

        if (CONTROLDOWN) {
          let ctrlKeyDown  = CONTROLDOWN;
          let shiftKeyDown = SHIFTDOWN;
          let newfile      = FILE [FILE.length - 1].trim ();

          ___ (End, _, that);
          ___ (PersistClipboardCursor);
          ___ (PersistClipboardLine);

          if (!shiftKeyDown) { ___ (PressShift, _, that); }

          ___ (Backspace, _, that);

          if (!shiftKeyDown) { ___ (ReleaseShift, _, that); }

          ___ (PersistFile);
          ___ (PersistFileLine);
          ___ (PersistFileCursor);
          ___ (FILEMANAGER.Write, [newfile], that);
          ___ (UnsetEditing, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseS (event) {
        let that = this;

        if (CONTROLDOWN) {
          ___ (FILEMANAGER.Write, _, that);
          ___ (UnsetEditing, _, that);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseV (event) {
        let that = this;

        if (CONTROLDOWN) {
          ___ (DeleteSelectionFromFile);
          ___ (PasteTextFromClipboard);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseV (event) {
        let that = this;

        if (CONTROLDOWN) {
          ___ (DeleteSelectionFromFile);
          ___ (PasteTextFromClipboard);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseX (event) {
        let that = this;

        if (CONTROLDOWN) {
          let inClipbardText= __;
          let updateExClipboard = __;

          ___ (CopyTextToClipboard);
          ___ (DeleteSelectionFromFile);

          inClipbardText = ___ (CLIPBOARD.GetText);
          inClipbardText = inClipbardText.join (UTILS.NEWLINECHAR);
          updateExClipboard = navigator.clipboard.writeText (inClipbardText);

          ___ (updateExClipboard.then, [ReportUpdateSuccess], updateExClipboard);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseX (event) {
        let that = this;

        if (CONTROLDOWN) {
          ___ (CopyTextToClipboard);
          ___ (DeleteSelectionFromFile);
        }
        else { ___ (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define arbitrary internal functions that form the class interface below
  ************************************************************************************/

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetStopPropagation () {
      let that = this;
      ___ (____, [that, "stopPropagation", true]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UnsetStopPropagation () {
      let that = this;
      ___ (____, [that, "stopPropagation", false]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetRequireRewrite () {
      let that = this;
      ___ (____, [that, "requireRewrite", true]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UnsetRequireRewrite () {
      let that = this;
      ___ (____, [that, "requireRewrite", false]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetPreventDefault () {
      let that = this;
      ___ (____, [that, "preventDefault", true]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UnsetPreventDefault () {
      let that = this;
      ___ (____, [that, "preventDefault", false]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetJustifyViewport () {
      let that = this;
      ___ (____, [that, "justifyViewport", true]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UnsetJustifyViewport () {
      let that = this;
      ___ (____, [that, "justifyViewport", false]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetEditing () {
      let that = this;
      ___ (____, [that, "editing", true]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UnsetEditing () {
      let that = this;
      ___ (____, [that, "editing", false]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetAltState () { return ALTDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetAltGraphState () { return ALTGRAPHDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetControlState () { return CONTROLDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetBgColor () { return BGCOLOR; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFgColor () { return FGCOLOR; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFont () { return FONT; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetKeyFunction (key=__, index=__) {
      let that       = this;
      let keyHandler = __;

      if (___ (NonPrintCharacter, [key])) {
        if (index === UTILS.RELEASE) { keyHandler = that.Release [key]; }
        else if (index === UTILS.PRESS) { keyHandler = that.Press [key]; }
      }
      else { keyHandler = that.Printable [key]; }

      return keyHandler;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetLineHeight () { return LINEHEIGHT; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetScrollLockState () { return SCROLLLOCK; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetShiftState () { return SHIFTDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetBgColor (color=__) {
      let that = this;
      BGCOLOR = color;
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetFgColor (color=__) {
      let that = this;
      FGCOLOR = color;
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetFont (font=__) {
      let that = this;
      FONT = font;
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetKeyFunction (key=__, keyHandler=__, index=__) {
      let that = this;

      if (___ (NonPrintCharacter, [key])) {
        if (index === UTILS.RELEASE) {
          ___ (____, [that.Release, key, keyHandler]);
        }
        else if (index === UTILS.PRESS) {
          ___ (____, [that.Press, key, keyHandler]);
        }
      }
      else { ___ (____, [that.Printable, key, keyHandler]); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetLineHeight (height=__) {
      let that = this;
      LINEHEIGHT = height;
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFile () { ___ (FILEMANAGER.SetFile, [UTILS.WHOLE, FILE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFileCursor () { ___ (FILEMANAGER.SetFileCursor, [CURSOR]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFileLine () { ___ (FILEMANAGER.SetFileLine, [LINE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistViewportStart () { ___ (VIEWPORT.SetSegmentBegin, [FILESEGBEGIN]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistViewportEnd () { ___ (VIEWPORT.SetSegmentEnd, [FILESEGEND]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistViewportLineStart () { ___ (VIEWPORT.SetLineStart, [LINESTART]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistClipboardCursor () { ___ (CLIPBOARD.SetCursor, [CURSOR]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistClipboardLine () { ___ (CLIPBOARD.SetLine, [LINE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFile () { FILE = ___ (FILEMANAGER.GetFile, [UTILS.WHOLE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFileCursor () { CURSOR = ___ (FILEMANAGER.GetFileCursor); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFileLine () { LINE = ___ (FILEMANAGER.GetFileLine); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveViewportStart () { FILESEGBEGIN = ___ (VIEWPORT.GetSegmentBegin); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveViewportEnd () { FILESEGEND = ___ (VIEWPORT.GetSegmentEnd); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveViewportLineStart () { LINESTART = ___ (VIEWPORT.GetLineStart); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ReWrite (somewords=__) {
      let that         = this;
      let currententry = __;
      let subline      = __;
      let filesize     = __;
      let thisline     = __;
      let words        = somewords;

      if (words === __) { words = FILE; }
      else {
        ___ (VIEWPORT.AdjustPosition, [words.length, LINE, CURSOR]);

        FILESEGBEGIN = ___ (VIEWPORT.GetSegmentBegin);
        FILESEGEND   = ___ (VIEWPORT.GetSegmentEnd);
        LINESTART    = ___ (VIEWPORT.GetLineStart);
      }

      filesize = words.length;
      thisline = FILESEGBEGIN;

      ___ (PAINTER.BeginPath);
      ___ (PAINTER.SetFillColorTo, [BGCOLOR]);
      ___ (PAINTER.ClearPixels);
      ___ (PAINTER.PaintBackGround);
      ___ (PAINTER.SetFontTo, [FONT]);
      ___ (PAINTER.SetFillColorTo, [FGCOLOR]);
      ___ (____, [that, "x", LMARGIN]);
      ___ (____, [that, "y", TMARGIN]);

      while (thisline <= FILESEGEND) {
        currententry = words [thisline];
        subline = ___ (LeadWithSpaces, [(1 + thisline), filesize]);
        subline = subline + currententry.substring (LINESTART, LINESTART + LINESTOP);
        thisline = thisline + 1;

        ___ (PAINTER.FillText, [subline], that);
        ___ (NewLine, _, that);
      }

      ___ (PAINTER.SetFillColorTo, [BGCOLOR]);
      ___ (PAINTER.PaintBackGround, [RMARGIN]);
      ___ (PAINTER.ClosePath);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UpdateDocumentBgColor () {
      let that    = this;
      let html    = ___ (UTILS.WIN.DOC.querySelector, ["html"], UTILS.WIN.DOC);
      let center  = ___ (UTILS.WIN.DOC.querySelector, ["center"], UTILS.WIN.DOC);
      let head    = ___ (UTILS.WIN.DOC.querySelector, ["head"], UTILS.WIN.DOC);
      let body    = ___ (UTILS.WIN.DOC.querySelector, ["body"], UTILS.WIN.DOC);
      let bgcolor = "backgroundColor";

      ___ (____, [COVER.style, bgcolor, BGCOLOR]);
      ___ (____, [html.style, bgcolor, BGCOLOR]);
      ___ (____, [center.style, bgcolor, BGCOLOR]);
      ___ (____, [head.style, bgcolor, BGCOLOR]);
      ___ (____, [body.style, bgcolor, BGCOLOR]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GenerateKeyFunctions (from=__, to=__, fn=__) {
      let that = this;
      let key  = __;

      if (from !== __) {
        if (to === __) { to = from; }

        for (let i = from; i <= to; i ++) {
          key = ___ (UTILS.ToChar, [i]);
          ___ (____, [that, key, fn]);
        }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RemoveAllEventHandlers () {
      let that = this;

      ___ (UTILS.RemoveHandlerFor, [UTILS.KBD.KEY.DOWN, UTILS.WIN.SYS], that.Press);
      ___ (UTILS.RemoveHandlerFor, [UTILS.KBD.KEY.UP, UTILS.WIN.SYS], that.Press);
      ___ (UTILS.RemoveHandlerFor, [UTILS.WIN.RESIZE, UTILS.WIN.SYS], that.Press);
      ___ (UTILS.RemoveHandlerFor, [UTILS.MWS.WHEEL, ___ (PAINTER.GetCanvas)], that.Press);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
    /************************************************************************************
    * The function which destroys the paper process
    ************************************************************************************/
      let that = this;

      while (that.stack.size > 0) {
        ___ (STACK.Pop, _, that.stack);
        ___ (that.stack.popped.abort, _, that.stack.popped);
      }

      ___ (UpdateDocumentBgColor);
      ___ (RemoveAllEventHandlers, _, that);
      ___ (PAINTER.Destroy, _, that.painter);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify (loaderObj=__) {
      let that  = this;
      let Avail = __;

      LOADER = loaderObj;
      UTILS  = LOADER.UTILS;
      Avail  = UTILS.Avail;
      ___    = UTILS.Link;
      ____   = UTILS.MapKeyValue;

      COVER       = ___ (LOADER.Import, [LOADER.COVER]);
      CLIPBOARD   = ___ (LOADER.Import, [LOADER.CLIPBOARD]);
      DATA        = ___ (LOADER.Import, [LOADER.DATA]);
      FILEMANAGER = ___ (LOADER.Import, [LOADER.FILEMANAGER]);
      PAINTER     = ___ (LOADER.Import, [LOADER.PAINTER]);
      STACK       = ___ (LOADER.Import, [LOADER.STACK]);
      VIEWPORT    = ___ (LOADER.Import, [LOADER.VIEWPORT]);

      Press        = ___ (UTILS.CloneMap);
      Printable    = ___ (UTILS.CloneMap);
      Release      = ___ (UTILS.CloneMap);
      ALTDOWN      = false;
      ALTGRAPHDOWN = false;
      CONTROLDOWN  = false;
      EXPLAIN      = DATA [36];
      INSERT       = false;
      LINEHEIGHT   = 17;
      SCROLLLOCK   = false;
      SHIFTDOWN    = false;
      PROGRAMS     = DATA [9] + DATA [37];
      TABSIZE      = 2;
      VIEWCAPACITY = 0;

      ___ (DefineNonPrintKeyFunctions);
      ___ (DefinePrintKeyFunctions);

      ___ (Avail, [Create], that);
      ___ (Avail, [Destroy], that);
      ___ (Avail, [GetAltState], that);
      ___ (Avail, [GetAltGraphState], that);
      ___ (Avail, [GetControlState], that);
      ___ (Avail, [GetBgColor], that);
      ___ (Avail, [GetFgColor], that);
      ___ (Avail, [GetFont], that);
      ___ (Avail, [GetKeyFunction], that);
      ___ (Avail, [GetLineHeight], that);
      ___ (Avail, [GetScrollLockState], that);
      ___ (Avail, [GetShiftState], that);
      ___ (Avail, [SetBgColor], that);
      ___ (Avail, [SetFgColor], that);
      ___ (Avail, [SetFont], that);
      ___ (Avail, [SetKeyFunction], that);
      ___ (Avail, [SetLineHeight], that);

      ___ (Avail, [RetrieveFile], that);
      ___ (Avail, [RetrieveFileCursor], that);
      ___ (Avail, [RetrieveFileLine], that);
      ___ (Avail, [RetrieveViewportStart], that);
      ___ (Avail, [RetrieveViewportEnd], that);
      ___ (Avail, [RetrieveViewportLineStart], that);
      ___ (Avail, [PersistFile], that);
      ___ (Avail, [PersistFileCursor], that);
      ___ (Avail, [PersistFileLine], that);
      ___ (Avail, [PersistViewportStart], that);
      ___ (Avail, [PersistViewportEnd], that);
      ___ (Avail, [PersistViewportLineStart], that);
      ___ (Avail, [PersistClipboardCursor], that);
      ___ (Avail, [PersistClipboardLine], that);

      ___ (Avail, [GenerateKeyFunctions], that);
      ___ (Avail, [JustifyViewport], that);
      ___ (Avail, [RemoveAllEventHandlers], that);
      ___ (Avail, [ReWrite], that);

      ___ (Avail, [SetEditing], that);
      ___ (Avail, [SetJustifyViewport], that);
      ___ (Avail, [SetPreventDefault], that);
      ___ (Avail, [SetRequireRewrite], that);
      ___ (Avail, [SetStopPropagation], that);
      ___ (Avail, [UnsetEditing], that);
      ___ (Avail, [UnsetJustifyViewport], that);
      ___ (Avail, [UnsetPreventDefault], that);
      ___ (Avail, [UnsetRequireRewrite], that);
      ___ (Avail, [UnsetStopPropagation], that);

      ___ (____, [that, "Press", Press]);
      ___ (____, [that, "Printable", Printable]);
      ___ (____, [that, "Release", Release]);

      return ___ (UTILS.CloneMap, [that]);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    return Loader.UTILS.Link (Objectify, [Loader], paper);
  }

  return loader.UTILS.Link (MakePaperName, [loader], paperspace);
}