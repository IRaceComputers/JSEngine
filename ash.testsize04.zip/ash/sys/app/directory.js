/****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeNullTermNameSpace (loader) {
  "use strict";

  let nulltermspace = Object.create (null);

  function MakeNullTermName (Loader=undefined) {
    let nullterm = this;
    let _        = null;
    let __       = undefined;
    let ___      = __;
    let ____     = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let BROWSER        = __;
    let COVER          = __;
    let CURSOR         = __;
    let PAPER          = __;
    let EXIT           = __;
    let FILE           = __;
    let FILEMANAGER    = __;
    let INITIATE       = __;
    let INITDATA       = __;
    let LINE           = __;
    let LOADER         = __;
    let PAINTER        = __;
    let PROCESS        = __;
    let PressControl   = __;
    let PressEnter     = __;
    let PressShift     = __;
    let ReleaseControl = __;
    let ReleaseShift   = __;
    let SCREEN         = __;
    let ScrollLock     = __;
    let SERVER         = __;
    let UTILS          = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/ 

    function Create (info=__) {
      let that = this;

      EXIT           = info.escape;
      PressEnter     = ___ (PAPER.GetKeyFunction, [UTILS.KBD.KEY.ENTER, UTILS.PRESS], PAPER);
      PressControl   = ___ (PAPER.GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], PAPER);
      PressShift     = ___ (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.PRESS], PAPER);
      ReleaseControl = ___ (PAPER.GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], PAPER);
      ReleaseShift   = ___ (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.RELEASE], PAPER);
      ScrollLock     = ___ (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, UTILS.RELEASE], PAPER);

      ___ (____, [that, "paper", Object.create (_)]);
      ___ (____, [that, "id", info.id]);
      ___ (PAPER.Create, [info], that.paper);
      ___ (Customize, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatnullterm   = this;
      let that           = thatnullterm.paper;
      let ENTER          = UTILS.KBD.KEY.ENTER;
      let HELP           = UTILS.KBD.KEY.F1;
      let RELOAD         = UTILS.KBD.KEY.F5;
      let oldFunction    = ___ (PAPER.GetKeyFunction, [HELP, UTILS.PRESS], that);
      let newFunction    = ___ (MakeNewHelp, [oldFunction], that);
      let commandHandler = Object.create (_);

      ___ (PAPER.SetKeyFunction, [HELP, newFunction, UTILS.PRESS], that);
      ___ (____, [commandHandler, "command", ".help."]);
      ___ (____, [commandHandler, "handler", newFunction.bind (thatnullterm)]);
      ___ (BROWSER.Create, [commandHandler], thatnullterm);

      newFunction = UTILS.WIN.SYS.location.reload.bind (UTILS.WIN.SYS);

      ___ (PAPER.SetKeyFunction, [RELOAD, newFunction, UTILS.PRESS], that);

      newFunction = RunCommand.bind (thatnullterm);

      ___ (PAPER.SetKeyFunction, [ENTER, newFunction, UTILS.PRESS], that);

      oldFunction = ___ (PAPER.GetKeyFunction, [ENTER, UTILS.PRESS], that);
      newFunction = ___ (MakeNewEnter, [oldFunction], thatnullterm);

      ___ (PAPER.SetKeyFunction, [ENTER, newFunction, UTILS.PRESS], that); 
      ___ (____, [commandHandler, "command", ".history."]);
      ___ (____, [commandHandler, "handler", History.bind (thatnullterm)]);
      ___ (BROWSER.Create, [commandHandler], thatnullterm);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=__) {
      let thatnullterm = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that    = this;
        let Command = __;
        let opline  = __;

        FILE    = ___ (FILEMANAGER.GetFile, [UTILS.WHOLE]);
        opline  = FILE [FILE.length - 1].trim (). split (UTILS.KBD.KEY.WHITESPACE);
        opline  = ___ (UTILS.Filter, [UTILS.BLANKCHAR, opline]);
        opline  = ___ (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, opline]);
        Command = ___ (BROWSER.Recorded, [opline[0]], thatnullterm);

        if (Command !== __) { ___ (Command, [FILE, UTILS.KBD.KEY.WHITESPACE]); }
        else { ___ (oldEnter, _, that); }

        return __;
      }

      return Enter;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Escape () {
      let that      = this;
      let date      = new Date ();
      let exitText  = new Array ();
      let finaltext = UTILS.BLANKCHAR;
      let bgcolor   = "backgroundColor";
      let bgRGBA    = ___ (PAPER.GetBgColor);
      let p         = "p";
      let lb        = "br";
      let paragraph = __;
      let linebreak = __;

      ___ (____, [exitText, 0, "<br/><br/><br/><br/>"]);
      ___ (____, [exitText, 1, "<p>Press [F5] or [CTRL]+[R] to start</p>"]);
      ___ (____, [exitText, 2, "<br/><br/>"]);
      ___ (____, [exitText, 3, "<p>Press [CTRL]+[W] to exit.</p>"]);
      ___ (____, [exitText, 4, "<br/><br/>"]);
      ___ (____, [exitText, 5, "<p>Ancient Creations &trade;</p>"]);
      ___ (____, [exitText, 6, "<br/><br/>"]);
      ___ (____, [exitText, 7, "<p>ASH &copy; 2021</p>"]);

      for (let i = 0; i < exitText.length; i ++) { finaltext = finaltext + exitText [i]; }

      ___ (____, [COVER, "innerHTML", finaltext]);

      paragraph = ___ (UTILS.WIN.DOC.querySelectorAll, [p], UTILS.WIN.DOC);
      linebreak = ___ (UTILS.WIN.DOC.querySelectorAll, [lb], UTILS.WIN.DOC);

      for (let i = 0; i < paragraph.length; i ++) {
        ___ (____, [paragraph [i].style, bgcolor, bgRGBA]);
      }
      for (let i = 0; i < linebreak.length; i ++) {
        ___ (____, [linebreak [i].style, bgcolor, bgRGBA]);
      }

      return ___ (Destroy, _, that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function fakeEscape () { return __; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=__) {
      let thatpaper = this;

      function Help (event=__) {
        let that = this;

        ___ (Helper, [event, fakeEscape], that);
        ___ (RunCommand, _, SERVER);
        ___ (PAPER.PersistClipboardCursor);
        ___ (PAPER.PersistClipboardLine);

        return __;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function History () {
      let that             = this;
      let ArrowUp          = ___ (PAPER.GetKeyFunction, [UTILS.KBD.KEY.ARROWUP, UTILS.PRESS], PAPER);
      let Backspace        = ___ (PAPER.GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, UTILS.PRESS], PAPER);
      let End              = ___ (PAPER.GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], PAPER);
      let ctrlKeyDown      = ___ (PAPER.GetControlState);
      let scrollLockActive = ___ (PAPER.GetScrollLockState);
      let shiftKeyDown     = ___ (PAPER.GetShiftState);

      if (scrollLockActive) { ___ (ScrollLock, _, that.paper); }

      ___ (ReleaseControl, _, that.paper);
      ___ (ReleaseShift, _, that.paper);

      ___ (PressControl, _, that.paper);
      ___ (End, _, that.paper);
      ___ (ReleaseControl, _, that.paper);
      ___ (PAPER.PersistClipboardCursor);
      ___ (PAPER.PersistClipboardLine);

      ___ (PressEnter, _, that.paper);
      ___ (PAPER.PersistClipboardCursor);
      ___ (PAPER.PersistClipboardLine);

      for (let i = 0; i < that.history.length; i ++) {
        ___ (PressEnter, _, that.paper);
        ___ (ArrowUp, _, that.paper);
        ___ (PAPER.PersistClipboardCursor);
        ___ (PAPER.PersistClipboardLine);
      }

      ___ (PAPER.PersistFile);
      ___ (PAPER.PersistFileLine);
      ___ (PAPER.PersistFileCursor);

      FILE = ___ (FILEMANAGER.GetFile, [UTILS.WHOLE]);
      LINE = ___ (FILEMANAGER.GetFileLine);

      for (let i = 0; i < that.history.length; i ++) {
        ___ (____, [FILE, LINE + i, that.history [i]]);
      }

      ___ (FILEMANAGER.SetFile, [UTILS.WHOLE, FILE]);
      ___ (FILEMANAGER.SetFileLine, [FILE.length - 1]);
      ___ (FILEMANAGER.SetFileCursor, [0]);
      ___ (PAPER.RetrieveFile);
      ___ (PAPER.RetrieveFileLine);
      ___ (PAPER.RetrieveFileCursor);

      ___ (PressControl, _, that.paper);
      ___ (End, _, that.paper);
      ___ (ReleaseControl, _, that.paper);
      ___ (PAPER.PersistClipboardCursor);
      ___ (PAPER.PersistClipboardLine);

      ___ (PAPER.PersistViewportStart);
      ___ (PAPER.PersistViewportLength);
      ___ (PAPER.PersistViewportLineStart);
      ___ (PAPER.ReWrite, _, that.paper);

      if (ctrlKeyDown) { ___ (PressControl, _, that.paper); }
      if (shiftKeyDown) { ___ (PressSift, _, that.paper); }
      if (scrollLockActive) { ___ (ScrollLock, _, that.paper); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    /********************************************************
    * Command Recognition and Application Loader
    /*******************************************************/
    function RunCommand (pressedEnter=true) {
      let that     = this;
      let command  = 0;
      let readfile = 1;
      let identity = "id";
      let lastline = ___ (FILEMANAGER.GetFileSize) - 1;

      FILE     = ___ (FILEMANAGER.GetFile, [UTILS.WHOLE]);
      lastline = FILE [lastline].trim ();
      lastline = lastline.split (UTILS.KBD.KEY.WHITESPACE);
      lastline = ___ (UTILS.Filter, [UTILS.BLANKCHAR, lastline]);
      lastline = ___ (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, lastline]);
      command  = lastline [command];
      readfile = lastline [readfile];

      /**
      * Design a method that allows the source of an action to be identified 
      * through the stimulus event (keydown, keyup, etc.) and implement 
      * that design through the paper app... so we can prevent uncaught errors
      * caused by using keydown keys in a keyup event.
      */
      if (PROCESS [command] !== __) {
        ___ (____, [that.history, that.history.length, INITDATA [command][identity]]);
        ___ (Destroy, _, that);
        ___ (INITIATE [command], [readfile], PROCESS [command]);
      }
      else if (pressedEnter) { ___ (PressEnter); }

      ___ (PAPER.PersistFile);
      ___ (PAPER.PersistFileLine);
      ___ (PAPER.PersistFileCursor);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;
      ___ (PAPER.Destroy, _, that.paper);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;
      let StopServer = __;

      LOADER = Loader;
      UTILS  = LOADER.UTILS;
      ___    = UTILS.Link;
      ____   = UTILS.MapKeyValue;

      BROWSER     = ___ (LOADER.Import, [LOADER.BROWSER]);
      COVER       = ___ (LOADER.Import, [LOADER.COVER]);
      PAPER       = ___ (LOADER.Import, [LOADER.PAPER]);
      FILEMANAGER = ___ (LOADER.Import, [LOADER.FILEMANAGER]);
      INITDATA    = ___ (LOADER.Import, [LOADER.INITDATA]);
      INITIATE    = ___ (LOADER.Import, [LOADER.INITIATE]);
      PROCESS     = ___ (LOADER.Import, [LOADER.PROCESS]);
      SERVER      = ___ (LOADER.Import, [LOADER.SERVER]);
      StopServer  = Escape.bind (SERVER);

      ___ (____, [that, "Create", Create]);
      ___ (____, [that, "Destroy", Destroy]);
      ___ (____, [that, "RunCommand", RunCommand]);
      ___ (____, [that, "Escape", StopServer]);

      return Object.create (that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    return Loader.UTILS.Link (Objectify, _, nullterm);
  }

  return loader.UTILS.Link (MakeNullTermName, [loader], nulltermspace);
}