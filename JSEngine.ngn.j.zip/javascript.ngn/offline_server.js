function MakeServerNameSpace () {
  "use strict";

  var fs   = require ("fs");
  var http = require ("http");

  var IP_ADDRESS  = "127.0.0.1",
      PORT_NUMBER = 9000,
      READABLE    = {
        "File" : {
          "/"                            : {"Content-Type":"text/html"},
          "/favicon.ico"                 : {"Content-Type":"image/ico"},
          "/sys/priv/style.ngn.css"      : {"Content-Type":"text/css"},
          "/sys/lib/browser.js"          : {"Content-Type":"text/javascript"},
          "/sys/lib/decimal.js"          : {"Content-Type":"text/javascript"},
          "/sys/lib/filemanager.js"      : {"Content-Type":"text/javascript"},
          "/sys/lib/integer.js"          : {"Content-Type":"text/javascript"},
          "/sys/lib/paint.js"            : {"Content-Type":"text/javascript"},
          "/sys/lib/stack.js"            : {"Content-Type":"text/javascript"},
          "/sys/lib/utility.js"          : {"Content-Type":"text/javascript"},
          "/sys/proc/grid.js"            : {"Content-Type":"text/javascript"},
          "/sys/proc/graphics.process.js": {"Content-Type":"text/javascript"},
          "/sys/proc/plot.js"            : {"Content-Type":"text/javascript"},
          "/sys/proc/search.js"          : {"Content-Type":"text/javascript"},
          "/sys/app/logic.js"            : {"Content-Type":"text/javascript"},
          "/sys/app/geometry.js"         : {"Content-Type":"text/javascript"},
          "/sys/app/io.js"               : {"Content-Type":"text/javascript"},
          "/sys/app/scramble.js"         : {"Content-Type":"text/javascript"},
          "/sys/app/media.js"            : {"Content-Type":"text/javascript"},
          "/sys/app/directory.js"        : {"Content-Type":"text/javascript"},
          "/sys/init/process.js"         : {"Content-Type":"text/javascript"},
          "/sys/init/begin.js"           : {"Content-Type":"text/javascript"}
        },
        "Directory" : {
          "/files"    : true,
          "/music"    : true,
          "/videos"   : true,
          "/sys/doc"  : true
        }
      };

  var server = http.createServer (Materialize);

  console.log ("Serving HTTP on", IP_ADDRESS + ":" +  PORT_NUMBER, "...");

  /************************************************************************/
  function Materialize (rikwest, rizalt) {
    var file = Object.create (null);

    file.DATAPOST     = undefined;
    file.INCOMINGDATA = "data";
    file.DATAEND      = "end";
    file.GET          = "GET";
    file.POST         = "POST";

    console.log ("\n",rikwest.method, rikwest.url);

    switch (rikwest.method) {
      case file.GET:
        return GETResource.call (rikwest, rizalt);
      break;
      case file.POST:
        file.DATAPOST = "";
        rikwest.on (file.INCOMINGDATA, AcceptData.bind (file));
        rikwest.on (file.DATAEND, WriteData.bind (file));
      break;
    }

    function AcceptData (stream) {
      var self = this;
      self.DATAPOST = self.DATAPOST + stream;
      return undefined;
    }

    function WriteData (stream) {
      var self = this;
      OverwriteResource (self.DATAPOST);
      return undefined;
    }

     return undefined;
    /*****************/
  }


  function GETResource (rizalt) {
    /******************************************************************/
    var self       = this,
        file       = Object.create (null);

    file.DIREKTORY  = undefined;
    file.DIDNOTREAD = undefined;

    if (READABLE.File[self.url]) { ReadResource.call (self, rizalt); }
    else {
      file.DIDNOTREAD = true;

      for (file.DIREKTORY in READABLE.Directory) {
        if (CanAccess.call (self, file.DIREKTORY)) {
          if (MediaResource.call (self)) { GetMediaResource.call (self, rizalt); }
          else { GetTextResource.call (self, rizalt); }
          file.DIDNOTREAD = false;
        }
        else { /* HANDLE READING DIRECTORY CONTENTS HERE */ }
      }

      if (file.DIDNOTREAD) { GetFNF.call (self, rizalt); }
    }
    /******************************************************************/

    return undefined;
  }

  function CanAccess (directory) {
    var self = this,
        response = false;

    if ((self.url.indexOf (directory) === 0) && (self.url !== directory)) { response = true; }

    return response;
  }

  function MediaResource () {
    var self  = this,
        file = Object.create (null);

    file.MUSIC    = "music";
    file.VIDEO    = "video";
    file.RESPONSE = false;

    if (self.url.indexOf (file.MUSIC) !== -1 || self.url.indexOf (file.VIDEO)) { file.RESPONSE = true; }

    return file.RESPONSE;
  }


  /***************************************************************************/
  /***************************************************************************/
  function ReadResource (rizalt) {
    var self = this,
        file = Object.create (null);

    file.BLANK    = "";
    file.SITE     = ".";
    file.ROOT     = "/";
    file.BASE     = "index.html";
    file.STATUS   = 200;
    file.CONTENTS = undefined;
    file.STREAM   = undefined;

    if (self.url === file.ROOT) { file.CONTENTS = file.BASE; }
    else                        { file.CONTENTS = file.BLANK; }

    file.CONTENTS = file.SITE + self.url + file.CONTENTS;
    file.STREAM = fs.createReadStream (file.CONTENTS);

    rizalt.writeHead (file.STATUS, READABLE.File[self.url]);
    file.STREAM.pipe (rizalt);

    console.log ("GOT", file.CONTENTS);

    return undefined;
  }

  /***************************************************************************/
  /******************************************************/
  function GetMediaResource (rizalt) {
    var self    = this,
        file    = Object.create (null);

        file.SITE      = ".";
        file.CONTENTS  = file.SITE + self.url,
        file.STREAM    = fs.createReadStream (file.CONTENTS);

    rizalt.writeHead (200, {"Content-Type":"video/mp4"});
    file.STREAM.pipe (rizalt);

    console.log ("GOT", file.CONTENTS);

    return undefined;
  }

  /******************************************************/
  /***************************************************************************/
  function GetFNF (rizalt) {
   var self = this;

    rizalt.writeHead (404, {"Content-Type":"text/html"});
    rizalt.write ("File '" + self.url + "' not found. Try a different name.");
    rizalt.end ();

    console.log ("GOT", "404");

    return undefined;
  }

  /***************************************************************************/
  /********************************************************/
  function GetTextResource (rizalt) {
    var self    = this,
        file    = Object.create (null);

    file.SITE     = ".";
    file.CONTENTS = file.SITE + self.url,
    file.STREAM   = fs.createReadStream (file.CONTENTS);

    rizalt.writeHead (200, {"Content-Type":"text/plain"});
    file.STREAM.pipe (rizalt);

    console.log ("GOT", file.CONTENTS);

    return undefined;
  }

  /********************************************************/
  /*************************************************/
  function OverwriteResource (data) {
    var dataArr  = data.split ("\n");
    var filename = dataArr.pop ().trim ();

    if (filename === "" || filename === ".") {
      console.log ("[!!] Filename \"" + filename + "\" is invalid.");
    }
    else { fs.writeFileSync (filename, dataArr.join("\n")); }

    console.log ("POSTED\n", data);

    return undefined;
  }
  /*************************************************/

  server.listen (PORT_NUMBER, IP_ADDRESS);

  return undefined;
}

/***************************************************************************************************/
/***************************************************************************************************/

var SERVERSPACE = Object.create (null);

MakeServerNameSpace.call (SERVERSPACE);

/***************************************************************************************************/
/***************************************************************************************************/
