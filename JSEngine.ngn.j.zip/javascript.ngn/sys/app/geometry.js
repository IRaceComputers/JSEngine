function MakeGeometryNameSpace (utils, decimal, browser) {
  "use strict";

  let geometryspace = Object.create (null);
  let Geometry      = undefined;

  function MakeGeometryName (Utils=undefined, Decimal=undefined, Browser=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let geometry    = Object.create (null);

    let DECIMAL     = Decimal;
    let BGCOLOR     = undefined;
    let BROWSER     = Browser;
    let COVER       = undefined;
    let EKKOE       = undefined;
    let EXIT        = undefined;
    let FGCOLOR     = undefined;
    let FILEMANAGER = undefined;
    let FONT        = "15px Monospace";
    let GRID        = undefined;
    let PAINTER     = undefined;
    let PLOT        = undefined;
    let SCREEN      = undefined;
    let STACK       = undefined;
    let UTILS       = Utils;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Materialize (info=undefined) {
      let that = this;

      BGCOLOR     = info.bgcolor;
      GRID        = info.grid;
      EKKOE       = info.ekkoe;
      EXIT        = info.escape;
      FGCOLOR     = info.fgcolor;
      FILEMANAGER = info.filemanager;
      FONT        = info.font || FONT;
      PAINTER     = info.painter;
      COVER       = info.cover;
      PLOT        = info.plot;
      SCREEN      = info.screen;
      STACK       = info.stack;
      that.id     = info.id;
      that.ekkoe  = Object.create (null);

      UTILS.Link (
        EKKOE.Materialize,
        [{
          "bgcolor"    : BGCOLOR,
          "cover"      : COVER,
          "escape"     : EXIT,
          "fgcolor"    : FGCOLOR,
          "filemanager": FILEMANAGER,
          "font"       : FONT,
          "help"       : info.help,
          "id"         : that.id,
          "painter"    : PAINTER,
          "screen"     : SCREEN,
          "stack"      : info.stack
        }],
        that.ekkoe
      );

      UTILS.Link (
        PLOT.Materialize,
        [{
          "bgcolor" : BGCOLOR,
          "grid"    : GRID,
          "painter" : PAINTER,
          "unit"    : info.unit
        }],
        that
      );

      UTILS.Link (Customize, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatgeometry  = this;
      let that          = thatgeometry.ekkoe;
      let ENTER         = "Enter";
      let oldEnter      = that.Action [ENTER];

      that.Action [ENTER]  = UTILS.Link (MakeNewEnter, [oldEnter], thatgeometry);

    /**************************************************************************************************************/
    /**************************************************************************************************************/
    /**************************************************************************************************************/

      UTILS.Link (
        BROWSER.Materialize,
        [{
          "command" : ".draw.",
          "funktion": ShowGeometry.bind (thatgeometry)
        }],
        thatgeometry
      );

      return undefined;
    } 

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=undefined) {
      let thatgeometry = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that      = this;
        let command   = undefined;
        let opline    = undefined;
        let words     = that.words;

        opline  = words[words.length - 1].trim (). split (UTILS.SPACECHAR);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, opline]);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.SPACECHAR, opline]);
        command = UTILS.Link (BROWSER.Recorded, [opline[0]], thatgeometry);

        // if last line's first word is an internal kommand then runnit, else UTILS.Link (oldEnter, [], that);
        if (command !== undefined) { UTILS.Link (command, [words, UTILS.SPACECHAR]); }
        else { UTILS.Link (oldEnter, [], that); }

        return undefined;
      }

      return Enter;
    };
 
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ShowGeometry () {
      let thatgeometry = this;
      let TYPE         = 0;
      let components   = undefined;
      let structures   = undefined;
      let type         = undefined;

      structures = UTILS.Link (PLOT.CloneStructures, [], thatgeometry);
      structures = UTILS.Link (PLOT.CleanStructures, [structures]);

      UTILS.Link (PLOT.ClearBackground, [], thatgeometry);

      for (let i =  0; i < structures.length; i ++) {
        components = structures [i];
        type       = components [TYPE];

        if (PLOT.Structure [type] !== undefined) {
          UTILS.Link (PLOT.Structure [type], [components], thatgeometry);
        }
      }

      thatgeometry.ekkoe.requireRewrite = false;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      UTILS.Link (EKKOE.Destroy, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    geometry.Materialize = Materialize;
    geometry.Destroy     = Destroy;

    return Object.create (geometry);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Geometry = utils.Link (MakeGeometryName, [utils, decimal, browser], geometryspace);

  return Geometry;
}
