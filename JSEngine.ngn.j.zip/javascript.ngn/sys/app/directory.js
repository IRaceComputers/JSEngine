function MakeNullTermNameSpace (utils) {
  "use strict";

  let nulltermspace = Object.create (null);
  let NullTerm      = undefined;

  function MakeNullTermName (Utils=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let nullterm = Object.create (null);

    let BGCOLOR     = undefined;
    let EKKOE       = undefined;
    let FILEMANAGER = undefined;
    let EXIT        = undefined;
    let FGCOLOR     = undefined;
    let PAINTER     = undefined;
    let UTILS       = Utils;
    let COVER       = undefined;  
    let SCREEN      = undefined;
    let FONT        = "15px Monospace";

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/ 

    function Materialize (info=undefined) {
      let that = this;

      BGCOLOR           = info.bgcolor;
      EKKOE             = info.ekkoe; 
      EXIT              = info.escape;
      FGCOLOR           = info.fgcolor;
      FILEMANAGER       = info.filemanager;
      FONT              = info.font || FONT;
      PAINTER           = info.painter;
      COVER             = info.cover;
      SCREEN            = info.screen;
      that.ekkoe        = Object.create (null);
      that.ekkoe.exists = true;
      that.id           = info.id;

      if (EXIT === undefined) { EXIT = EscapeNullTerm; }

      UTILS.Link (
        EKKOE.Materialize,
        [{
          "bgcolor"    : BGCOLOR,
          "escape"     : EXIT,
          "fgcolor"    : FGCOLOR,
          "filemanager": FILEMANAGER,
          "font"       : FONT,
          "help"       : info.help,
          "id"         : that.id,
          "screen"     : SCREEN,
          "cover"      : COVER,
          "painter"    : PAINTER,
          "stack"      : info.stack
        }],
        that.ekkoe
      );

      UTILS.Link (Customize, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let that    = this;
      let HELP    = "F1"; 
      let oldHelp = that.ekkoe.Action [HELP];

      that.ekkoe.Action [HELP] = undefined;
      that.ekkoe.Action [HELP] = UTILS.Link (MakeNewHelp, [oldHelp], that.ekkoe);

      return undefined;
    }

  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/
  
    /**********************************************************************
    * NullTerm Escape Function
    /**********************************************************************/
    function EscapeNullTerm () {
      let that        = this;
      let FINALTEXT   = [];
      let ESCAPE      = "Escape";
      let RELOAD      = "F5";
      let finaltext   = UTILS.BLANKCHAR;
//      let currentDate = new Date ();

      that.Action [ESCAPE] = Escape;
      that.Action [RELOAD] = window.location.reload;
//      currentDate          = currentDate.getUTCFullYear ();
      FINALTEXT [0]        = "<br/><br/><br/><br/>";
      FINALTEXT [1]        = "<h2>Press [F5] or [CTRL]+[R] To Start</h2>";
      FINALTEXT [2]        = "<br/><br/>";
      FINALTEXT [3]        = "<h2>Press [CTRL]+[W] To Exit</h2>";
/*
      FINALTEXT [4]        = "<br/><br/>";
      FINALTEXT [5]        = "<p>Ancient Creations &copy; " + currentDate + "</p>"
*/
      function Escape () {
      /************************************************************************************
      * The function which exits nullterm
      ************************************************************************************/
        let that = this;

        for (let i = 0; i < FINALTEXT.length; i ++) {
          finaltext = finaltext + FINALTEXT [i];
        }

        COVER.innerHTML = finaltext;
        that.exists     = false;


        return UTILS.Link (EKKOE.Destroy, [], that);;
      };

      UTILS.Link (that.Action [ESCAPE], [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=undefined) {
      let thatekkoe = this;
      let ARROWDOWN = "ArrowDown";
      let END       = "End";
      let F1        = "F1";
      let ArrowDown = thatekkoe.Action [ARROWDOWN];
      let End       = thatekkoe.Action [END];

      function fakeExit () { return undefined; }

      function Help (event=undefined) {
      /************************************************************************************
      * The function which exits the current servent and enters the help servent
      ************************************************************************************/
        let that             = this;
        let fakeEvent        = Object.create (null);
        let scrollLockActive = that.ekkoe.scrollLock;

        fakeEvent.ctrlKey = true;

        if (scrollLockActive) { that.ekkoe.scrollLock = false; }

        UTILS.Link (End, [fakeEvent], that);
        UTILS.Link (ArrowDown, [event], that);
        UTILS.Link (Helper, [event, fakeExit], that);

        if (scrollLockActive) { that.ekkoe.scrollLock = true; }

        return undefined;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function History () {
      let that             = this;
      let fakeEvent        = Object.create (null);
      let lastline         = undefined;
      let ellipsis         = "...";
      let ARROWDOWN        = "ArrowDown";
      let ARROWUP          = "ArrowUp";
      let BACKSPACE        = "Backspace";
      let ENTER            = "Enter";
      let scrollLockActive = that.ekkoe.scrollLock;

      fakeEvent ["shiftKey"] = true;

      if (scrollLockActive) { that.ekkoe.scrollLock = false; }

      UTILS.Link (EKKOE.Action [ARROWUP], [fakeEvent], that.ekkoe);
      UTILS.Link (EKKOE.Action [BACKSPACE], [fakeEvent], that.ekkoe);
      UTILS.Link (EKKOE.Action [ENTER], [fakeEvent], that.ekkoe);

      lastline = that.ekkoe.line;
      that.ekkoe.words [lastline] = ellipsis;

      for (let i = 0; i < that.history.length; i ++) {
        that.ekkoe.words [lastline] = that.ekkoe.words [lastline] + UTILS.SPACECHAR + that.history [i];
      }

      that.cursor = that.ekkoe.words [lastline].length;

      UTILS.Link (EKKOE.Action [ARROWDOWN], [fakeEvent], that.ekkoe);
      UTILS.Link (EKKOE.ReWrite, [], that.ekkoe);

      if (scrollLockActive) { that.ekkoe.scrollLock = true; }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      UTILS.Link (EKKOE.Destroy, [], that.ekkoe);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    nullterm.Destroy     = Destroy;
    nullterm.History     = History;
    nullterm.Materialize = Materialize;

    return Object.create (nullterm);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  NullTerm = utils.Link (MakeNullTermName, [utils], nulltermspace);

  return NullTerm;
}
