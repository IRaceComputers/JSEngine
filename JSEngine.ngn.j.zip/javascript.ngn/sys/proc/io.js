function MakeEkkoeNameSpace (utils) {
  "use strict";

  let ekkoespace = Object.create (null);
  let Ekkoe      = undefined;

  function MakeEkkoeName (Utils=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let ekkoe        = Object.create (null);
    let Action       = Object.create (null);
    let Printable    = Object.create (null);

    let EXIT         = undefined;
    let FILEMANAGER  = undefined;
    let PAINTER      = undefined;
    let COVER        = undefined;
    let STACK        = undefined;
    let EXPLAIN      = "explain";
    let FGCOLOR      = "#00FEFF";
    let FONT         = "15px Monospace";
    let HELP         = undefined;
    let STARTPRINT   = 0;
    let STOPPRINT    = undefined;
    let STOPCURSOR   = undefined;
    let TABSIZE      = 2;
    let UTILS        = Utils;
    let VISIBLELINES = 0;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Materialize (info=undefined) {
    /************************************************************************************
    * The function which creates the ekkoe process
    ************************************************************************************/
      let that        = this;
      let html        = document.querySelector ("html");
      let center      = document.querySelector ("center");
      let head        = document.querySelector ("head");
      let body        = document.querySelector ("body");
      let painterInfo = Object.create (null);

      EXIT                         = info.escape;
      COVER                        = info.cover;
      FGCOLOR                      = info.fgcolor || FGCOLOR;
      FILEMANAGER                  = info.filemanager;
      FONT                         = info.font || FONT;
      HELP                         = info.help;
      PAINTER                      = info.painter;
      STACK                        = info.stack;
      STOPCURSOR                   = 102;
      that.Action                  = Object.create (Action);
      that.Printable               = Object.create (Printable);
      that.painter                 = Object.create (null);
      that.stack                   = Object.create (null);
      that.viewport                = Object.create (null);
      that.viewport.start          = 0;
      that.viewport.stop           = 1;
      that.viewport.requireUpdate  = false;
      that.help                    = new Array ();
      that.saved                   = new Array ();
      that.words                   = new Array ("The words you type are the cursor.");
      that.color                   = info.bgcolor;
      that.cursor                  = 0;
      that.startcursor             = 0;
      that.stopcursor              = STOPCURSOR;
      that.formercursor            = 0;
      that.id                      = info.id;
      that.line                    = 0;
      that.lineHeight              = 17;
      that.insert                  = false;
      that.scrollLock              = false;
      that.requireRewrite          = true;
      that.superposeCursors        = true;
      that.preventDefault          = true;
      that.stopPropagation         = true;
      that.x                       = 20;
      that.y                       = that.lineHeight;
      COVER.style.backgroundColor  = that.color;
      html.style.backgroundColor   = that.color;
      center.style.backgroundColor = that.color;
      head.style.backgroundColor   = that.color;
      body.style.backgroundColor   = that.color;
      painterInfo.cover            = COVER;
      painterInfo.height           = info.screen.height;
      painterInfo.id               = that.id;
      painterInfo.width            = info.screen.width;

      UTILS.Link (Customize, [] , that);
      UTILS.Link (PAINTER.Materialize, [painterInfo], that.painter);
      UTILS.Link (STACK.Materialize, [], that.stack);
      UTILS.Link (FILEMANAGER.Materialize, [], that);
      UTILS.Link (FILEMANAGER.OpenTo.Read, [HELP], that);
      UTILS.Link (AddHandlerFor, ["keydown", KeydownEventHandler], that);
      UTILS.Link (AddHandlerFor, ["resize", ResizeEventHandler] , that);
      UTILS.Link (PAINTER.AddHandlerFor, ["wheel", MouseWheelScrollHandler], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let that         = this;
      let ESCAPE       = "Escape";
      let HELP         = "F1";
      let AFTERREADING = "InternalCall";
      let oldHelp      = that.Action [HELP];

      that.Action [ESCAPE]       = EXIT;
      that.Action [HELP]         = UTILS.Link (MakeNewHelp, [oldHelp], that);
      that.Action [AFTERREADING] = UseFileContents;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UseFileContents (event=undefined) {
      let that = this;

      for (let i = 0; i < that.words.length; i ++) {
        that.help.push (that.words [i]);
        that.saved.push (that.words [i]);
      }

      UTILS.Link (ReWrite, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function AddHandlerFor (EventName=undefined, EventHandlerFunction=undefined) {
    /************************************************************************************
    * The function which adds an event handler for the ekkoe process
    ************************************************************************************/
      let that         = this;
      let EventHandler = EventHandlerFunction.bind (that);

      that.Action [EventName] = EventHandler;

      window.addEventListener (EventName, EventHandler, true);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RemoveHandlerFor (EventName=undefined) {
    /************************************************************************************
    * The function which removes an event handler for the ekkoe process 
    ************************************************************************************/
      let that         = this;
      let EventHandler = that.Action [EventName];

      window.removeEventListener (EventName, EventHandler, true);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=undefined) {
      let thatekkoe = this;
      let ARROWDOWN = "ArrowDown";
      let END       = "End";
      let ESCAPE    = "Escape";
      let F1        = "F1";
      let ArrowDown = thatekkoe.Action [ARROWDOWN];
      let End       = thatekkoe.Action [END];
      let Escape    = thatekkoe.Action [ESCAPE];

      function Help (event=undefined, otherEscape=undefined) {
      /************************************************************************************
      * The function which exits the current servent and enters the help servent
      ************************************************************************************/
        let that             = this;
        let fakeEvent        = Object.create (null);
        let scrollLockActive = that.scrollLock;
        let SCROLLLOCK       = "ScrollLock";

        fakeEvent.ctrlKey = true;

        if (otherEscape !== undefined) { Escape = otherEscape; }

        UTILS.Link (End, [fakeEvent], that);

        if (scrollLockActive) {
          UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
        }

        UTILS.Link (ArrowDown, [fakeEvent], that);

        if (scrollLockActive) {
          UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
        }

        UTILS.Link (Helper, [fakeEvent], that);
        UTILS.Link (Escape, [fakeEvent], that);

        return undefined;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ReWrite (somewords=undefined) { 
      let that            = this;
      let visibleSentence = undefined;
      let words           = somewords;
      let i               = 0;

      if (words === undefined) { words = that.words; }

      UTILS.Link (PAINTER.BeginPath);
      UTILS.Link (PAINTER.SetFillColorTo, [that.color]);
      UTILS.Link (PAINTER.PaintBackGround);
      UTILS.Link (PAINTER.SetFontTo, [FONT]);
      UTILS.Link (PAINTER.SetFillColorTo, [FGCOLOR]);

      that.y             = that.lineHeight;
      that.viewport.stop = that.viewport.start;

      if (STOPPRINT === undefined) {
        STOPPRINT    = UTILS.Link (PAINTER.GetCanvasHeight) - 2 * that.lineHeight;
        VISIBLELINES = STOPPRINT - (STOPPRINT % that.lineHeight);
        VISIBLELINES = VISIBLELINES / that.lineHeight;
      }

      while ((i + that.y) < STOPPRINT) {
       that.viewport.stop = that.viewport.stop + 1;
       i = i + that.y;
      }

      if (that.viewport.stop > words.length) {
        that.viewport.stop = words.length;
      }

      i = that.viewport.start;

      while (i < that.viewport.stop) {
        if (i === that.line) {
          visibleSentence = words [i].substring (that.startcursor, that.stopcursor);
        }
        else { visibleSentence = words [i].substring (0, STOPCURSOR); }

        UTILS.Link (PAINTER.FillText, [visibleSentence], that);
        UTILS.Link (NewLine, [], that);

        i = i + 1;
      }

      UTILS.Link (PAINTER.ClosePath);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define arbitrary internal functions below
  ************************************************************************************/

    function NewLine () {
    /************************************************************************************
    * The function which moves the cursor to the next line on the kanvas 
    ************************************************************************************/
      let that = this;
      that.y = that.y + that.lineHeight;
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function AdjustBoundingCursors () {
      let that = this;

      that.startcursor = that.cursor - (STOPCURSOR / 2);
      that.stopcursor  = that.cursor + (STOPCURSOR / 2);

      if (that.startcursor < 0) { that.startcursor = 0; }

      if (that.stopcursor > that.words [that.line].length) {
        that.stopcursor = that.words [that.line].length;
      }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UpdateViewPort () {
      let that = this;

      if (that.line < that.viewport.start) {
        that.viewport.start = that.line;

        if (that.words.length >= VISIBLELINES) {
          that.viewport.stop = that.viewport.start + VISIBLELINES;
        }
        else { that.viewport.stop = that.words.length; }
      }
      else if (that.line >= that.viewport.stop) {
        that.viewport.stop = that.line + 1;

        if (that.words.length >= VISIBLELINES) {
          that.viewport.start = that.viewport.stop - VISIBLELINES;
        }
      }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SkipWordMoveCursor (spaceCharSide=undefined) {
      let that  = this;
      let chars = undefined;
      let line  = that.words [that.line];
      let LEFT  = 0;
      let RIGHT = 1

      if ((LEFT === spaceCharSide) || (spaceCharSide === RIGHT)) {
        if (spaceCharSide === RIGHT) {
          for (let o = that.cursor; o <= line.length - 2; o ++) {
            chars = line.substring (o, o+2);

            if ((chars.charAt (RIGHT) === UTILS.SPACECHAR) && (chars.charAt (LEFT) !== UTILS.SPACECHAR)) {
              return (o+1);
            }
          }

          return line.length;
        }
        else {
          for (let o = that.cursor; o >= 2; o --) {
            chars = line.substring (o-2, o);

            if ((chars.charAt (LEFT) === UTILS.SPACECHAR) && (chars.charAt (RIGHT) !== UTILS.SPACECHAR)) {
              return (o-1);
            }
          }

          return LEFT;
        }
      }

      return (-RIGHT);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function InvisibleCharacter (key=undefined) {
    /************************************************************************************
    * The function which determines whether a character is non-printable 
    ************************************************************************************/
      let invisibility = false;

      switch (key) {
        case "Alt"               : invisibility = true; break;
        case "AltGraph"          : invisibility = true; break;
        case "ArrowDown"         : invisibility = true; break;
        case "ArrowLeft"         : invisibility = true; break;
        case "ArrowRight"        : invisibility = true; break;
        case "ArrowUp"           : invisibility = true; break;
        case "AudioVolumeDown"   : invisibility = true; break;
        case "AudioVolumeMute"   : invisibility = true; break;
        case "AudioVolumeUp"     : invisibility = true; break;
        case "Backspace"         : invisibility = true; break;
        case "CapsLock"          : invisibility = true; break;
        case "Control"           : invisibility = true; break;
        case "ContextMenu"       : invisibility = true; break;
        case "Delete"            : invisibility = true; break;
        case "End"               : invisibility = true; break;
        case "Enter"             : invisibility = true; break;
        case "Escape"            : invisibility = true; break;
        case "F1"                : invisibility = true; break;
        case "F2"                : invisibility = true; break;
        case "F3"                : invisibility = true; break;
        case "F4"                : invisibility = true; break;
        case "F5"                : invisibility = true; break;
        case "F6"                : invisibility = true; break;
        case "F7"                : invisibility = true; break;
        case "F8"                : invisibility = true; break;
        case "F9"                : invisibility = true; break;
        case "F10"               : invisibility = true; break;
        case "F11"               : invisibility = true; break;
        case "F12"               : invisibility = true; break;
        case "Home"              : invisibility = true; break;
        case "Insert"            : invisibility = true; break;
        case "MediaPlay"         : invisibility = true; break;
        case "MediaTrackNext"    : invisibility = true; break;
        case "MediaTrackPrevious": invisibility = true; break;
        case "NumLock"           : invisibility = true; break;
        case "OS"                : invisibility = true; break;
        case "PageDown"          : invisibility = true; break;
        case "PageUp"            : invisibility = true; break;
        case "Shift"             : invisibility = true; break;
        case "ScrollLock"        : invisibility = true; break;
        case "Tab"               : invisibility = true; break;
        case "Unidentified"      : invisibility = true; break;
      }

      return invisibility;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CommandCharacter (key=undefined) {
    /************************************************************************************
    * The function which determines whether a character is treated as a command 
    ************************************************************************************/
      let status = false;

      switch (key) {
        case "ArrowDown"         : status = true; break;
        case "ArrowLeft"         : status = true; break;
        case "ArrowRight"        : status = true; break;
        case "ArrowUp"           : status = true; break;
        case "AudioVolumeDown"   : status = true; break;
        case "AudioVolumeMute"   : status = true; break;
        case "AudioVolumeUp"     : status = true; break;
        case "Backspace"         : status = true; break;
        case "ContextMenu"       : status = true; break;
        case "Delete"            : status = true; break;
        case "End"               : status = true; break;
        case "Enter"             : status = true; break;
        case "Escape"            : status = true; break;
        case "F1"                : status = true; break;
        case "F2"                : status = true; break;
        case "F5"                : status = true; break;
        case "F6"                : status = true; break;
        case "F8"                : status = true; break;
        case "F9"                : status = true; break;
        case "F10"               : status = true; break;
        case "F11"               : status = true; break;
        case "Home"              : status = true; break;
        case "Insert"            : status = true; break;
        case "MediaPlay"         : status = true; break;
        case "MediaTrackNext"    : status = true; break;
        case "MediaTrackPrevious": status = true; break;
        case "OS"                : status = true; break;
        case "PageDown"          : status = true; break;
        case "PageUp"            : status = true; break;
        case "ScrollLock"        : status = true; break;
        case "Tab"               : status = true; break;
      // add cases to handle other command keys
      }

      return status;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandleCommand (event=undefined) {
    /************************************************************************************
    * The function which handles command keys for the ekkoe process 
    ************************************************************************************/
      let that = this;
      return UTILS.Link (that.Action [event.key], [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["InternalCall"] = function () {
    /************************************************************************************
    * The function which ...
    ************************************************************************************/
      let that = this;
      console.log ("[ internal call: ", that.words [0], " ]");
      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["OS"] = function () {
    /************************************************************************************
    * The function which ...
    ************************************************************************************/
      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["ArrowLeft"] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the left
    ************************************************************************************/
      let that      = this;
      let ARROWUP   = "ArrowUp";
      let END       = "End";

      if (event.ctrlKey) {
        let LEFT      = 0;

        if (that.cursor === 0) {
          let fakeEvent = Object.create (null);
          let ARROWLEFT = "ArrowLeft";

          fakeEvent.ctrlKey = false;
          
          UTILS.Link (Action [ARROWLEFT], [fakeEvent], that); 
        }
        else {
          that.cursor = UTILS.Link (SkipWordMoveCursor, [LEFT], that);
          UTILS.Link (AdjustBoundingCursors, [], that);
        }
      }
      else {
        if (that.cursor > 0) {
          that.cursor = that.cursor - 1;

          UTILS.Link (UpdateViewPort, [], that);
          UTILS.Link (AdjustBoundingCursors, [], that);
        }
        else {
          let fakeEvent        = Object.create (null);
          let scrollLockActive = that.scrollLock;
          let SCROLLLOCK       = "ScrollLock";

          if (scrollLockActive) {
            UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
          }

          UTILS.Link (Action [ARROWUP], [event], that);

          if (scrollLockActive) {
            UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
          }

          UTILS.Link (Action [END], [fakeEvent], that);
        }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["ArrowUp"] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the next line above 
    ************************************************************************************/
      let that    = this;

      if (that.scrollLock) {
        event.deltaY = -3;
        UTILS.Link (MouseWheelScrollHandler, [event], that);
      }
      else if (event.shiftKey && event.ctrlKey) {
        let currentline  = that.line;
        let previousline = currentline - 1;
        let tmpline      = undefined;

        if (previousline >= 0) {
          tmpline = that.words [previousline];
          that.words [previousline] = that.words [currentline];
          that.words [currentline] = tmpline;
          that.line = previousline;
        }
      }
      else {
        let count = 0;
        let lastline = that.words.length - 1;

        if (that.line > 0) {
          that.line   = that.line - 1;
          that.cursor = that.words [that.line].length;
        }

        while (that.line < lastline && that.words [lastline].trim () === UTILS.BLANKCHAR) {
          count = count + 1;
          lastline = lastline - 1;
        }

        if (count > 0) {
          that.words  = that.words.splice (0, that.words.length - count);
        }

        UTILS.Link (UpdateViewPort, [], that);
        UTILS.Link (AdjustBoundingCursors, [], that);
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["ArrowDown"] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the next line below
    ************************************************************************************/
      let that = this;

      if (that.scrollLock) { 
        event.deltaY = 3;
        UTILS.Link (MouseWheelScrollHandler, [event], that);
      }
      else if (event.shiftKey && event.ctrlKey) {
        let currentline = that.line;
        let nextline    = currentline + 1;
        let tmpline     = undefined;

        if (nextline < that.words.length) {
          tmpline = that.words [nextline];
          that.words [nextline] = that.words [currentline];
          that.words [currentline] = tmpline;
          that.line = nextline;
        }
      }
      else {
        let lastline = that.words.length - 1;

        if (lastline === that.line) { that.words.push (UTILS.BLANKCHAR); }

        that.line   = that.line + 1;
        that.cursor = that.words [that.line].length;

        UTILS.Link (UpdateViewPort, [], that);
        UTILS.Link (AdjustBoundingCursors, [], that);
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["ArrowRight"] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the right 
    ************************************************************************************/
      let that      = this;
      let ARROWDOWN = "ArrowDown";
      let HOME      = "Home";

      if (event.ctrlKey) {
        let RIGHT = 1;

        if (that.cursor === that.words [that.line].length) {
          let fakeEvent  = Object.create (null);
          let ARROWRIGHT = "ArrowRight";

          fakeEvent.ctrlKey = false;
          
          UTILS.Link (Action [ARROWRIGHT], [fakeEvent], that); 
        }
        else {
          that.cursor = UTILS.Link (SkipWordMoveCursor, [RIGHT], that);
          UTILS.Link (AdjustBoundingCursors, [], that);
        }
      }
      else {
        if (that.cursor < that.words [that.line].length) {
          that.cursor = that.cursor + 1;

          UTILS.Link (UpdateViewPort, [], that);
          UTILS.Link (AdjustBoundingCursors, [], that);
        }
        else {
          let fakeEvent        = Object.create (null);
          let scrollLockActive = that.scrollLock;
          let SCROLLLOCK       = "ScrollLock";

          if (scrollLockActive) {
            UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
          }

          UTILS.Link (Action [ARROWDOWN], [event], that);

          if (scrollLockActive) {
            UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
          }

          UTILS.Link (Action [HOME], [fakeEvent], that);
        }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["Backspace"] = function (event=undefined) {
    /************************************************************************************
    * The function which removes one character to the left of the cursor
    ************************************************************************************/
      let that       = this;
      let fakeEvent        = Object.create (null);
      let words      = that.words;
      let line       = words [that.line];
      let leftbit    = undefined;
      let midbit     = undefined;
      let rightbit   = undefined;
      let BACKSPACE  = "Backspace";
      let DELETELINE = "F9";

      if (event.shiftKey) {
        fakeEvent.shiftKey = false;

        UTILS.Link (Action [DELETELINE], [fakeEvent], that);
        UTILS.Link (Action [BACKSPACE], [fakeEvent], that);
      }
      else {
        if (that.cursor > 0) {
          line = words [that.line].substring (0, that.cursor - 1);
          line = line + words [that.line].substring (that.cursor, words [that.line].length);
          words [that.line] = line;
          that.cursor       = that.cursor - 1;

          UTILS.Link (AdjustBoundingCursors, [], that);
        }
        else {
          if ((that.words.length > 1) && (that.line > 0)) {
            leftbit    = that.words.splice (0, that.line);
            midbit     = that.words.splice (0,1);
            rightbit   = that.words.splice (0);
            that.words = leftbit.concat (rightbit);

            if (that.line > 0) { that.line = that.line - 1; }

            that.cursor = that.words [that.line].length;
            that.words [that.line] = that.words [that.line] + midbit;

            UTILS.Link (UpdateViewPort, [], that);
            UTILS.Link (AdjustBoundingCursors, [], that);
          }
        }
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["ContextMenu"] = function (event=undefined) {
      let that = this;

      that.preventDefault  = false;
      that.stopPropagation = false;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["Delete"] = function (event=undefined) {
    /************************************************************************************
    * The function which removes one character to the right of the cursor
    ************************************************************************************/
      let that  = this;
      let words = that.words;
      let line  = words [that.line];

      if (that.cursor < line.length) {
        line = words [that.line].substring (0, that.cursor);
        line = line + words [that.line].substring (that.cursor + 1, words [that.line].length);
        words [that.line] = line;

        if (that.cursor > that.words [that.line].length) {
          that.cursor -= 1;
        }

        UTILS.Link (AdjustBoundingCursors, [], that);
      }
      else {
        let fakeEvent        = Object.create (null);
        let scrollLockActive = that.scrollLock;
        let SCROLLLOCK       = "ScrollLock";
        let ARROWDOWN        = "ArrowDown";
        let BACKSPACE        = "Backspace";
        let HOME             = "Home";

        fakeEvent.shiftKey = false;

        if (scrollLockActive) {
          UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
        }

        UTILS.Link (Action [ARROWDOWN], [fakeEvent], that);

        if (scrollLockActive) {
          UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
        }

        UTILS.Link (Action [HOME], [fakeEvent], that);
        UTILS.Link (Action [BACKSPACE], [fakeEvent], that);
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["End"] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the end of the line
    ************************************************************************************/
      let that = this;

      if (event.ctrlKey) {
        that.line = that.words.length - 1;
        UTILS.Link (UpdateViewPort, [], that);
      }

      that.cursor = that.words [that.line].length;

      UTILS.Link (AdjustBoundingCursors, [], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["Enter"] = function () {
    /************************************************************************************
    * The function which moves the cursor to the next line
    ************************************************************************************/
      let that         = this;
      let leftbit      = undefined;
      let rightbit     = undefined;
      let leftsubline  = undefined;
      let rightsubline = undefined;
      let START        = 0;

      leftbit  = that.words.splice (START, that.line);
      rightbit = that.words.splice (START);

      leftbit.push (UTILS.BLANKCHAR);

      leftsubline                  = rightbit [START].substring (START, that.cursor);
      rightsubline                 = rightbit [START].substring (that.cursor, rightbit [START].length);
      leftbit [leftbit.length - 1] = leftsubline;
      rightbit [START]             = rightsubline;
      that.words                   = leftbit.concat (rightbit);
      that.cursor                  = START;
      that.line                    = that.line + 1;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["Escape"] = EXIT;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["F1"] = function () {
    /************************************************************************************
    * The function which displays the help text for the ekkoe process
    ************************************************************************************/
      let that   = this;
      let helper = EXPLAIN + that.id;

      that.words[that.line] = that.words[that.line] + helper;
      that.cursor           = that.words[that.line].length;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["F2"] = function () {
    /************************************************************************************
    * The function which name of the file opened in the ekkoe process
    ************************************************************************************/
      let that      = this;
      let fakeEvent = Object.create (null);
      let filename  = UTILS.Link (FILEMANAGER.GetFileName);
      let END       = "End";

      fakeEvent.ctrlKey = true;

      that.words.push (filename);

      UTILS.Link (Action [END], [fakeEvent], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["F8"] = function (event = undefined) {
    /************************************************************************************
    * The function which navigates to the web address specified on the last line
    ************************************************************************************/
      let that      = this;
      let fakeEvent = Object.create (null);
      let url       = undefined;
      let urlline   = that.words [that.words.length - 1];
      let ARROWDOWN = "ArrowDown";
      let ARROWUP   = "ArrowUp";
      let END       = "End";

      if (event.ctrlKey) {
        let scrollLockActive = that.scrollLock;
        let SCROLLLOCK       = "ScrollLock";

        url               = window.location.href;
        fakeEvent.ctrlKey = true;

        UTILS.Link (Action [END], [fakeEvent], that);

        if (scrollLockActive) {
          UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
        }

        UTILS.Link (Action [ARROWDOWN], [fakeEvent], that);

        that.words [that.line] = url;
        fakeEvent.ctrlKey      = false;

        UTILS.Link (Action [ARROWDOWN], [fakeEvent], that);
        UTILS.Link (Action   [ARROWUP], [fakeEvent], that);

        if (scrollLockActive) {
          UTILS.Link (Action [SCROLLLOCK], [fakeEvent], that);
        }
      }
      else {
        urlline = urlline.trim ();
        urlline = urlline.split (UTILS.SPACECHAR);
        urlline = UTILS.Link (UTILS.Filter, [UTILS.SPACECHAR, urlline]);
        urlline = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, urlline]);
        url     = urlline [0];

        window.location.assign (url);
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["F9"] = function () {
    /************************************************************************************
    * The function which removes all the characters in the current line
    ************************************************************************************/
      let that = this;

      that.words[that.line] = "";
      that.cursor           = 0;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["F10"] = function () {
    /************************************************************************************
    * The function which clears all text stored by the ekkoe process
    ************************************************************************************/
      let that = this;

      that.cursor = 0;
      that.line   = 0;
      that.words  = [""];

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["F11"] = function () {
    /************************************************************************************
    * The function which requests maximum screen for the ekkoe process
    ************************************************************************************/
      let that = this;
      UTILS.Link (LaunchFullscreen, [], that);
      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["Home"] = function (event=undefined) {
    /************************************************************************************
    * The function which moves the cursor to the beginning of the line
    ************************************************************************************/
      let that = this;

      if (event.ctrlKey) {
        that.line = 0;
        UTILS.Link (UpdateViewPort, [], that);
      }

      that.cursor = 0;

      UTILS.Link (AdjustBoundingCursors, [], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["Insert"] = function (event=undefined) {
    /************************************************************************************
    * The function which toggles character replacing
    ************************************************************************************/
      let that = this;

      that.insert = !that.insert;

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["Tab"] = function (event=undefined) {
    /************************************************************************************
    * The function which adds a tab-equivalent-of-spaces to the current line
    ************************************************************************************/
      let that       = this;
      let WHITESPACE = " ";
      let fakeEvent  = Object.create (null);

      that.preventDefault  = true;
      that.stopPropagation = true;
      fakeEvent.key        = WHITESPACE;

      for (let i = 0; i < TABSIZE; i ++) {
        UTILS.Link (that.Printable [WHITESPACE], [fakeEvent], that);
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["PageDown"] = function (event=undefined) {
    /************************************************************************************
    * The function which increases the length of the kanvas
    ************************************************************************************/
      let that = this;

           if (event.altKey)   { UTILS.Link (PAINTER.ChangeCanvasHeightBy, [2]);; }//{ UTILS.Link (PAINTER.HideCanvas); }
      else if (event.shiftKey) { UTILS.Link (PAINTER.ChangeCanvasWidthBy, [2]); }
      else if (event.ctrlKey)  { UTILS.Link (PAINTER.ChangeCanvasHeightBy, [2]);; }
      else {
        that.line = that.viewport.stop - 1;

        for (let i = 0; (i < VISIBLELINES) && (that.line + 1 < that.words.length); i ++) {
          that.line = that.line + 1;
        }

        that.cursor = that.words [that.line].length;

        UTILS.Link (AdjustBoundingCursors, [], that);
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["PageUp"] = function (event=undefined) {
    /************************************************************************************
    * The function which increases the length of the kanvas
    ************************************************************************************/
      let that = this;

           if (event.altKey)   { UTILS.Link (PAINTER.ShowCanvas); }
      else if (event.shiftKey) { UTILS.Link (PAINTER.ChangeCanvasWidthBy, [-2]); }
      else if (event.ctrlKey)  { UTILS.Link (PAINTER.ChangeCanvasHeightBy, [-2]);; }
      else {
        that.line = that.viewport.start;

        for (let i = 0; (i < VISIBLELINES) && (that.line > 0); i ++) {
          that.line = that.line - 1;
        }

        that.cursor = that.words [that.line].length;

        UTILS.Link (AdjustBoundingCursors, [], that);
      }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Action ["ScrollLock"] = function (event=undefined) {
      let that = this;

      that.scrollLock      = !that.scrollLock;
      that.scrollLockEvent = event;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandlePrintCharacter (event=undefined) {
    /************************************************************************************
    * The function which handles printable character keys for the ekkoe process 
    ************************************************************************************/
      let that      = this;
      let DELETE    = "Delete";
      let fakeEvent = Object.create (null);

      if (that.insert) {
        if (that.cursor < that.words [that.line].length) {
          UTILS.Link (Action [DELETE], [fakeEvent], that);
        }
      }

      return UTILS.Link (that.Printable [event.key], [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

   function PrintCharacter (key=undefined) {
      let that          = this;
      let currentline   = that.words [that.line];
      let endOfThisLine = currentline.length;
      let subline       = currentline.substring (0, that.cursor)

      that.words [that.line] = subline + key;
      subline                = currentline.substring (that.cursor, endOfThisLine)
      that.words [that.line] = that.words [that.line] + subline;
      that.cursor            = that.cursor + key.length;

      UTILS.Link (AdjustBoundingCursors, [], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["~"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["`"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["1"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["!"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["2"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["@"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["3"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["#"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["4"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["$"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["5"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["%"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["6"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["^"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["7"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["&"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["8"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["*"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["9"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["("] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["0"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [")"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["-"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["_"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["="] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["+"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Q"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["q"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["W"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["w"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["E"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["e"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["R"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["r"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["T"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

     Printable ["t"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Y"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["y"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["U"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["u"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["I"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["i"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["O"] = function (event) {
      let that = this;

      if (event.ctrlKey) {
        let lastline = that.words.length - 1;
        let filename = that.words [lastline].trim ();
        UTILS.Link (FILEMANAGER.OpenTo.Read, [filename], that);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["o"] = function (event) {
      let that = this;

      if (event.ctrlKey) {
        let lastline = that.words.length - 1;
        let filename = that.words [lastline].trim ();
        UTILS.Link (FILEMANAGER.OpenTo.Read, [filename], that);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["P"] = function (event) {
      let that = this;

      if (event.ctrlKey) {
        that.preventDefault   = false;
        that.stopPropagation  = false;
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["p"] = function (event) {
      let that = this;

      if (event.ctrlKey) {
        that.preventDefault   = false;
        that.stopPropagation  = false;
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["["] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["{"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["]"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["}"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["\\"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["|"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["A"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["a"] = function (event) {
      let that = this;
      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["S"] = function (event) {
      let that = this;

      if (event.ctrlKey === true) {
        let fakeEvent = Object.create (null);
        let newfile   = that.words [that.words.length - 1].trim ();
        let BACKSPACE = "Backspace";

        fakeEvent.shiftKey = true;

        UTILS.Link (Action [BACKSPACE], [fakeEvent], that);

        that.saved  = [];
        that.cursor = that.words [that.line].length;

        that.words.forEach (line => { that.saved.push (line); });

        UTILS.Link (FILEMANAGER.OpenTo.Write, [newfile], that);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["s"] = function (event) {
      let that = this;

      if (event.ctrlKey === true) { 
        that.saved = [];
        that.words.forEach( line => { that.saved.push (line); } );
        UTILS.Link (FILEMANAGER.OpenTo.Write, [], that);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["D"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["d"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["F"] = function (event) {
      let that = this;

      if (event.ctrlKey) {
        let keyword     = that.words [that.words.length - 1];
        let currentline = that.line;

        if (currentline > 0) { currentline = currentline - 1; }
        else /*************/ { currentline = that.words.length - 1; }

        for (let i = currentline; i > -1; i = (i - 1)) {
          i = UTILS.Link (ThoroughSearch, [keyword, UTILS.BLANKCHAR, i, -1], that);
        }
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ThoroughSearch (keyword=undefined, blank=undefined, linenumber=undefined, eof=undefined) {
      let that        = this;
      let wordchars   = that.words [linenumber].split (blank);
      let k           = keyword.length;
      let searchstart = 0;

      for (let j = searchstart; (wordchars.length >= k) && (j + k <= wordchars.length); j ++) {
        let comparisonString = that.words [linenumber].substring (j, j + k);

        if (keyword === comparisonString) {
          that.line   = linenumber;
          that.cursor = j + k;
          j           = wordchars.length;
          linenumber  = eof;

          UTILS.Link (AdjustBoundingCursors, [], that);
        }
      }

      return linenumber;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["f"] = function (event) {
      let that = this;

      if (event.ctrlKey) { 
        let keyword     = that.words [that.words.length - 1];
        let currentline = that.line;

        if ((currentline + 1) < that.words.length) {
          currentline = currentline + 1;
        }
        else { currentline = 0; }

        for (let i = currentline; i < that.words.length; i = (i + 1)) {
          i = UTILS.Link (ThoroughSearch, [keyword, UTILS.BLANKCHAR, i, that.words.length], that);
        }
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["G"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["g"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["H"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["h"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["J"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["j"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["K"] = function (event) {
      let that = this;

      if (event.altKey) {
        let currentline = that.words[that.line];
        that.words.push (UTILS.BLANKCHAR);
        that.words.push (currentline);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["k"] = function (event) {
      let that = this;

      if (event.altKey) {
        let currentline = that.words[that.line];
        that.words.push (UTILS.BLANKCHAR);
        that.words.push (currentline);
      }
      else { UTILS.Link (PrintCharacter, [event.key], that); }

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["L"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["l"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [";"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [":"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["'"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["\""] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Z"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["z"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["X"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["x"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["C"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["c"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["V"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["v"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["B"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["b"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["N"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["n"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["M"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["m"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [","] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["<"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["."] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [">"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["/"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["?"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable [" "] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["“"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["”"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¹"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¥"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["£"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["€"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ł"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ë"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ê"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ṱ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["û"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ü"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ï"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ö"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ä"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["š"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ḓ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["đ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ŋ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ħ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ĸ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ḽ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["«"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["»"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¢"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ṋ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ṅ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¬"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¡"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["⅛"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["⅜"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["⅝"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["⅞"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["™"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["±"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["°"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["¿"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ω"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ł"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ë"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ê"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ṱ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Û"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ü"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ï"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ö"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ô"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ä"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Š"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ḓ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["ª"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ŋ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ħ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ḽ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["©"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["‘"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["’"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ṋ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["Ṅ"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["×"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    Printable ["÷"] = function (event) {
      let that = this;

      UTILS.Link (PrintCharacter, [event.key], that);

      return undefined;
    };

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define event handlers below
  ************************************************************************************/

    function KeydownEventHandler (event=undefined) {
    /************************************************************************************
    * The function which is the keydown-event-handler for the ekkoe process 
    ************************************************************************************/
      let that                    = this;
      that.requireRewrite         = true;
      that.superposeCursors       = true;
      that.viewport.requireUpdate = true;
      that.preventDefault         = true;
      that.stopPropagation        = true;

      if (UTILS.Link (InvisibleCharacter, [event.key], null)) {
        //handle non-printable characters
        if (UTILS.Link (CommandCharacter, [event.key], null)) {
          UTILS.Link (HandleCommand, [event], that);

          if (that.viewport.requireUpdate) {
            UTILS.Link (UpdateViewPort, [], that);
          }
        }
      }
      else {
        UTILS.Link (HandlePrintCharacter, [event], that);

        if (that.viewport.requireUpdate) {
          UTILS.Link (UpdateViewPort, [], that);
        }
      }

      if (that.requireRewrite) { UTILS.Link (ReWrite, [], that); }

      if (that.superposeCursors) {
        that.formercursor     = that.cursor;
        that.superposeCursors = true;
      }

      if (that.preventDefault) { event.preventDefault (); }
      if (that.stopPropagation) { event.stopPropagation (); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/


    function ResizeEventHandler (event) {
      let that = this;

      UTILS.Link (PAINTER.SetCanvasHeightTo, [window.innerHeight - 20]);
      UTILS.Link (PAINTER.SetCanvasWidthTo, [window.innerWidth - 20]);

      UTILS.Link (ReWrite, [], that);
    }


  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LaunchFullscreen () {
      let that    = this;
      let element = document.documentElement;

      if (element.requestFullscreen      ) { element.requestFullscreen      (); } else
      if (element.mozRequestFullScreen   ) { element.mozRequestFullScreen   (); } else
      if (element.webkitRequestFullscreen) { element.webkitRequestFullscreen(); } else
      if (element.msRequestFullscreen    ) { element.msRequestFullscreen    (); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ExitFullscreen () {
      if (document.exitFullscreen      ) { document.exitFullscreen      (); } else
      if (document.mozCancelFullScreen ) { document.mozCancelFullScreen (); } else
      if (document.webkitExitFullscreen) { document.webkitExitFullscreen(); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MouseWheelScrollHandler (event=undefined) {
      let that         = this;
      let SCROLLAMOUNT = 3;

      that.requireRewrite = true;

      if (that.scrollLock) {
        SCROLLAMOUNT                = 1;
        that.viewport.requireUpdate = false;
      }

      if (event.ctrlKey) { UTILS.Link (UpdateFontSize, [event.deltaY], that); }
      else {
        if (event.deltaY > 0) {
          for (let o = 0; (o < SCROLLAMOUNT) && (that.viewport.stop < that.words.length); o ++) {
            that.viewport.start = that.viewport.start + 1;
            that.viewport.stop = that.viewport.stop + 1;
          }
        }
        else {
          for (let o = 0; (o < SCROLLAMOUNT) && (that.viewport.start > 0); o ++) {
            that.viewport.start = that.viewport.start - 1;
            that.viewport.stop = that.viewport.stop - 1;
          }
        }
      }

      if (that.requireRewrite) { UTILS.Link (ReWrite, [], that); }

      event.preventDefault ();
      event.stopPropagation ();

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UpdateFontSize (amount=undefined) {
      let that      = this;
      let fontUnits = UTILS.BLANKCHAR;
      let fontArray = FONT.split (UTILS.SPACECHAR);
      let fontSize  = fontArray [0].split (UTILS.BLANKCHAR);
      let deltaSize = undefined;

      fontUnits = fontSize.pop () + fontUnits;
      fontUnits = fontSize.pop () + fontUnits;
      fontSize  = fontSize.join (UTILS.BLANKCHAR);
      fontSize  = UTILS.Link (UTILS.ToNumber, [undefined, fontSize]);
      deltaSize = (amount / amount);

      if (amount > 0) {
        deltaSize = -1 * deltaSize;

        if (fontSize > 1) {
          fontSize        = fontSize + deltaSize;
          that.lineHeight = that.lineHeight + deltaSize;
          STOPCURSOR      = STOPCURSOR - deltaSize;
        }
      }
      else {
        fontSize        = fontSize + deltaSize;
        that.lineHeight = that.lineHeight + deltaSize;
        STOPCURSOR      = STOPCURSOR - deltaSize;
      }

      FONT = fontSize + fontUnits + UTILS.SPACECHAR + fontArray [1];

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
    /************************************************************************************
    * The function which destroys the ekkoe process
    ************************************************************************************/
      let that = this;

      while (that.stack.size > 0) {
        UTILS.Link (STACK.Pop, [], that.stack);
        that.stack.popped.abort ();
      }

      UTILS.Link (RemoveHandlerFor, ["keydown"], that);
      UTILS.Link (RemoveHandlerFor, ["resize"] , that);
      UTILS.Link (PAINTER.Destroy, [], that.painter);

      return undefined;
    }

  /************************************************************************************/

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /***********************************************************************************/
    ekkoe.Materialize      = Materialize;
    ekkoe.Destroy          = Destroy;
    ekkoe.Action           = Action;
    ekkoe.Printable        = Printable;
    ekkoe.AddHandlerFor    = AddHandlerFor;
    ekkoe.NewLine          = NewLine;
    ekkoe.PrintCharacter   = PrintCharacter;
    ekkoe.RemoveHandlerFor = RemoveHandlerFor;
    ekkoe.ReWrite          = ReWrite;
  /***********************************************************************************/

    return Object.create (ekkoe);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Ekkoe = utils.Link (MakeEkkoeName, [utils], ekkoespace);

  return Ekkoe;
}
