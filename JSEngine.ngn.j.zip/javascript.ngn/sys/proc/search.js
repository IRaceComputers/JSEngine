/*
    JSEngine finds and runs user programs based on the user's input.
    Copyright (C) <2018>  <Sbabalwe Mchasa>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

    Email: gmeta07@gmail.com
*/
function MakeJSEngineNameSpace (utils) {
  "use strict";

  let jsenginespace = Object.create (null);
  let JSEngine      = undefined;

  function MakeJSEngineName (Utils=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let jsengine = Object.create (null);

    /***********************************************************************************
    * All The Necessary State Variables and Constants
    /***********************************************************************************/
    let EKKOE       = undefined;
    let INITDATA    = undefined;
    let INITIATE    = undefined;
    let NULLTERM    = undefined;
    let PROCESS     = undefined;
    let SERVER      = undefined;
    let STARTENGINE = undefined;
    let UTILS       = Utils;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Materialize (info=undefined) {
      let that = this;

      EKKOE       = info.ekkoe;
      INITDATA    = info.initdata;
      INITIATE    = info.initiate;
      NULLTERM    = info.nullterm;
      PROCESS     = info.process;
      SERVER      = info.server;
      STARTENGINE = info.StartProcess;
      that.id     = info.id;

    /**********************************************************************
    * The Actual Initiation Of The Whole Application
    /**********************************************************************/
      UTILS.Link (STARTENGINE, [], SERVER);
      UTILS.Link (UTILS.Animate, [Interpreter], window);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    /********************************************************
    * Command Interpreter and Process Switcher: the engine
    /*******************************************************/
    function Interpreter () {
      let command          = undefined;
      let identity         = "id";
      let scrollLockActive = SERVER.ekkoe.scrollLock;
      // a short-to-write reference to the array of lines of text ...
      // ... on the nullterm screen
      let words     = SERVER.ekkoe.words;
      // an array of the words in the last line of text ...
      // ... on the nullterm screen
      let lastline  = words [words.length - 1].trim ().split (UTILS.SPACECHAR);
      // a container for the first word on the last line ...
      // ... of text on the nullterm screen
      lastline = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, lastline]);
      lastline = UTILS.Link (UTILS.Filter, [UTILS.SPACECHAR, lastline]);
      // store the first word of the last line of text ...
      // ... on the nullterm screen in its designated container
      command  = lastline [0];
      // is the command (first word of the last line) mapped to a process?
      if (PROCESS [command] !== undefined) { 
        // if so, update the server command history and ...
        SERVER.history.push (INITDATA [command][identity]);

        if (scrollLockActive) { SERVER.ekkoe.scrollLock = false; }

        // make a blank line the last line -- new line
        UTILS.Link (EKKOE.Action.ArrowDown, [{}], SERVER.ekkoe);

        if (scrollLockActive) { SERVER.ekkoe.scrollLock = true; }

        // if the given command is not an exception, destroy nullterm
        if (SERVER.exceptional [command] === undefined) {
          UTILS.Link (NULLTERM.Destroy, [], SERVER);
        }
        // finally, run the process specified by the given command
        UTILS.Link (INITIATE [command], [], PROCESS [command]);
      }
      // well, this bit makes sure that the user need not ...
      // ... press [ENTER] for the command to begin running;
      // also, this bit should only run while the suite is in use
      if (SERVER.ekkoe.exists) {
        UTILS.Link (UTILS.Animate, [Interpreter], window);
      }
      
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    jsengine.Materialize = Materialize;

    return Object.create (jsengine);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  JSEngine = utils.Link (MakeJSEngineName, [utils], jsenginespace);

  return JSEngine;
}