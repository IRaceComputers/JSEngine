/****************************************************************
    Bootstrapper initiates the ASH suite when the window is ready for use.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/***********************************************************************************
* Well, we want to bootstrap the suite iff everything has been loaded ...
* ... it is not going to be _that_ great if it bootstraps prematurely.
/***********************************************************************************/
let bs = Object.create (null);

bs ["bubble"] = false;
bs ["event"]  = "DOMContentLoaded";
bs [bs.event] = Bootstrapper.bind (bs);

window.addEventListener (bs.event, bs [bs.event], bs.bubble);

/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/****
* the bootstrapping function ...
**/
function Bootstrapper () {
  "use strict";

  let that = this;
  let _    = null;
  let __   = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  let UTILS     = MakeUtilityNameSpace ();
  let ___       = UTILS.Link;
  let ____      = UTILS.MapKeyValue;
  let loader    = Object.create (_);
  let info      = Object.create (_);
  let LOADER    = ___ (MakeLoaderNameSpace, [UTILS]);
  let ID        = "begin";
  let FSTABLE   = "/sys/doc/filerecords";
  let INIT      = __;
  let APP       = __;
  let PROCESS   = __;
  let DIRECTORY = __;

  ___ (UTILS.RemoveHandlerFor, [that.event, UTILS.WIN.SYS, that.bubble], that);
  ___ (____, [info, "fstable", FSTABLE]);
  ___ (____, [info, "id", ID]);
  ___ (LOADER.Create, [info], loader);

  INIT      = ___ (LOADER.Import, [LOADER.INITIATE]);
  APP       = ___ (LOADER.Import, [LOADER.APP]);
  PROCESS   = ___ (LOADER.Import, [LOADER.PROCESS]);
  DIRECTORY = APP [2];

  ___ (LOADER.Enable, [APP [1]]);
  ___ (LOADER.Enable, [APP [2]]);
  ___ (LOADER.Enable, [APP [3]]);
  ___ (LOADER.Enable, [APP [6]]);
  ___ (LOADER.Enable, [APP [8]]);
  ___ (LOADER.Enable, [APP [9]]);
  ___ (LOADER.Enable, [APP [10]]);
  ___ (LOADER.Enable, [APP [11]]);
  ___ (LOADER.Enable, [APP [12]]);
  ___ (LOADER.Enable, [APP [13]]);
  ___ (LOADER.Enable, [APP [14]]);

  ___ (INIT [DIRECTORY], _, PROCESS [DIRECTORY]);
/*
  let INT = ___ (LOADER.Import, [LOADER.INTEGER]);
  let m = {};
  let n = {};

  let o = {};

  ___ (INT.SetBase, ["2"], m);
  ___ (INT.Create, [{"value": "0111111111111111111111111111111111111111111111111111111111111111"}], m);
  ___ (UTILS.WIN.CNSL.Log, [["[m] Base 10:", ___ (INT.ToBase, ["10"], m)]], UTILS.WIN.SYS);

  ___ (INT.SetBase, ["2"], n);
  ___ (INT.Create, [{"value": "1111111111111111111111111111111111111111111111111111111111111110"}], n);
  ___ (UTILS.WIN.CNSL.Log, [["[n] Base 10:", ___ (INT.ToBase, ["10"], n)]], UTILS.WIN.SYS);
/*
  ___ (INT.SetBase, ["16"], n);
  ___ (INT.Create, [{"value": "10"}], n);

  o = ___ (INT.Plus, [m], n);
  ___ (INT.SetBase, ["10"], o);

  ___ (UTILS.WIN.CNSL.Log, [["m =", ___ (INT.ToString, _, m), "(base 9)"]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["n =", ___ (INT.ToString, _, n), "(base 16)"]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["o", "=", "n", "+", "m"]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["o", "=", ___ (INT.ToString, _, o), "(base 10)"]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 2:", ___ (INT.ToBase, ["2"], n), ___ (INT.ToBase, ["2"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 3:", ___ (INT.ToBase, ["3"], n), ___ (INT.ToBase, ["3"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 4:", ___ (INT.ToBase, ["4"], n), ___ (INT.ToBase, ["4"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 5:", ___ (INT.ToBase, ["5"], n), ___ (INT.ToBase, ["5"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 6:", ___ (INT.ToBase, ["6"], n), ___ (INT.ToBase, ["6"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 7:", ___ (INT.ToBase, ["7"], n), ___ (INT.ToBase, ["7"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 8:", ___ (INT.ToBase, ["8"], n), ___ (INT.ToBase, ["8"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 9:", ___ (INT.ToBase, ["9"], n), ___ (INT.ToBase, ["9"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 10:", ___ (INT.ToBase, ["10"], n), ___ (INT.ToBase, ["10"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 11:", ___ (INT.ToBase, ["11"], n), ___ (INT.ToBase, ["11"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 12:", ___ (INT.ToBase, ["12"], n), ___ (INT.ToBase, ["12"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 13:", ___ (INT.ToBase, ["13"], n), ___ (INT.ToBase, ["13"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 14:", ___ (INT.ToBase, ["14"], n), ___ (INT.ToBase, ["14"], m)]], UTILS.WIN.SYS);
  ___ (UTILS.WIN.CNSL.Log, [["[n m] Base 15:", ___ (INT.ToBase, ["15"], n), ___ (INT.ToBase, ["15"], m)]], UTILS.WIN.SYS);
*/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  return __;
}