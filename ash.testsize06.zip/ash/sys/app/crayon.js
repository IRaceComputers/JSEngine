/****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeCrayonNameSpace (loader) {
  "use strict";

  let crayonspace = Object.create (null);

  function MakeCrayonName (Loader=undefined) {
    let crayon = this;
    let _      = null;
    let __     = undefined;
    let ___    = __;
    let ____   = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let BGCOLOR     = __;
    let BROWSER     = __;
    let COVER       = __;
    let PAPER       = __;
    let EXIT        = __;
    let FGCOLOR     = __;
    let FILE        = __;
    let FILEMANAGER = __;
    let GEOMETER    = __;
    let GRID        = __;
    let LOADER      = __;
    let PAINTER     = __;
    let SCREEN      = __;
    let STACK       = __;
    let UTILS       = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=__) {
      let that = this;

      BGCOLOR = info.bgcolor;
      EXIT    = info.escape;
      FGCOLOR = info.fgcolor;

      ___ (____, [that, "id", info.id]);
      ___ (____, [that, "paper", Object.create (_)]);
      ___ (PAPER.Create, [info], that.paper);
      ___ (GEOMETER.Create, [info], that);
      ___ (Customize, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatcrayon     = this;
      let that           = thatcrayon.paper;
      let commandHandler = Object.create (_);
      let ENTER          = UTILS.KBD.KEY.ENTER;
      let oldFunction    = ___ (PAPER.GetKeyFunction, [ENTER, UTILS.PRESS], that);
      let newFunction    = ___ (MakeNewEnter, [oldFunction], thatcrayon);

      ___ (____, [commandHandler, "command", ".create."]);
      ___ (____, [commandHandler, "handler", Make.bind (thatcrayon)]);
      ___ (PAPER.SetKeyFunction, [ENTER, newFunction, UTILS.PRESS], that); 
      ___ (BROWSER.Create, [commandHandler], thatcrayon);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=__) {
      let thatcrayon = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that    = this;
        let Command = __;
        let opline  = __;

        FILE    = ___ (FILEMANAGER.GetFile, [UTILS.WHOLE]);
        opline  = FILE [FILE.length - 1].trim (). split (UTILS.KBD.KEY.WHITESPACE);
        opline  = ___ (UTILS.Filter, [UTILS.BLANKCHAR, opline]);
        opline  = ___ (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, opline]);
        Command = ___ (BROWSER.Recorded, [opline[0]], thatcrayon);

        if (Command !== __) { ___ (Command, [FILE, UTILS.KBD.KEY.WHITESPACE]); }
        else { ___ (oldEnter, _, that); }

        return __;
      }

      return Enter;
    };
 
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Make () {
      let thatcrayon = this;
      let TYPE       = 0;
      let components = __;
      let structures = __;
      let type       = __;
      let Structure  = __;

      structures = ___ (GEOMETER.CloneStructures, [FILE], thatcrayon);
      structures = ___ (GEOMETER.CleanStructures, [structures]);
      BGCOLOR    = ___ (PAPER.GetBgColor);

      ___ (GEOMETER.SetBgColor, [BGCOLOR]);
      ___ (GEOMETER.ClearBackground, _, thatcrayon);

      for (let i =  0; i < structures.length; i ++) {
        components = structures [i];
        type       = components [TYPE];
        Structure  = ___ (GEOMETER.GetStructure, [type]);

        if (Structure !== __) { ___ (Structure, [components], thatcrayon); }
      }

      ___ (PAPER.UnsetRequireRewrite, _, thatcrayon.paper);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;
      ___ (PAPER.Destroy, _, that);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify (loaderObj=__) {
      let that = this;

      LOADER  = Loader;
      UTILS   = LOADER.UTILS;
      ___     = UTILS.Link;
      ____    = UTILS.MapKeyValue;

      BROWSER     = ___ (LOADER.Import, [LOADER.BROWSER]);
      COVER       = ___ (LOADER.Import, [LOADER.COVER]);
      FILEMANAGER = ___ (LOADER.Import, [LOADER.FILEMANAGER]);
      GEOMETER    = ___ (LOADER.Import, [LOADER.GEOMETER]);
      GRID        = ___ (LOADER.Import, [LOADER.GRID]);
      PAINTER     = ___ (LOADER.Import, [LOADER.PAINTER]);
      PAPER       = ___ (LOADER.Import, [LOADER.PAPER]);
      SCREEN      = ___ (LOADER.Import, [LOADER.SCREEN]);
      STACK       = ___ (LOADER.Import, [LOADER.STACK]);

      ___ (____, [crayon, "Create", Create]);
      ___ (____, [crayon, "Destroy", Destroy]);

      return Object.create (that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    return Loader.UTILS.Link (Objectify, [Loader], crayon);
  }

  return loader.UTILS.Link (MakeCrayonName, [loader], crayonspace);
}