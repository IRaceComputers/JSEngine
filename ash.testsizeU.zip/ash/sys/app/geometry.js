/****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeGeometryNameSpace (utils, decimal, browser) {
  "use strict";

  let geometryspace = Object.create (null);
  let Geometry      = undefined;

  function MakeGeometryName (Utils=undefined, Decimal=undefined, Browser=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let geometry    = Object.create (null);

    let BGCOLOR     = undefined;
    let BROWSER     = undefined;
    let COVER       = undefined;
    let DECIMAL     = undefined;
    let EKKOE       = undefined;
    let EXIT        = undefined;
    let FGCOLOR     = undefined;
    let FILE        = undefined;
    let FILEMANAGER = undefined;
    let FONT        = undefined;
    let GEOMETER    = undefined;
    let GRID        = undefined;
    let PAINTER     = undefined;
    let PRESS       = undefined;
    let RELEASE     = undefined;
    let SCREEN      = undefined;
    let STACK       = undefined;
    let UTILS       = undefined;
    let WHOLE       = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=undefined) {
      let that = this;

      BGCOLOR     = info.bgcolor;
      GRID        = info.grid;
      EKKOE       = info.edword;
      EXIT        = info.escape;
      FGCOLOR     = info.fgcolor;
      FILEMANAGER = info.filemanager;
      FONT        = info.font || FONT;
      PAINTER     = info.painter;
      COVER       = info.cover;
      GEOMETER    = info.geometer;
      SCREEN      = info.screen;
      STACK       = info.stack;

      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
      UTILS.Link (UTILS.MapKeyValue, [that, "edword", Object.create (null)]);
      UTILS.Link (EKKOE.Create, [info], that.edword);
      UTILS.Link (GEOMETER.Create, [info], that);
      UTILS.Link (Customize, null, that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatgeometry   = this;
      let that           = thatgeometry.edword;
      let commandHandler = Object.create (null);
      let ENTER          = UTILS.KBD.KEY.ENTER;
      let oldFunction    = UTILS.Link (EKKOE.GetKeyFunction, [ENTER, PRESS], that);
      let newFunction    = UTILS.Link (MakeNewEnter, [oldFunction], thatgeometry);

      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "command", ".create."]);
      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "handler", Make.bind (thatgeometry)]);
      UTILS.Link (EKKOE.SetKeyFunction, [ENTER, newFunction, PRESS], that); 
      UTILS.Link (BROWSER.Create, [commandHandler], thatgeometry);

      return undefined;
    } 

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=undefined) {
      let thatgeometry = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that    = this;
        let Command = undefined;
        let opline  = undefined;

        FILE    = UTILS.Link (FILEMANAGER.GetFile, [WHOLE]);
        opline  = FILE [FILE.length - 1].trim (). split (UTILS.KBD.KEY.WHITESPACE);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, opline]);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, opline]);
        Command = UTILS.Link (BROWSER.Recorded, [opline[0]], thatgeometry);

        if (Command !== undefined) { UTILS.Link (Command, [FILE, UTILS.KBD.KEY.WHITESPACE]); }
        else { UTILS.Link (oldEnter, null, that); }

        return undefined;
      }

      return Enter;
    };
 
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Make () {
      let thatgeometry = this;
      let TYPE         = 0;
      let components   = undefined;
      let structures   = undefined;
      let type         = undefined;
      let Structure    = undefined;

      structures = UTILS.Link (GEOMETER.CloneStructures, [FILE], thatgeometry);
      structures = UTILS.Link (GEOMETER.CleanStructures, [structures]);

      UTILS.Link (GEOMETER.ClearBackground, null, thatgeometry);

      for (let i =  0; i < structures.length; i ++) {
        components = structures [i];
        type       = components [TYPE];
        Structure  = UTILS.Link (GEOMETER.GetStructure, [type]);

        if (Structure !== undefined) {
          UTILS.Link (Structure, [components], thatgeometry);
        }
      }

      thatgeometry.edword.requireRewrite = false;

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      UTILS.Link (EKKOE.Destroy, null, that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;

      BROWSER              = Browser;
      DECIMAL              = Decimal;
      FONT                 = "15px Monospace";
      PRESS                = 0;
      RELEASE              = 1;
      UTILS                = Utils;
      WHOLE                = -1;
      geometry.Create      = Create;
      geometry.Destroy     = Destroy;

      return Object.create (that);
    }

    return Utils.Link (Objectify, null, geometry);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Geometry = utils.Link (MakeGeometryName, [utils, decimal, browser], geometryspace);

  return Geometry;
}
