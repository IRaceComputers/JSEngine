function MakeServerNameSpace () {
  "use strict";

  var fs        = require ("fs");
  var http      = require ("http");

  var reddata     = undefined;
  var IP_ADDRESS  = "127.0.0.1",
      PORT_NUMBER = 9000,
      READABLE    = {
        "File" : {
          "/"                            : {"Content-Type":"text/html"},
          "/favicon.ico"                 : {"Content-Type":"image/ico"},
          "/sys/priv/style.ngn.css"      : {"Content-Type":"text/css"},
          "/sys/lib/utility.ngn"         : {"Content-Type":"text/javascript"},
          "/sys/lib/stack.ngn"           : {"Content-Type":"text/javascript"},
          "/sys/lib/paint.ngn"           : {"Content-Type":"text/javascript"},
          "/sys/lib/grid.ngn"            : {"Content-Type":"text/javascript"},
          "/sys/lib/graphics.process.ngn": {"Content-Type":"text/javascript"},
          "/sys/lib/big.decimal.ngn"     : {"Content-Type":"text/javascript"},
          "/sys/lib/big.float.ngn"       : {"Content-Type":"text/javascript"},
          "/sys/lib/browser.ngn"         : {"Content-Type":"text/javascript"},
          "/sys/lib/file.ngn"            : {"Content-Type":"text/javascript"},
          "/sys/lib/plot.ngn"            : {"Content-Type":"text/javascript"},
          "/sys/proc/ekkoe.ngn"          : {"Content-Type":"text/javascript"},
          "/sys/proc/logic.ngn"          : {"Content-Type":"text/javascript"},
          "/sys/proc/geometry.ngn"       : {"Content-Type":"text/javascript"},
          "/sys/proc/scramble.ngn"       : {"Content-Type":"text/javascript"},
          "/sys/proc/media.ngn"          : {"Content-Type":"text/javascript"},
          "/sys/proc/search.ngn"         : {"Content-Type":"text/javascript"},
          "/sys/init/javascript.ngn"     : {"Content-Type":"text/javascript"},
          "/sys/init/process.ngn"        : {"Content-Type":"text/javascript"},
          "/sys/init/begin.ngn"          : {"Content-Type":"text/javascript"}
        },
        "Directory" : {
          "/files"    : true,
          "/music"    : true,
          "/video"    : true,
          "/sys/doc"  : true
        }
      };

  var server = http.createServer (Materialize);

  console.log ("Serving HTTP on", IP_ADDRESS + ":" +  PORT_NUMBER, "...");

  /************************************************************************/
  function Materialize (rikwest, rizalt) {
    var file = Object.create (null);

    file.DATAPOST     = undefined;
    file.INCOMINGDATA = "data";
    file.DATAEND      = "end";
    file.GET          = "GET";
    file.POST         = "POST";

    console.log ("\n",rikwest.method, rikwest.url);

    switch (rikwest.method) {
      case file.GET:
        return GETResource.call (rikwest, rizalt);
      break;
      case file.POST:
        file.DATAPOST = "";
        rikwest.on (file.INCOMINGDATA, AcceptData.bind (file));
        rikwest.on (file.DATAEND, WriteData.bind (file));
      break;
    }

    function AcceptData (stream) {
      var self = this;
      self.DATAPOST = self.DATAPOST + stream;
      return undefined;
    }

    function WriteData (stream) {
      var self = this;
      OverwriteResource (self.DATAPOST);
      return undefined;
    }

     return undefined;
    /*****************/
  }


  function GETResource (rizalt) {
    /******************************************************************/
    var self       = this,
        file       = Object.create (null);

    file.DIREKTORY  = undefined;
    file.DIDNOTREAD = undefined;

    if (READABLE.File[self.url]) { ReadResource.call (self, rizalt); }
    else {
      file.DIDNOTREAD = true;

      for (file.DIREKTORY in READABLE.Directory) {
        if (CanAccess.call (self, file.DIREKTORY)) {
          if (MediaResource.call (self)) { GetMediaResource.call (self, rizalt); }
          else { GetTextResource.call (self, rizalt); }
          file.DIDNOTREAD = false;
        }
        else { /* HANDLE READING DIRECTORY CONTENTS HERE */ }
      }

      if (file.DIDNOTREAD) { GetFNF.call (self, rizalt); }
    }
    /******************************************************************/

    return undefined;
  }

  function CanAccess (directory) {
    var self = this,
        response = false;

    if ((self.url.indexOf (directory) === 0) && (self.url !== directory)) { response = true; }

    return response;
  }

  function MediaResource () {
    var self  = this,
        file = Object.create (null);

    file.MUSIC    = "music";
    file.VIDEO    = "video";
    file.RESPONSE = false;

    if (self.url.indexOf (file.MUSIC) !== -1 || self.url.indexOf (file.VIDEO)) { file.RESPONSE = true; }

    return file.RESPONSE;
  }


  /***************************************************************************/
  /***************************************************************************/
  function ReadResource (rizalt) {
    var self = this,
        file = Object.create (null);

    file.BLANK    = "";
    file.SITE     = ".";
    file.ROOT     = "/";
    file.BASE     = "index.html";
    file.STATUS   = 200;
    file.CONTENTS = undefined;
    file.STREAM   = undefined;

    if (self.url === file.ROOT) { file.CONTENTS = file.BASE; }
    else                        { file.CONTENTS = file.BLANK; }

    file.CONTENTS = file.SITE + self.url + file.CONTENTS;
    file.STREAM = fs.createReadStream (file.CONTENTS);

    rizalt.writeHead (file.STATUS, READABLE.File[self.url]);
    file.STREAM.pipe (rizalt);

    console.log ("GOT", file.CONTENTS);

    return undefined;
  }

  /***************************************************************************/
  /******************************************************/
  function GetMediaResource (rizalt) {
    var self    = this,
        file    = Object.create (null);

        file.SITE      = ".";
        file.CONTENTS  = file.SITE + self.url,
        file.STREAM    = fs.createReadStream (file.CONTENTS);

    rizalt.writeHead (200, {"Content-Type":"video/mp4"});
    file.STREAM.pipe (rizalt);

    console.log ("GOT", file.CONTENTS);

    return undefined;
  }

  /******************************************************/
  /***************************************************************************/
  function GetFNF (rizalt) {
   var self = this;

    rizalt.writeHead (404, {"Content-Type":"text/html"});
    rizalt.write ("File '" + self.url + "' not found. Try a different name.");
    rizalt.end ();

    console.log ("GOT", "404");

    return undefined;
  }

  /***************************************************************************/
  /********************************************************/
  function GetTextResource (rizalt) {
    var self    = this,
        file    = Object.create (null);

    file.SITE     = ".";
    file.CONTENTS = file.SITE + self.url,
    file.STREAM   = fs.createReadStream (file.CONTENTS);

    rizalt.writeHead (200, {"Content-Type":"text/plain"});
    file.STREAM.pipe (rizalt);

    console.log ("GOT", file.CONTENTS);

    return undefined;
  }

  /********************************************************/
  /*************************************************/
  function OverwriteResource (data) {
    var dataArr  = data.split ("\n");
    var filename = dataArr.pop ().trim ();

    if (filename === "" || filename === ".") {
      console.log ("[!!] Filename \"" + filename + "\" is invalid.");
    }
    else { fs.writeFileSync (filename, dataArr.join("\n")); }

    console.log ("POSTED\n", data);

    return undefined;
  }
  /*************************************************/

  server.listen (PORT_NUMBER, IP_ADDRESS);

  return undefined;
}

/***************************************************************************************************/
/***************************************************************************************************/

var SERVERSPACE = Object.create (null);

MakeServerNameSpace.call (SERVERSPACE);

/***************************************************************************************************/
/***************************************************************************************************/
