/****************************************************************
    Process holds and combines the default data with init 
    functions of processes, which prepares each process to be 
    called as an application in the ASH suite through a command.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeProcessNameSpace (utils) {
  "use strict";

  let processspace = Object.create (null);
  let Process      = undefined;

  function MakeProcessName (Utils=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let process = Object.create (null);

    /***********************************************************************************
    * All The Necessary State Variables and Konstants
    /***********************************************************************************/ 
    // Classes
    let BROWSER     = undefined;
    let DECIMAL     = undefined;
    let EDWORD       = undefined;
    let FILEMANAGER = undefined;
    let GEOMETER    = undefined;
    let GEOMETRY    = undefined;
    let GRID        = undefined;
    let INTEGER     = undefined;
    let NULLTERM    = undefined;
    let PAINTER     = undefined;
    let STACK       = undefined;
    let UTILS       = Utils;
    let VIEWPORT    = undefined;
    // Data-Storage Objects
    let APP         = undefined;
    let COVER       = undefined;
    let DATA        = undefined;
    let FILERECORDS = undefined;
    let INITDATA    = undefined;
    let INITIATE    = undefined;
    let PROCESS     = undefined;
    let SCREEN      = undefined;
    let SERVER      = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=undefined) {
      let that     = this;
      let listed   = info.include;

      FILERECORDS = info.fstable;

      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
      UTILS.Link (UTILS.MapKeyValue, [info, "cover", "#cover"]);
      UTILS.Link (DefineDefaultState, [info]);

      if (listed !== undefined && listed.length > 0) {
        let processName = 0;
        let processID   = undefined;

        UTILS.Link (UTILS.MapKeyValue, [SERVER, "exceptional", Object.create (null)]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [2]], "initdata", INITDATA]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [2]], "initiate", INITIATE]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [2]], "process", PROCESS]);
        UTILS.Link (FILEMANAGER.Create);

        while (processName < listed.length) {
          processID = listed [processName];
          UTILS.Link (Include, [APP [processID]]);
          processName = processName + 1;
        }

        if (PROCESS [APP [2]] !== undefined) {
          UTILS.Link (INITIATE [APP [2]], null, PROCESS [APP [2]]);
        }
      }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefineDefaultState (info=undefined) {
      /***********************************************************************************
      * Object Template Classes
      /**********************************************************************************/
      /*
      * LIBRARY AND PROCESS OBJECTS
      **/
      INTEGER     = UTILS.Link (MakeIntegerNameSpace    , [UTILS]);
      DECIMAL     = UTILS.Link (MakeDecimalNameSpace    , [UTILS, INTEGER]);
      BROWSER     = UTILS.Link (MakeBrowserNameSpace    , [UTILS]);
      GRID        = UTILS.Link (MakeGridNameSpace       , [UTILS]);
      PAINTER     = UTILS.Link (MakePainterNameSpace    , [UTILS]);
      GEOMETER    = UTILS.Link (MakeGeometerNameSpace   , [UTILS, DECIMAL]);
      STACK       = UTILS.Link (MakeStackNameSpace      , [UTILS]);
      FILEMANAGER = UTILS.Link (MakeFileManagerNameSpace, [UTILS, STACK, FILERECORDS]);
      VIEWPORT    = UTILS.Link (MakeViewPortNameSpace   , [UTILS]);
      /*
      * APPLICATION OBJECTS
      **/
      EDWORD   = UTILS.Link (MakeEdwordNameSpace  , [UTILS, VIEWPORT]);
      GEOMETRY = UTILS.Link (MakeGeometryNameSpace, [UTILS, DECIMAL, BROWSER]); 
      NULLTERM = UTILS.Link (MakeNullTermNameSpace, [UTILS]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      /***********************************************************************************
      * Data-Storage Objects
      /**********************************************************************************/
      APP      = Object.create (null);
      DATA     = Object.create (null);
      INITDATA = Object.create (null);
      INITIATE = Object.create (null);
      PROCESS  = Object.create (null);
      SERVER   = Object.create (null);
      SCREEN   = Object.create (null);
      COVER    = UTILS.WIN.DOC.querySelector (info.cover);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      UTILS.Link (UTILS.MapKeyValue, [APP, 1, "license"]) ;
      UTILS.Link (UTILS.MapKeyValue, [APP, 2, "nullterm"]);
      UTILS.Link (UTILS.MapKeyValue, [APP, 3, "edword"]);
      UTILS.Link (UTILS.MapKeyValue, [APP, 6, ".history."]);
      UTILS.Link (UTILS.MapKeyValue, [APP, 8, "help"]);
      UTILS.Link (UTILS.MapKeyValue, [APP, 9, "geometry"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,10, "explaingeometry"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,11, "explainedword"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,12, "explainnullterm"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,13, "explainlicense"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,14, "explainhelp"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,15, ".exit."]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      UTILS.Link (UTILS.MapKeyValue, [DATA, 0, "bgcolor"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 1, "fgcolor"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 2, "font"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 3, "filemanager"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 4, "painter"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 5, "cover"]);

      UTILS.Link (UTILS.MapKeyValue, [DATA, 6, "screen"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 7, "stack"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 8, "id"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 9, "/sys/doc/"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA,10, "height"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA,11, "width"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA,12, "escape"]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      /**********************************************************************
      * The Screen Dimensions
      /**********************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [SCREEN, DATA [10], UTILS.WIN.SYS.innerHeight - 20]);
      UTILS.Link (UTILS.MapKeyValue, [SCREEN, DATA [11], UTILS.WIN.SYS.innerWidth  - 30]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      UTILS.Link (UTILS.MapKeyValue, [INITDATA, DATA [0], "#000030FF"]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, DATA [1], "#00BAFFFF"]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, DATA [2], "15px Monospace"]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      /***********************************************************************************
        * edword init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [3], Object.create (null)]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [0], INITDATA [DATA [0]]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [1], INITDATA [DATA [1]]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [2], INITDATA [DATA [2]]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [3], FILEMANAGER]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [4], PAINTER]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [5], COVER]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [7], STACK]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [8], APP [3]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], APP [8], DATA [9] + APP [3]]);

      /***********************************************************************************
      * nullterm init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [2], Object.create (INITDATA [APP [3]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [2]], DATA [8], APP [2]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [2]], APP [8], DATA [9] + APP [2]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [2]], APP [3], EDWORD]);

      /***********************************************************************************
      * license init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [1], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [1]], DATA [8], APP [1]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [1]], APP [8], DATA [9] + APP [1]]);

      /***********************************************************************************
      * help init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [8], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [8]], DATA [8], APP [8]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [8]], APP [8], DATA [9] + APP [8]]);

      /***********************************************************************************
      * geometry init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [9], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], "unit", Object.create (null)]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], "skew", Object.create (null)]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]]["skew"], "x", 0]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]]["skew"], "y", 0]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]]["unit"], "x", 10]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]]["unit"], "y", 10]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], DATA [8], APP [9]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], APP [8], DATA [9] + APP [9]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], "grid", GRID]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], "geometer", GEOMETER]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], "browser", BROWSER]);

      /***********************************************************************************
      * explaingeometry init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [10], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [10]], DATA [8], APP [10]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [10]], APP [8], DATA [9] + APP [10]]);

      /***********************************************************************************
      * explainedword init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [11], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [11]], DATA [8], APP [11]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [11]], APP [8], DATA [9] + APP [11]]);

      /***********************************************************************************
      * explainnullterm init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [12], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [12]], DATA [8], APP [12]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [12]], APP [8], DATA [9] + APP [12]]);

      /***********************************************************************************
      * explainlicense init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [13], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [13]], DATA [8], APP [13]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [13]], APP [8], DATA [9] + APP [13]]);

      /***********************************************************************************
      * explainhelp init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [14], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [14]], DATA [8], APP [14]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [14]], APP [8], DATA [9] + APP [14]]);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Include (processName=undefined) {
      let tmpObj     = Object.create (null);
      let Launcher   = undefined;
      let Terminator = undefined;

      if (processName === APP [2]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA [APP [2]]]);

        UTILS.Link (UTILS.MapKeyValue, [SERVER, "history", new Array ()]);
        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [2], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [2], Launcher]);
      }

      if (processName === APP [15]) {
        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [15], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [15], EscapeNullTerm]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [15], INITDATA [APP [2]]]);
      }

      if (processName === APP [6]) {
        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [6], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [6], NULLTERM.History]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [6], INITDATA [APP [2]]]);
        UTILS.Link (UTILS.MapKeyValue, [SERVER.exceptional, APP [6], true]);
      }

      if (processName === APP [3]) {
        Launcher   = UTILS.Link (BeginProcess, [EDWORD.Create, INITDATA [APP [3]]]);
        Terminator = UTILS.Link (EndProcess, [tmpObj, EDWORD])

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [3], Object.create (null)]);
        UTILS.Link (UTILS.MapKeyValue, [tmpObj, APP [3], PROCESS [APP [3]]]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [3], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [12], Terminator]);
      }

      if (processName === APP [9]) {
        Launcher   = UTILS.Link (BeginProcess, [GEOMETRY.Create, INITDATA.geometry]);
        Terminator = UTILS.Link (EndProcess, [PROCESS.geometry, GEOMETRY]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [9], Object.create (null)]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [9], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], DATA [12], Terminator]);
      }

      if (processName === APP [8]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA.help]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [8], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [tmpObj, APP [3], PROCESS [APP [8]]]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [8], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [8]], DATA [12], undefined]);
      }

      if (processName === APP [1]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA.license]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [1], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [tmpObj, APP [3], PROCESS [APP [1]]]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [1], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [1]], DATA [12], undefined]);
      }

      if (processName === APP [14]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA.explainhelp]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [14], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [tmpObj, APP [3], PROCESS [APP [14]]]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [14], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [14]], DATA [12], undefined]);
      }

      if (processName === APP [13]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA.explainlicense]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [13], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [tmpObj, APP [3], PROCESS [APP [13]]]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [13], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [13]], DATA [12], undefined]);
      }

      if (processName === APP [12]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA.explainnullterm]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [12], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [tmpObj, APP [3], PROCESS [APP [12]]]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [12], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [12]], DATA [12], undefined]);
      }

      if (processName === APP [11]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA.explainedword]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [11], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [tmpObj, APP [3], PROCESS [APP [11]]]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [11], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [11]], DATA [12], undefined]);
      }

      if (processName === APP [10]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA.explaingeometry]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [10], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [tmpObj, APP [3], PROCESS [APP [10]]]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [10], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [10]], DATA [12], undefined]);
      }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function BeginProcess (CreateProcess=undefined, ProcessData=undefined) {

      function InitProcess (newfile=undefined) {
        let that    = this;
        let oldfile = undefined;

        if (newfile !== oldfile) {
          oldfile = ProcessData [APP [8]];
          UTILS.Link (UTILS.MapKeyValue, [ProcessData, APP [8], newfile]);
        }

        UTILS.Link (CreateProcess, [ProcessData], that);

        if (oldfile !== undefined) {
          UTILS.Link (UTILS.MapKeyValue, [ProcessData, APP [8], oldfile]);
        }

        return undefined;
      }

      return InitProcess;
    }  

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function EndProcess (ProcessName=undefined, ProcessFunctions=undefined) {

      function InitEnd () {
        let that        = this;
        let EscapeRoute = [ProcessName, ProcessFunctions];

        return UTILS.Link (EscapeUsing, EscapeRoute, that);
      }

      return InitEnd;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function EscapeUsing (ProcessName=undefined, ProcessFunctions=undefined) { 
      let that          = this;
      let StartNullTerm = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA.nullterm]);

      UTILS.Link (ProcessFunctions.Destroy, null, that);
      UTILS.Link (StartNullTerm, null, SERVER);
      UTILS.Link (NULLTERM.CommandRecognition, null, SERVER);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    process.Create = Create;

    return Object.create (process);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Process = utils.Link (MakeProcessName, [utils], processspace);

  return Process;
}