/****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeCrayonNameSpace (utils, decimal, browser) {
  "use strict";

  let crayonspace = Object.create (null);
  let Crayon      = undefined;

  function MakeCrayonName (Utils=undefined, Decimal=undefined, Browser=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let crayon      = Object.create (null);

    let BGCOLOR     = undefined;
    let BROWSER     = undefined;
    let COVER       = undefined;
    let DECIMAL     = undefined;
    let PAPER      = undefined;
    let EXIT        = undefined;
    let FGCOLOR     = undefined;
    let FILE        = undefined;
    let FILEMANAGER = undefined;
    let GEOMETER    = undefined;
    let GRID        = undefined;
    let PAINTER     = undefined;
    let SCREEN      = undefined;
    let STACK       = undefined;
    let UTILS       = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=undefined) {
      let that = this;

      BGCOLOR     = info.bgcolor;
      GRID        = info.grid;
      PAPER       = info.paper;
      EXIT        = info.escape;
      FGCOLOR     = info.fgcolor;
      FILEMANAGER = info.filemanager;
      PAINTER     = info.painter;
      COVER       = info.cover;
      GEOMETER    = info.geometer;
      SCREEN      = info.screen;
      STACK       = info.stack;

      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
      UTILS.Link (UTILS.MapKeyValue, [that, "paper", Object.create (null)]);
      UTILS.Link (PAPER.Create, [info], that.paper);
      UTILS.Link (GEOMETER.Create, [info], that);
      UTILS.Link (Customize, null, that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatcrayon   = this;
      let that           = thatcrayon.paper;
      let commandHandler = Object.create (null);
      let ENTER          = UTILS.KBD.KEY.ENTER;
      let oldFunction    = UTILS.Link (PAPER.GetKeyFunction, [ENTER, UTILS.PRESS], that);
      let newFunction    = UTILS.Link (MakeNewEnter, [oldFunction], thatcrayon);

      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "command", ".create."]);
      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "handler", Make.bind (thatcrayon)]);
      UTILS.Link (PAPER.SetKeyFunction, [ENTER, newFunction, UTILS.PRESS], that); 
      UTILS.Link (BROWSER.Create, [commandHandler], thatcrayon);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=undefined) {
      let thatcrayon = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that    = this;
        let Command = undefined;
        let opline  = undefined;

        FILE    = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]);
        opline  = FILE [FILE.length - 1].trim (). split (UTILS.KBD.KEY.WHITESPACE);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, opline]);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, opline]);
        Command = UTILS.Link (BROWSER.Recorded, [opline[0]], thatcrayon);

        if (Command !== undefined) { UTILS.Link (Command, [FILE, UTILS.KBD.KEY.WHITESPACE]); }
        else { UTILS.Link (oldEnter, null, that); }

        return undefined;
      }

      return Enter;
    };
 
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Make () {
      let thatcrayon = this;
      let TYPE         = 0;
      let components   = undefined;
      let structures   = undefined;
      let type         = undefined;
      let Structure    = undefined;

      structures = UTILS.Link (GEOMETER.CloneStructures, [FILE], thatcrayon);
      structures = UTILS.Link (GEOMETER.CleanStructures, [structures]);
      BGCOLOR    = UTILS.Link (PAPER.GetBgColor);

      UTILS.Link (GEOMETER.SetBgColor, [BGCOLOR]);
      UTILS.Link (GEOMETER.ClearBackground, null, thatcrayon);

      for (let i =  0; i < structures.length; i ++) {
        components = structures [i];
        type       = components [TYPE];
        Structure  = UTILS.Link (GEOMETER.GetStructure, [type]);

        if (Structure !== undefined) {
          UTILS.Link (Structure, [components], thatcrayon);
        }
      }

      UTILS.Link (UTILS.MapKeyValue, [thatcrayon.paper, "requireRewrite", false]);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      UTILS.Link (PAPER.Destroy, null, that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;

      BROWSER = Browser;
      DECIMAL = Decimal;
      UTILS   = Utils;

      UTILS.Link (UTILS.MapKeyValue, [crayon, "Create", Create]);
      UTILS.Link (UTILS.MapKeyValue, [crayon, "Destroy", Destroy]);

      return Object.create (that);
    }

    return Utils.Link (Objectify, null, crayon);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  Crayon = utils.Link (MakeCrayonName, [utils, decimal, browser], crayonspace);

  return Crayon;
}
