 /****************************************************************
    Loader holds and combines the default data with init 
    functions of processes, which prepares each process to be 
    called through a command as an application in the ASH suite.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeLoaderNameSpace (utils) {
  "use strict";

  let loaderspace = Object.create (null);

  function MakeLoaderName (Utils=undefined) {
    let loader = this;
    let _       = null;
    let __      = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    /***********************************************************************************
    * All The Necessary State Variables and Konstants
    /***********************************************************************************/ 
    // Classes
    let BROWSER     = __;
    let CLIPBOARD   = __;
    let DECIMAL     = __;
    let PAPER       = __;
    let FILEMANAGER = __;
    let GEOMETER    = __;
    let CRAYON      = __;
    let GRID        = __;
    let INTEGER     = __;
    let NULLTERM    = __;
    let PAINTER     = __;
    let STACK       = __;
    let UTILS       = __;
    let VIEWPORT    = __;
    // Data-Storage Objects
    let APP         = __;
    let COVER       = __;
    let DATA        = __;
    let FILERECORDS = __;
    let INITDATA    = __;
    let INITIATE    = __;
    let LOADER      = __;
    let PROCESS     = __;
    let SCREEN      = __;
    let SERVER      = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=__) {
      let that     = this;

      FILERECORDS = info.fstable;

      UTILS.Link (UTILS.MapKeyValue, [info, "cover", "#cover"]);
      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
      UTILS.Link (DefineDefaultState, [info]);
      UTILS.Link (FILEMANAGER.Create);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefineDefaultState (info=__) {
      /***********************************************************************************
      * Data-Storage Objects
      /**********************************************************************************/
      APP      = Object.create (_);
      DATA     = Object.create (_);
      INITDATA = Object.create (_);
      INITIATE = Object.create (_);
      PROCESS  = Object.create (_);
      SERVER   = Object.create (_);
      SCREEN   = Object.create (_);
      COVER    = UTILS.WIN.DOC.querySelector (info.cover);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      UTILS.Link (UTILS.MapKeyValue, [APP, 1, "license"]) ;
      UTILS.Link (UTILS.MapKeyValue, [APP, 2, "nullterm"]);
      UTILS.Link (UTILS.MapKeyValue, [APP, 3, "paper"]);
      UTILS.Link (UTILS.MapKeyValue, [APP, 8, "help"]);
      UTILS.Link (UTILS.MapKeyValue, [APP, 9, "crayon"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,10, "explaincrayon"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,11, "explainpaper"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,12, "explainnullterm"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,13, "explainlicense"]);
      UTILS.Link (UTILS.MapKeyValue, [APP,14, "explainhelp"]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      UTILS.Link (UTILS.MapKeyValue, [DATA, 0, "bgcolor"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 1, "fgcolor"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 2, "font"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 3, "filemanager"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 4, "painter"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 5, "cover"]);

      UTILS.Link (UTILS.MapKeyValue, [DATA, 6, "screen"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 7, "stack"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 8, "id"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA, 9, "/sys/doc/"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA,10, "height"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA,11, "width"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA,12, "escape"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA,13, "clipboard"]);
      UTILS.Link (UTILS.MapKeyValue, [DATA,14, "history"]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      UTILS.Link (UTILS.MapKeyValue, [SERVER, DATA [14], new Array ()]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      /**********************************************************************
      * The Screen Dimensions
      /**********************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [SCREEN, DATA [10], UTILS.WIN.SYS.innerHeight - 20]);
      UTILS.Link (UTILS.MapKeyValue, [SCREEN, DATA [11], UTILS.WIN.SYS.innerWidth  - 30]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      UTILS.Link (UTILS.MapKeyValue, [INITDATA, DATA [0], "#000030FF"]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, DATA [1], "#00BAFFFF"]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, DATA [2], "15px Monospace"]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      /***********************************************************************************
        * paper init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [3], Object.create (_)]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [0], INITDATA [DATA [0]]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [1], INITDATA [DATA [1]]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [2], INITDATA [DATA [2]]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [8], APP [3]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], APP [8], DATA [9] + APP [3]]);

      /***********************************************************************************
      * nullterm init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [2], Object.create (INITDATA [APP [3]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [2]], DATA [8], APP [2]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [2]], APP [8], DATA [9] + APP [2]]);

      /***********************************************************************************
      * license init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [1], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [1]], DATA [8], APP [1]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [1]], APP [8], DATA [9] + APP [1]]);

      /***********************************************************************************
      * help init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [8], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [8]], DATA [8], APP [8]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [8]], APP [8], DATA [9] + APP [8]]);

      /***********************************************************************************
      * crayon init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [9], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], "unit", Object.create (_)]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], "skew", Object.create (_)]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]]["skew"], "x", 0]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]]["skew"], "y", 0]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]]["unit"], "x", 10]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]]["unit"], "y", 10]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], DATA [8], APP [9]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], APP [8], DATA [9] + APP [9]]);

      /***********************************************************************************
      * explaincrayon init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [10], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [10]], DATA [8], APP [10]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [10]], APP [8], DATA [9] + APP [10]]);

      /***********************************************************************************
      * explainpaper init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [11], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [11]], DATA [8], APP [11]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [11]], APP [8], DATA [9] + APP [11]]);

      /***********************************************************************************
      * explainnullterm init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [12], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [12]], DATA [8], APP [12]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [12]], APP [8], DATA [9] + APP [12]]);

      /***********************************************************************************
      * explainlicense init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [13], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [13]], DATA [8], APP [13]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [13]], APP [8], DATA [9] + APP [13]]);

      /***********************************************************************************
      * explainhelp init data
      /**********************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [INITDATA, APP [14], Object.create (INITDATA [APP [2]])]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [14]], DATA [8], APP [14]]);
      UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [14]], APP [8], DATA [9] + APP [14]]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      /**********************************************************************************
      * LIBRARY AND PROCESS OBJECTS
      **/
      INTEGER     = UTILS.Link (MakeIntegerNameSpace    , [LOADER]);
      DECIMAL     = UTILS.Link (MakeDecimalNameSpace    , [LOADER]);
      BROWSER     = UTILS.Link (MakeBrowserNameSpace    , [LOADER]);
      CLIPBOARD   = UTILS.Link (MakeClipboardNameSpace  , [LOADER]);
      GRID        = UTILS.Link (MakeGridNameSpace       , [LOADER]);
      PAINTER     = UTILS.Link (MakePainterNameSpace    , [LOADER]);
      GEOMETER    = UTILS.Link (MakeGeometerNameSpace   , [LOADER]);
      STACK       = UTILS.Link (MakeStackNameSpace      , [LOADER]);
      FILEMANAGER = UTILS.Link (MakeFileManagerNameSpace, [LOADER]); 
      VIEWPORT    = UTILS.Link (MakeViewPortNameSpace   , [LOADER]);
      /**********************************************************************************
      * APPLICATION OBJECTS
      **/
      PAPER    = UTILS.Link (MakePaperNameSpace   , [LOADER]);
      CRAYON   = UTILS.Link (MakeCrayonNameSpace  , [LOADER]);
      NULLTERM = UTILS.Link (MakeNullTermNameSpace, [LOADER]);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Enable (processName=__) {
      let tmpObj     = Object.create (_);
      let Launcher   = __;
      let Terminator = __;

      if (processName === APP [1]) {
        Launcher = UTILS.Link (BeginProcess, [PAPER.Create, INITDATA [APP [1]]]);
        Terminator = UTILS.Link (EndProcess, [PAPER]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [1], Object.create (_)]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [1], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [1]], DATA [12], Terminator]);
      }

      if (processName === APP [2]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA [APP [2]]]);
        Terminator = NULLTERM.Escape;

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [2], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [2], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [2]], DATA [12], Terminator]);
      }

      if (processName === APP [3]) {
        Launcher   = UTILS.Link (BeginProcess, [PAPER.Create, INITDATA [APP [3]]]);
        Terminator = UTILS.Link (EndProcess, [PAPER]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [3], Object.create (_)]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [3], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [3]], DATA [12], Terminator]);
      }

      if (processName === APP [8]) {
        Launcher = UTILS.Link (BeginProcess, [NULLTERM.Create, INITDATA [APP [8]]]);
        Terminator = UTILS.Link (EndProcess, [PAPER]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [8], SERVER]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [8], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [8]], DATA [12], Terminator]);
      }

      if (processName === APP [9]) {
        Launcher   = UTILS.Link (BeginProcess, [CRAYON.Create, INITDATA [APP [9]]]);
        Terminator = UTILS.Link (EndProcess, [CRAYON]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [9], Object.create (_)]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [9], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [9]], DATA [12], Terminator]);
      }

      if (processName === APP [10]) {
        Launcher = UTILS.Link (BeginProcess, [PAPER.Create, INITDATA [APP [10]]]);
        Terminator = UTILS.Link (EndProcess, [PAPER]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [10], Object.create (_)]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [10], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [10]], DATA [12], Terminator]);
      }

      if (processName === APP [11]) {
        Launcher = UTILS.Link (BeginProcess, [PAPER.Create, INITDATA [APP [11]]]);
        Terminator = UTILS.Link (EndProcess, [PAPER]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [11], Object.create (_)]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [11], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [11]], DATA [12], Terminator]);
      }

      if (processName === APP [12]) {
        Launcher = UTILS.Link (BeginProcess, [PAPER.Create, INITDATA [APP [12]]]);
        Terminator = UTILS.Link (EndProcess, [PAPER]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [12], Object.create (_)]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [12], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [12]], DATA [12], Terminator]);
      }

      if (processName === APP [13]) {
        Launcher = UTILS.Link (BeginProcess, [PAPER.Create, INITDATA [APP [13]]]);
        Terminator = UTILS.Link (EndProcess, [PAPER]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [13], Object.create (_)]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [13], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [13]], DATA [12], Terminator]);
      }

      if (processName === APP [14]) {
        Launcher = UTILS.Link (BeginProcess, [PAPER.Create, INITDATA [APP [14]]]);
        Terminator = UTILS.Link (EndProcess, [PAPER]);

        UTILS.Link (UTILS.MapKeyValue, [PROCESS, APP [14], Object.create (_)]);
        UTILS.Link (UTILS.MapKeyValue, [INITIATE, APP [14], Launcher]);
        UTILS.Link (UTILS.MapKeyValue, [INITDATA [APP [14]], DATA [12], Terminator]);
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function BeginProcess (CreateProcess=__, ProcessData=__) {

      function InitProcess (newfile=__) {
        let that    = this;
        let oldfile = __;

        if (newfile !== oldfile) {
          oldfile = ProcessData [APP [8]];
          UTILS.Link (UTILS.MapKeyValue, [ProcessData, APP [8], newfile]);
        }

        UTILS.Link (CreateProcess, [ProcessData], that);

        if (oldfile !== __) {
          UTILS.Link (UTILS.MapKeyValue, [ProcessData, APP [8], oldfile]);
        }

        return __;
      }

      return InitProcess;
    }  

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function EndProcess (ProcessFunctions=__) {

      function InitEnd () {
        let that        = this;
        let EscapeRoute = [ProcessFunctions];

        return UTILS.Link (EscapeUsing, EscapeRoute, that);
      }

      return InitEnd;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function EscapeUsing (ProcessFunctions=__) { 
      let that = this;

      UTILS.Link (UTILS.WIN.CNSL.Clear, _, UTILS.WIN.SYS)
      UTILS.Link (ProcessFunctions.Destroy, _, that);

      if (that.id !== APP [2]) {
        UTILS.Link (NULLTERM.Create, [INITDATA [APP [2]]], SERVER);
        UTILS.Link (NULLTERM.RunCommand, _, SERVER);
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Import (key=__) {
      let that  = this;
      let value = __;

      switch (key) {
        case LOADER.BROWSER    : value = BROWSER; break;
        case LOADER.CLIPBOARD  : value = CLIPBOARD; break;
        case LOADER.DECIMAL    : value = DECIMAL; break;
        case LOADER.PAPER      : value = PAPER; break;
        case LOADER.FILEMANAGER: value = FILEMANAGER; break;
        case LOADER.GEOMETER   : value = GEOMETER; break;
        case LOADER.CRAYON     : value = CRAYON; break;
        case LOADER.GRID       : value = GRID; break;
        case LOADER.INTEGER    : value = INTEGER; break;
        case LOADER.NULLTERM   : value = NULLTERM; break;
        case LOADER.PAINTER    : value = PAINTER; break;
        case LOADER.STACK      : value = STACK; break;
        case LOADER.UTILS      : value = UTILS; break;
        case LOADER.VIEWPORT   : value = VIEWPORT; break;
        case LOADER.COVER      : value = COVER; break;
        case LOADER.INITDATA   : value = INITDATA; break;
        case LOADER.INITIATE   : value = INITIATE; break;
        case LOADER.PROCESS    : value = PROCESS; break;
        case LOADER.SCREEN     : value = SCREEN; break;
        case LOADER.SERVER     : value = SERVER; break;
        case LOADER.FILERECORDS: value = FILERECORDS; break;
        case LOADER.APP        : value = APP; break;
      }

      return value;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;

      LOADER = Object.create (_);
      UTILS  = Utils;

      UTILS.Link (UTILS.MapKeyValue, [LOADER, "Enable", Enable]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "Import", Import]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "UTILS", UTILS]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "BROWSER", "BROWSER"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "CLIPBOARD", "CLIPBOARD"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "DECIMAL", "DECIMAL"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "PAPER", "PAPER"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "FILEMANAGER", "FILEMANAGER"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "GEOMETER", "GEOMETER"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "CRAYON", "CRAYON"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "GRID", "GRID"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "INTEGER", "INTEGER"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "NULLTERM", "NULLTERM"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "PAINTER", "PAINTER"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "STACK", "STACK"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "VIEWPORT", "VIEWPORT"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "COVER", "COVER"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "INITDATA", "INITDATA"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "INITIATE", "INITIATE"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "PROCESS", "PROCESS"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "SERVER", "SERVER"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "SCREEN", "SCREEN"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "APP", "APP"]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "", ""]);
      UTILS.Link (UTILS.MapKeyValue, [LOADER, "", ""]);

      that = Object.create (LOADER);

      UTILS.Link (UTILS.MapKeyValue, [that, "Create", Create]);

      return Object.create (that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    return Utils.Link (Objectify, _, loader);
  }

  return utils.Link (MakeLoaderName, [utils], loaderspace);
}