/****************************************************************
    Bootstrapper initiates the ASH suite when the window is ready for use.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/***********************************************************************************
* Well, we want to bootstrap the suite iff everything has been loaded ...
* ... it is not going to be _that_ great if it bootstraps prematurely.
/***********************************************************************************/
let bs = Object.create (null);

bs ["bubble"] = false;
bs ["event"]  = "DOMContentLoaded";
bs [bs.event] = Bootstrapper.bind (bs);

window.addEventListener (bs.event, bs [bs.event], bs.bubble);

/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/****
* the bootstrapping function ...
**/
function Bootstrapper () {
  "use strict";

  let that = this;
  let _    = null;
  let __   = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  let loader    = Object.create (_);
  let info      = Object.create (_);
  let UTILS     = MakeUtilityNameSpace ();
  let LOADER    = UTILS.Link (MakeLoaderNameSpace, [UTILS]);
  let ID        = "begin";
  let FSTABLE   = "/sys/doc/filerecords";
  let INIT      = __;
  let APP       = __;
  let PROCESS   = __;
  let DIRECTORY = __;

  UTILS.Link (UTILS.RemoveHandlerFor, [that.event, UTILS.WIN.SYS, that.bubble], that);
  UTILS.Link (UTILS.MapKeyValue, [info, "fstable", FSTABLE]);
  UTILS.Link (UTILS.MapKeyValue, [info, "id", ID]);
  UTILS.Link (LOADER.Create, [info], loader);

  INIT      = UTILS.Link (LOADER.Import, [LOADER.INITIATE]);
  APP       = UTILS.Link (LOADER.Import, [LOADER.APP]);
  PROCESS   = UTILS.Link (LOADER.Import, [LOADER.PROCESS]);
  DIRECTORY = APP [2];

  UTILS.Link (LOADER.Enable, [APP [1]]);
  UTILS.Link (LOADER.Enable, [APP [2]]);
  UTILS.Link (LOADER.Enable, [APP [3]]);
  UTILS.Link (LOADER.Enable, [APP [6]]);
  UTILS.Link (LOADER.Enable, [APP [8]]);
  UTILS.Link (LOADER.Enable, [APP [9]]);
  UTILS.Link (LOADER.Enable, [APP [10]]);
  UTILS.Link (LOADER.Enable, [APP [11]]);
  UTILS.Link (LOADER.Enable, [APP [12]]);
  UTILS.Link (LOADER.Enable, [APP [13]]);
  UTILS.Link (LOADER.Enable, [APP [14]]);

  UTILS.Link (INIT [DIRECTORY], _, PROCESS [DIRECTORY]);

  let INT = UTILS.Link (LOADER.Import, [LOADER.INTEGER]);
  let m = {};
  let n = {};
  let o = {};

  UTILS.Link (INT.SetBase, ["9"], m);
  UTILS.Link (INT.Create, [{"value": "0000000000010"}], m);
  UTILS.Link (INT.SetBase, ["16"], n);
  UTILS.Link (INT.Create, [{"value": "10"}], n);

  o = UTILS.Link (INT.Plus, [m], n);
  UTILS.Link (INT.SetBase, ["10"], o);

  UTILS.Link (UTILS.WIN.CNSL.Log, [["m =", UTILS.Link (INT.ToString, _, m), "(base 9)"]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["n =", UTILS.Link (INT.ToString, _, n), "(base 16)"]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["o", "=", "n", "+", "m"]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["o", "=", UTILS.Link (INT.ToString, _, o), "(base 10)"]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 2:", UTILS.Link (INT.ToBase, ["2"], n), UTILS.Link (INT.ToBase, ["2"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 3:", UTILS.Link (INT.ToBase, ["3"], n), UTILS.Link (INT.ToBase, ["3"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 4:", UTILS.Link (INT.ToBase, ["4"], n), UTILS.Link (INT.ToBase, ["4"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 5:", UTILS.Link (INT.ToBase, ["5"], n), UTILS.Link (INT.ToBase, ["5"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 6:", UTILS.Link (INT.ToBase, ["6"], n), UTILS.Link (INT.ToBase, ["6"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 7:", UTILS.Link (INT.ToBase, ["7"], n), UTILS.Link (INT.ToBase, ["7"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 8:", UTILS.Link (INT.ToBase, ["8"], n), UTILS.Link (INT.ToBase, ["8"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 9:", UTILS.Link (INT.ToBase, ["9"], n), UTILS.Link (INT.ToBase, ["9"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 10:", UTILS.Link (INT.ToBase, ["10"], n), UTILS.Link (INT.ToBase, ["10"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 11:", UTILS.Link (INT.ToBase, ["11"], n), UTILS.Link (INT.ToBase, ["11"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 12:", UTILS.Link (INT.ToBase, ["12"], n), UTILS.Link (INT.ToBase, ["12"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 13:", UTILS.Link (INT.ToBase, ["13"], n), UTILS.Link (INT.ToBase, ["13"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 14:", UTILS.Link (INT.ToBase, ["14"], n), UTILS.Link (INT.ToBase, ["14"], m)]], UTILS.WIN.SYS);
  UTILS.Link (UTILS.WIN.CNSL.Log, [["[n m] Base 15:", UTILS.Link (INT.ToBase, ["15"], n), UTILS.Link (INT.ToBase, ["15"], m)]], UTILS.WIN.SYS);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  return __;
}