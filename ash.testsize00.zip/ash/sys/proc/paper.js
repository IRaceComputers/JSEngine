 /****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakePaperNameSpace (loader) {
  "use strict";

  let paperspace = Object.create (null);

  function MakePaperName (Loader=undefined) {
    let paper = this;
    let _     = null;
    let __    = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    /************************************************************************************
    * keyboard functions/objects
    ************************************************************************************/
    let Press     = __;
    let Printable = __;
    let Release   = __;
    let EXIT      = __;
    /************************************************************************************
    * keyboard key state modifiers
    ************************************************************************************/
    let ALTDOWN      = __;
    let ALTGRAPHDOWN = __;
    let CONTROLDOWN  = __;
    let INSERT       = __;
    let SCROLLLOCK   = __;
    let SHIFTDOWN    = __;
    /************************************************************************************
    * class objects
    ************************************************************************************/
    let CLIPBOARD   = __;
    let FILEMANAGER = __;
    let LOADER      = __;
    let PAINTER     = __;
    let STACK       = __;
    let UTILS       = __;
    let VIEWPORT    = __;
    /************************************************************************************
    * filemanager states
    ************************************************************************************/
    let CURSOR = __;
    let FILE   = __;
    let LINE   = __;
    /************************************************************************************
    * viewport states
    ************************************************************************************/
    let FONT         = __;
    let LINEHEIGHT   = __;
    let FILESEGSIZE  = __;
    let FILESEGBEGIN = __;
    let FILESEGEND   = __;
    let LINESTART    = __;
    let LINESTOP     = __;
    let TMARGIN      = __;
    let LMARGIN      = __;
    let BMARGIN      = __;
    let RMARGIN      = __;
    let VIEWCAPACITY = __;
    /************************************************************************************
    * paper states
    ************************************************************************************/
    let COVER    = __;
    let EXPLAIN  = __;
    let BGCOLOR  = __;
    let FGCOLOR  = __;
    let HELP     = __;
    let PROGRAMS = __;
    let TABSIZE  = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=__) {
    /************************************************************************************
    * The function which creates the paper process
    ************************************************************************************/
      let that = this;

      CURSOR    = 0;
      EXIT      = info.escape;
      HELP      = info.help;
      LINE      = 0;
      LINESTART = 0;
      LINESTOP  = 120;
      BMARGIN   = info.height - TMARGIN;
      LMARGIN   = 20;
      RMARGIN   = info.width - 10*LMARGIN;
      TMARGIN   = 20;

      if (BGCOLOR === __) { UTILS.Link (SetBgColor, [info.bgcolor]); }
      if (FGCOLOR === __) { UTILS.Link (SetFgColor, [info.fgcolor]); }
      if (FONT === __) { UTILS.Link (SetFont, [info.font]); }

      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
    /************************************************************************************
    * create painter
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "painter", Object.create (_)]);
      UTILS.Link (UTILS.MapKeyValue, [info, "painter", Object.create (_)]);
      UTILS.Link (UTILS.MapKeyValue, [info.painter, "id", info.id]);
      UTILS.Link (UTILS.MapKeyValue, [info.painter, "cover", COVER]);
      UTILS.Link (UTILS.MapKeyValue, [info.painter, "height", UTILS.WIN.SYS.innerHeight - 20]);
      UTILS.Link (UTILS.MapKeyValue, [info.painter, "width", UTILS.WIN.SYS.innerWidth  - 20]);
      UTILS.Link (PAINTER.Create, [info.painter ], that.painter);
    /************************************************************************************
    * create stack
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "stack", Object.create (_)]);
      UTILS.Link (STACK.Create, _, that.stack);
    /************************************************************************************
    * initialize viewport
    ************************************************************************************/
      UTILS.Link (VIEWPORT.SetTopMargin, [TMARGIN]);
      UTILS.Link (VIEWPORT.SetLeftMargin, [LMARGIN]);
      UTILS.Link (VIEWPORT.SetBottomMargin, [BMARGIN]);
      UTILS.Link (VIEWPORT.SetRightMargin, [RMARGIN]);
      UTILS.Link (VIEWPORT.SetLineStop, [LINESTOP]);
    /************************************************************************************
    * customize paper
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "Press", Object.create (Press)]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Printable", Object.create (Printable)]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Release", Object.create (Release)]);
      UTILS.Link (Customize, _, that);
    /********************************************************************************************************************/
      UTILS.Link (CalculateViewCapacity);
    /************************************************************************************
    * read help file
    ************************************************************************************/
      UTILS.Link (FILEMANAGER.Read, [HELP], that);
    /********************************************************************************************************************/
    /************************************************************************************
    * set system flags
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "editing", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
 
    function Customize () {
      let that    = this;
      let HELP    = UTILS.KBD.KEY.F1;
      let oldHelp = UTILS.Link (GetKeyFunction, [HELP, UTILS.PRESS], that);
      let newHelp = UTILS.Link (MakeNewHelp, [oldHelp], that);

      UTILS.Link (UpdateDocumentBgColor);
    /********************************************************************************************************************/
      UTILS.Link (SetKeyFunction, [UTILS.KBD.KEY.ESCAPE, EXIT, UTILS.RELEASE], that);
      UTILS.Link (SetKeyFunction, [HELP, newHelp, UTILS.PRESS], that);
      UTILS.Link (SetKeyFunction, [UTILS.KBD.KEY.INTERNALCALL, UseFileContents, UTILS.PRESS], that);
    /********************************************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that.Press, UTILS.KBD.KEY.DOWN, KeydownHandler.bind (that)]);
      UTILS.Link (UTILS.MapKeyValue, [that.Press, UTILS.KBD.KEY.UP, KeyupHandler.bind (that)]);
      UTILS.Link (UTILS.MapKeyValue, [that.Press, UTILS.WIN.RESIZE, ResizeHandler.bind (that)]);
      UTILS.Link (UTILS.MapKeyValue, [that.Press, UTILS.MWS.WHEEL, MouseWheelScrollHandler.bind (that)]);
    /********************************************************************************************************************/
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.KBD.KEY.DOWN, UTILS.WIN.SYS], that.Press);
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.KBD.KEY.UP, UTILS.WIN.SYS], that.Press);
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.WIN.RESIZE, UTILS.WIN.SYS] , that.Press);
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.MWS.WHEEL, UTILS.Link (PAINTER.GetCanvas)], that.Press);

      return __;
     }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define event handlers below
  ************************************************************************************/

    function KeydownHandler (event=__) {
      let that = this;

      UTILS.Link (UTILS.MapKeyValue, [that, "editing", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
      UTILS.Link (RetrieveFile);
      UTILS.Link (RetrieveFileLine);
      UTILS.Link (RetrieveFileCursor);
      UTILS.Link (RetrieveViewportStart);
      UTILS.Link (RetrieveViewportLength);
      UTILS.Link (RetrieveViewportLineStart);

      if (UTILS.Link (NonPrintCharacter, [event.key], _)) {
        if (UTILS.Link (PressCharacter, [event.key], _)) {
          UTILS.Link (HandlePress, [event], that);
        }
      }
      else { UTILS.Link (HandlePrint, [event], that); }
      if (that.justifyViewport) { UTILS.Link (JustifyViewport); }

      UTILS.Link (PersistViewportStart);
      UTILS.Link (PersistViewportLength);
      UTILS.Link (PersistViewportLineStart);

      if (that.editing) {
        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);
      }
      if (that.requireRewrite) { UTILS.Link (ReWrite, _, that); }
      if (that.preventDefault) { UTILS.Link (event.preventDefault, _, event); }
      if (that.stopPropagation) { UTILS.Link (event.stopPropagation, _, event); }

      UTILS.Link (PersistFile);
      UTILS.Link (PersistFileLine);
      UTILS.Link (PersistFileCursor);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function KeyupHandler (event=__) {
      let that = this;
      let executableCommand = false;

      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
      UTILS.Link (RetrieveFile);
      UTILS.Link (RetrieveFileLine);
      UTILS.Link (RetrieveFileCursor);
      UTILS.Link (RetrieveViewportStart);
      UTILS.Link (RetrieveViewportLength);
      UTILS.Link (RetrieveViewportLineStart);

      switch (event.key) {
        case UTILS.KBD.KEY.ALT       : executableCommand = true; break;
        case UTILS.KBD.KEY.ALTGRAPH  : executableCommand = true; break;
        case UTILS.KBD.KEY.CONTROL   : executableCommand = true; break;
        case UTILS.KBD.KEY.END       : executableCommand = true; break;
        case UTILS.KBD.KEY.ESCAPE    : executableCommand = true; break;
        case UTILS.KBD.KEY.F2        : executableCommand = true; break;
        case UTILS.KBD.KEY.F8        : executableCommand = true; break;
        case UTILS.KBD.KEY.F9        : executableCommand = true; break;
        case UTILS.KBD.KEY.F10       : executableCommand = true; break;
        case UTILS.KBD.KEY.HOME      : executableCommand = true; break;
        case UTILS.KBD.KEY.INSERT    : executableCommand = true; break;
        case UTILS.KBD.KEY.OS        : executableCommand = true; break;
        case UTILS.KBD.KEY.SHIFT     : executableCommand = true; break;
        case UTILS.KBD.KEY.SCROLLLOCK: executableCommand = true; break;
      }

      if (executableCommand) { UTILS.Link (HandleRelease, [event], that); }
      if (that.justifyViewport) { UTILS.Link (JustifyViewport); }

      UTILS.Link (PersistViewportStart);
      UTILS.Link (PersistViewportLength);
      UTILS.Link (PersistViewportLineStart);

      if (that.editing) {
        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);
      }
      if (that.requireRewrite) { UTILS.Link (ReWrite, _, that); }
      if (that.preventDefault) { UTILS.Link (event.preventDefault, _, event); }
      if (that.stopPropagation) { UTILS.Link (event.stopPropagation, _, event); }

      UTILS.Link (PersistFile);
      UTILS.Link (PersistFileLine);
      UTILS.Link (PersistFileCursor);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MouseWheelScrollHandler (event=__) {
      let that         = this;
      let SCROLLAMOUNT = 3;
      let deltaSize    = -event.deltaY;

      //if (SCROLLLOCK && !CONTROLDOWN) { SCROLLAMOUNT = 1; }
      if (CONTROLDOWN) { UTILS.Link (UpdateFontSize, [deltaSize], that); }
      else if (FILE.length >= VIEWCAPACITY) {
        if (deltaSize < 0) {
          for (let o = 0; (o < SCROLLAMOUNT); o ++) {
            if ((FILESEGBEGIN + 1 + FILESEGEND) < FILE.length) {
              FILESEGBEGIN = FILESEGBEGIN + 1;
            }
          }
        }
        else {
          for (let o = 0; (o < SCROLLAMOUNT); o ++) {
            if (FILESEGBEGIN > 0) { FILESEGBEGIN = FILESEGBEGIN - 1; }
          }
        }
      }
      if (that.requireRewrite) { UTILS.Link (ReWrite, _, that); }

      UTILS.Link (event.preventDefault, _, event);
      UTILS.Link (event.stopPropagation, _, event );
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ResizeHandler (event) {
      let that = this;

      UTILS.Link (PAINTER.SetCanvasHeightTo, [UTILS.WIN.SYS.innerHeight - 20]);
      UTILS.Link (PAINTER.SetCanvasWidthTo, [UTILS.WIN.SYS.innerWidth - 20]);

      RMARGIN = UTILS.Link (PAINTER.GetCanvasWidth) - 10*LMARGIN;

      UTILS.Link (VIEWPORT.SetRightMargin, [RMARGIN]);
      UTILS.Link (ReWrite, _, that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define arbitrary internal functions below
  ************************************************************************************/

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function NewLine () {
    /************************************************************************************
    * The function which moves the cursor to the next line on the kanvas 
    ************************************************************************************/
      let that = this;
      UTILS.Link (UTILS.MapKeyValue, [that, "y", that.y + LINEHEIGHT]);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefineNonPrintKeyFunctions () {

      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.INTERNALCALL, InternalCall]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.ALT, PressAlt]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.ALTGRAPH, PressAltGraph]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.ARROWLEFT, ArrowLeft]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.ARROWUP, ArrowUp]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.ARROWDOWN, ArrowDown]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.ARROWRIGHT, ArrowRight]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.BACKSPACE, Backspace]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.CONTEXTMENU, ContextMenu]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.CONTROL, PressControl]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.DELETE, Delete]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.ENTER, Enter]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.F1, F1]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.F11, F11]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.TAB, Tab]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.PAGEDOWN, PageDown]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.PAGEUP, PageUp]);
      UTILS.Link (UTILS.MapKeyValue, [Press, UTILS.KBD.KEY.SHIFT, PressShift]);

      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.OS, OS]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.ALT, ReleaseAlt]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.ALTGRAPH, ReleaseAltGraph]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.CONTROL, ReleaseControl]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.END, End]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.F2, F2]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.F8, F8]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.F9, F9]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.F10, F10]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.HOME, Home]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.INSERT, Insert]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.SHIFT, ReleaseShift]);
      UTILS.Link (UTILS.MapKeyValue, [Release, UTILS.KBD.KEY.SCROLLLOCK, ScrollLock]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefinePrintKeyFunctions () {

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      let startPrintKeys = 32;
      let stopPrintKeys  = 126;

      UTILS.Link (GenerateKeyFunctions, [startPrintKeys, stopPrintKeys, PrintKey], Printable);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.MINUS_SIGN, MinusSign]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.PLUS_SIGN, PlusSign]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.LOWERCASE_C, LowercaseC]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.LOWERCASE_F, LowercaseF]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.LOWERCASE_I, LowercaseI]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.LOWERCASE_K, LowercaseK]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.LOWERCASE_O, LowercaseO]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.LOWERCASE_P, LowercaseP]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.LOWERCASE_S, LowercaseS]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.LOWERCASE_V, LowercaseV]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.LOWERCASE_X, LowercaseX]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.UPPERCASE_C, UppercaseC]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.UPPERCASE_F, UppercaseF]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.UPPERCASE_I, UppercaseI]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.UPPERCASE_K, UppercaseK]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.UPPERCASE_O, UppercaseO]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.UPPERCASE_P, UppercaseP]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.UPPERCASE_S, UppercaseS]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.UPPERCASE_V, UppercaseV]);
      UTILS.Link (UTILS.MapKeyValue, [Printable, UTILS.KBD.KEY.UPPERCASE_X, UppercaseX]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandlePress (event=__) {
    /************************************************************************************
    * The function which handles command keys for the paper process 
    ************************************************************************************/
      let that = this;
      let Command = UTILS.Link (GetKeyFunction, [event.key, UTILS.PRESS], that);

      UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);
      UTILS.Link (Command, [event], that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandleRelease (event=__) {
    /************************************************************************************
    * The function which handles release keys for the paper process 
    ************************************************************************************/
      let that    = this;
      let Command = UTILS.Link (GetKeyFunction, [event.key, UTILS.RELEASE], that);

      return UTILS.Link (Command, [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandlePrint (event=__) {
    /************************************************************************************
    * The function which handles printable character keys for the paper process 
    ************************************************************************************/
      let that = this;
      let PrintableKey = UTILS.Link (GetKeyFunction, [event.key], that);

      UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);

      return UTILS.Link (PrintableKey, [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CalculateViewCapacity () {
      let that = this;

      BMARGIN      = UTILS.Link (PAINTER.GetCanvasHeight) - 2 * LINEHEIGHT;
      VIEWCAPACITY = (BMARGIN - (BMARGIN % LINEHEIGHT)) / LINEHEIGHT;

      return __;
    }    

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UseFileContents (event=__) {
      let that = this;

      UTILS.Link (RetrieveFile);
      UTILS.Link (RetrieveFileLine);
      UTILS.Link (RetrieveFileCursor);

      FILESEGBEGIN = 0;
      FILESEGEND = LINE;
      LINESTART = FILESEGBEGIN;

      if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
      if (LINE >= VIEWCAPACITY) {
        FILESEGBEGIN = LINE - VIEWCAPACITY;
        FILESEGEND = VIEWCAPACITY;
      }

      UTILS.Link (PersistClipboardCursor);
      UTILS.Link (PersistClipboardLine);
      UTILS.Link (PersistViewportStart);
      UTILS.Link (PersistViewportLength);
      UTILS.Link (PersistViewportLineStart);
      UTILS.Link (ReWrite, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=__) {
      let thatpaper = this;

      function Help (event=__, otherEscape=__) {
        let that = this;
        let Exit = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ESCAPE, UTILS.RELEASE], thatpaper);

        if (otherEscape !== __) { Exit = otherEscape; }

        UTILS.Link (PersistFile);
        UTILS.Link (PersistFileLine);
        UTILS.Link (PersistFileCursor);
        UTILS.Link (PressControl, _, that);
        UTILS.Link (End, _, that);
        UTILS.Link (ReleaseControl, _, that);
        UTILS.Link (Enter, _, that);
        UTILS.Link (Helper, _, that);
        UTILS.Link (Exit, _, that);

        return __;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LeadWithSpaces (number=__, max=__) {
      let paddedValue = number + UTILS.KBD.KEY.WHITESPACE;
      let maxlength = (UTILS.BLANKCHAR + max).length;
      let blocks = 1 + maxlength - paddedValue.length;

      while (blocks > 0) {
        paddedValue = UTILS.KBD.KEY.WHITESPACE + paddedValue;
        blocks = blocks - 1;
      }

      return paddedValue;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SkipWordMoveCursor (spaceCharSide=__) {
      let that  = this;
      let chars = __;
      let line  = __;
      let LEFT  = 0;
      let RIGHT = 1;

      line = FILE [LINE];

      if ((LEFT === spaceCharSide) || (spaceCharSide === RIGHT)) {
        if (spaceCharSide === RIGHT) {
          for (let o = CURSOR; o <= line.length - 2; o ++) {
            chars = line.substring (o, o+2);

            if ((chars.charAt (RIGHT) === UTILS.KBD.KEY.WHITESPACE) && (chars.charAt (LEFT) !== UTILS.KBD.KEY.WHITESPACE)) {
              return (o+1);
            }
          }

          return line.length;
        }
        else {
          for (let o = CURSOR; o >= 2; o --) {
            chars = line.substring (o-2, o);

            if ((chars.charAt (LEFT) === UTILS.KBD.KEY.WHITESPACE) && (chars.charAt (RIGHT) !== UTILS.KBD.KEY.WHITESPACE)) {
              return (o-1);
            }
          }

          return LEFT;
        }
      }

      return (-RIGHT);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function TextSelected () {
      let fromLine = UTILS.Link (CLIPBOARD.GetLine);
      let fromCursor = UTILS.Link (CLIPBOARD.GetCursor);
      let differentLines = (fromLine !== LINE);
      let differentCursors = (fromCursor !== CURSOR);

      return (differentLines || differentCursors);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DeleteSelectionFromFile () {
      let fromLine = UTILS.Link (CLIPBOARD.GetLine);
      let fromCursor = UTILS.Link (CLIPBOARD.GetCursor);
      let toLine = fromLine;
      let toCursor = fromCursor;
      let shorterFile = new Array ();
      let differentLines = __;
      let differentCursors = __;

      if (fromLine !== LINE) {
        if (fromLine > LINE) {
          fromLine = LINE;
          fromCursor = CURSOR;
        }
        else {
          toLine = LINE;
          toCursor = CURSOR;
        }

        FILE [fromLine] = FILE [fromLine].substring (0, fromCursor);
        FILE [toLine] = FILE [toLine].substring (toCursor, FILE [toLine].length);

        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, (FILE [fromLine] + FILE [toLine])]);
      }
      else {
        let sublineA = FILE [fromLine];
        let sublineB = FILE [toLine];

        toCursor = CURSOR;

        if (fromCursor > toCursor) {
          fromCursor = fromCursor + toCursor;
          toCursor = fromCursor - toCursor;
          fromCursor = fromCursor - toCursor;
        }

        sublineA = sublineA.substring (0, fromCursor);
        sublineB = sublineB.substring (toCursor, sublineB.length);

        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, (sublineA + sublineB)]);
      }

      LINE = fromLine;
      CURSOR = fromCursor;
      differentCursors = (fromCursor !== toCursor);
      differentLines = (fromLine !== toLine);

      if (differentLines || differentCursors) {
        for (let i = 0; i <FILE.length; i ++) {
          if ((i <= fromLine) || (i > toLine)) { shorterFile.push (FILE [i]); }
        }

        FILE = shorterFile;

        if (FILE.length < VIEWCAPACITY) { FILESEGEND = (FILESEGBEGIN + FILE.length) - 1; }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFirstWordOnLastLine () {
      let index = FILE.length - 1;
      let text = FILE [index].split (UTILS.KBD.KEY.WHITESPACE);

      text = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, text]);
      text = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, text]);
      text = text [0];

      return text;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ReportUpdateSuccess (evt=__) {
      let that = this;
      console.log ("External clipboard updated sucessfully!");
      return __;
    }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function CopyTextToClipboard () {
        let that = this;
        let fromLine = UTILS.Link (CLIPBOARD.GetLine);
        let toLine = fromLine + 1;
        let fromCursor = UTILS.Link (CLIPBOARD.GetCursor);
        let toCursor = fromCursor;
        let clippedText = __;
        let clippedLine = __;

        if (fromLine < LINE) {
          toLine = LINE + 1;
          toCursor = CURSOR;
        }
        else if (fromLine > LINE) {
          fromLine = LINE;
          fromCursor = CURSOR;
        }

        if ((fromLine + 1) === toLine) {
          toCursor = CURSOR;

          if (fromCursor > toCursor) {
            fromCursor = fromCursor + toCursor;
            toCursor = fromCursor - toCursor;
            fromCursor = fromCursor - toCursor;
          }

          clippedText = FILE.slice (fromLine, toLine);
          fromLine = clippedText [0];
          clippedLine = fromLine.substring (fromCursor, toCursor);

          UTILS.Link (UTILS.MapKeyValue, [clippedText, 0, clippedLine]);
        }
        else {
          clippedText = FILE.slice (fromLine, toLine);
          fromLine = clippedText [0];
          clippedLine = fromLine.substring (fromCursor, fromLine.length);

          UTILS.Link (UTILS.MapKeyValue, [clippedText, 0, clippedLine]);

          toLine = clippedText [clippedText.length - 1];
          clippedLine = toLine.substring (0, toCursor);
          toCursor = clippedText.length - 1;

          UTILS.Link (UTILS.MapKeyValue, [clippedText, toCursor, clippedLine]);
        }

        UTILS.Link (CLIPBOARD.SetText, [clippedText]);

        return __;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function SearchFile (direction=__) {
        let that = this;
        let filesize = FILE.length;
        let keyword = FILE [filesize - 1];
        let initCursor = CURSOR;
        let initLine = LINE;
        let currentCursor = initCursor;
        let currentLine = initLine;
        let EOF = __;
        let delta = __;

        if (direction < 0) {
          EOF = -1;
          delta = -1;
        }
        else if (direction > 0) {
          EOF = filesize;
          delta = 1;
        }

        UTILS.Link (SearchLine, [keyword, currentLine, currentCursor, initLine], that);

        if ((LINE === initLine) && (CURSOR === initCursor)) {

          currentLine = initLine + delta;
          currentCursor = 0;

          while (currentLine !== initLine) {
            if (currentLine === EOF) { 
              if (direction < 0) { currentLine = filesize - 1; }
              else if (direction > 0) { currentLine = 0; }
            }

            currentLine = UTILS.Link (SearchLine, [keyword, currentLine, currentCursor, initLine], that);

            if (currentLine !== initLine) {
              currentCursor = 0;
              currentLine = currentLine + delta;
            }
          }
        }

        return __;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function SearchLine (keyword=__, linenumber=__, cursorPosition=__, eoc=__) {
        let that        = this;
        let sentence    = FILE [linenumber];
        let k           = keyword.length;
        let textSegment = __;

        for (let j = cursorPosition; (sentence.length >= k) && (j + k <= sentence.length); j ++) {
          textSegment = sentence.substring (j, j + k);

          if (keyword === textSegment) {
            LINE       = linenumber;
            CURSOR     = j + k;
            j          = sentence.length;
            linenumber = eoc;
          }
        }

        return linenumber;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function PasteTextFromClipboard () {
        let that = this;
        let preCut = FILE.slice (0, LINE + 1);
        let postCut = FILE.slice (LINE, FILE.length);
        let clippedText = UTILS.Link (CLIPBOARD.GetText);
        let splitLine = preCut [LINE];

        if (clippedText.length === 1) {
          splitLine = splitLine.substring (0, CURSOR);
          splitLine = splitLine + clippedText [0];
          clippedText = postCut [0];
          clippedText = clippedText.substring (CURSOR, clippedText.length);
          CURSOR = splitLine.length;
          splitLine = splitLine + clippedText;

          preCut.pop ();

          preCut = preCut.concat (postCut);

          UTILS.Link (UTILS.MapKeyValue, [preCut, LINE, splitLine]);

          FILE = preCut;
        }
        else {
          splitLine = splitLine.substring (0, CURSOR);
          splitLine = splitLine + clippedText [0];
          UTILS.Link (UTILS.MapKeyValue, [preCut, LINE, splitLine]);

          splitLine = postCut [0];
          splitLine = splitLine.substring (CURSOR, splitLine.length);
          CURSOR = clippedText.length - 1;
          splitLine = clippedText [CURSOR] + splitLine;
          UTILS.Link (UTILS.MapKeyValue, [postCut, 0, splitLine]);

          CURSOR = clippedText [CURSOR].length;
          LINE = (LINE + clippedText.length) - 1;
          clippedText = clippedText.slice (1, clippedText.length - 1);
          clippedText = preCut.concat (clippedText);
          FILE = clippedText.concat (postCut);

        /*
          account for file lengths exceeding view capacity and file lengths within view capacity
        */
          if (FILE.length < VIEWCAPACITY) { FILESEGBEGIN = 0; FILESEGEND = FILE.length - 1; }
          else {
            FILESEGEND = VIEWCAPACITY - 1;

            if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
          }
        }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LaunchFullscreen () {
      let that    = this;
      let element = UTILS.WIN.DOC.documentElement;

      if (element.requestFullscreen      ) { element.requestFullscreen      (); } else
      if (element.mozRequestFullScreen   ) { element.mozRequestFullScreen   (); } else
      if (element.webkitRequestFullscreen) { element.webkitRequestFullscreen(); } else
      if (element.msRequestFullscreen    ) { element.msRequestFullscreen    (); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ExitFullscreen () {
      let that = this;

      if (UTILS.WIN.DOC.exitFullscreen      ) { UTILS.WIN.DOC.exitFullscreen      (); } else
      if (UTILS.WIN.DOC.mozCancelFullScreen ) { UTILS.WIN.DOC.mozCancelFullScreen (); } else
      if (UTILS.WIN.DOC.webkitExitFullscreen) { UTILS.WIN.DOC.webkitExitFullscreen(); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UpdateFontSize (amount=__) {
      let that      = this;
      let fontUnits = UTILS.BLANKCHAR;
      let fontArray = FONT.split (UTILS.KBD.KEY.WHITESPACE);
      let fontSize  = fontArray [0].split (UTILS.BLANKCHAR);
      let deltaSize = amount / amount;
      let tmpFont   = __;

      fontUnits = fontSize.pop () + fontUnits;
      fontUnits = fontSize.pop () + fontUnits;
      fontSize  = fontSize.join (UTILS.BLANKCHAR);
      fontSize  = UTILS.Link (UTILS.ToNumber, [__, fontSize]);

      if (amount < 0) { deltaSize = -1 * deltaSize; }

      fontSize   = fontSize + deltaSize;
      tmpFont    = fontSize + fontUnits + UTILS.KBD.KEY.WHITESPACE + fontArray [1];

      UTILS.Link (SetLineHeight, [LINEHEIGHT + deltaSize]);
      UTILS.Link (SetFont, [tmpFont]);
      UTILS.Link (CalculateViewCapacity);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function JustifyViewport () {
      let that = this;

      if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
      if (LINE < FILESEGBEGIN) { FILESEGBEGIN = LINE; }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

   function PrintCharacter (key=__) {
      let that          = this;
      let currentline   = __;
      let endOfThisLine = __;
      let subline       = __;

      if (INSERT && (CURSOR < FILE [LINE].length)) { UTILS.Link (Delete, _, that); }
      else if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }

      currentline = FILE [LINE];
      endOfThisLine = currentline.length;
      subline = currentline.substring (0, CURSOR);

      UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, subline + key]);

      subline = currentline.substring (CURSOR, endOfThisLine);

      UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, FILE [LINE] + subline]);

      CURSOR = CURSOR + key.length;

      if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PrintKey (event) {
      let that = this;
      UTILS.Link (PrintCharacter, [event.key], that);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function NonPrintCharacter (key=__) {
    /************************************************************************************
    * The function which determines whether a character is non-printable 
    ************************************************************************************/
      let invisibility = false;

      switch (key) {
        case UTILS.KBD.KEY.ALT                : invisibility = true; break;
        case UTILS.KBD.KEY.ALTGRAPH           : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWDOWN          : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWLEFT          : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWRIGHT         : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWUP            : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEDOWN    : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEMUTE    : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEUP      : invisibility = true; break;
        case UTILS.KBD.KEY.BACKSPACE          : invisibility = true; break;
        case UTILS.KBD.KEY.CAPSLOCK           : invisibility = true; break;
        case UTILS.KBD.KEY.CONTROL            : invisibility = true; break;
        case UTILS.KBD.KEY.CONTEXTMENU        : invisibility = true; break;
        case UTILS.KBD.KEY.DELETE             : invisibility = true; break;
        case UTILS.KBD.KEY.END                : invisibility = true; break;
        case UTILS.KBD.KEY.ENTER              : invisibility = true; break;
        case UTILS.KBD.KEY.ESCAPE             : invisibility = true; break;
        case UTILS.KBD.KEY.F1                 : invisibility = true; break;
        case UTILS.KBD.KEY.F2                 : invisibility = true; break;
        case UTILS.KBD.KEY.F3                 : invisibility = true; break;
        case UTILS.KBD.KEY.F4                 : invisibility = true; break;
        case UTILS.KBD.KEY.F5                 : invisibility = true; break;
        case UTILS.KBD.KEY.F6                 : invisibility = true; break;
        case UTILS.KBD.KEY.F7                 : invisibility = true; break;
        case UTILS.KBD.KEY.F8                 : invisibility = true; break;
        case UTILS.KBD.KEY.F9                 : invisibility = true; break;
        case UTILS.KBD.KEY.F10                : invisibility = true; break;
        case UTILS.KBD.KEY.F11                : invisibility = true; break;
        case UTILS.KBD.KEY.F12                : invisibility = true; break;
        case UTILS.KBD.KEY.HOME               : invisibility = true; break;
        case UTILS.KBD.KEY.INSERT             : invisibility = true; break;
        case UTILS.KBD.KEY.INTERNALCALL       : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIAPLAY          : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIATRACKNEXT     : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIATRACKPREVIOUS : invisibility = true; break;
        case UTILS.KBD.KEY.NUMLOCK            : invisibility = true; break;
        case UTILS.KBD.KEY.OS                 : invisibility = true; break;
        case UTILS.KBD.KEY.PAGEDOWN           : invisibility = true; break;
        case UTILS.KBD.KEY.PAGEUP             : invisibility = true; break;
        case UTILS.KBD.KEY.SHIFT              : invisibility = true; break;
        case UTILS.KBD.KEY.SCROLLLOCK         : invisibility = true; break;
        case UTILS.KBD.KEY.TAB                : invisibility = true; break;
        case UTILS.KBD.KEY.UNIDENTIFIED       : invisibility = true; break;
      }

      return invisibility;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PressCharacter (key=__) {
    /************************************************************************************
    * The function which determines whether a character is treated as a command 
    ************************************************************************************/
      let status = false;

      switch (key) {
        case UTILS.KBD.KEY.ALT                : status = true; break;
        case UTILS.KBD.KEY.ALTGRAPH           : status = true; break;
        case UTILS.KBD.KEY.ARROWDOWN          : status = true; break;
        case UTILS.KBD.KEY.ARROWLEFT          : status = true; break;
        case UTILS.KBD.KEY.ARROWRIGHT         : status = true; break;
        case UTILS.KBD.KEY.ARROWUP            : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEDOWN    : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEMUTE    : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEUP      : status = true; break;
        case UTILS.KBD.KEY.BACKSPACE          : status = true; break;
        case UTILS.KBD.KEY.CONTEXTMENU        : status = true; break;
        case UTILS.KBD.KEY.CONTROL            : status = true; break;
        case UTILS.KBD.KEY.DELETE             : status = true; break;
        case UTILS.KBD.KEY.ENTER              : status = true; break;
        case UTILS.KBD.KEY.F1                 : status = true; break;
        case UTILS.KBD.KEY.F5                 : status = true; break;
        case UTILS.KBD.KEY.F6                 : status = true; break;
        case UTILS.KBD.KEY.F11                : status = true; break;
        case UTILS.KBD.KEY.MEDIAPLAY          : status = true; break;
        case UTILS.KBD.KEY.MEDIATRACKNEXT     : status = true; break;
        case UTILS.KBD.KEY.MEDIATRACKPREVIOUS : status = true; break;
        case UTILS.KBD.KEY.PAGEDOWN           : status = true; break;
        case UTILS.KBD.KEY.PAGEUP             : status = true; break;
        case UTILS.KBD.KEY.TAB                : status = true; break;
        case UTILS.KBD.KEY.SHIFT              : status = true; break;
      // add cases to handle other command keys
      }

      return status;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function InternalCall () {
    /************************************************************************************
    * The function which performs arbitrary tasks wherever ...
    ************************************************************************************/
      let that = this;
      console.log ("[ internal call: ", FILE [0], " ]");
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PressAlt (event=__) {
      let that = this;

      ALTDOWN = true;
      UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PressAltGraph (event=__) {
      let that = this;

      ALTGRAPHDOWN = true;
      UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ArrowLeft (event=__) {
    /************************************************************************************
    * The function which moves the cursor to the left
    ************************************************************************************/
      let that = this;

      if (CONTROLDOWN) {
        let LEFT = 0;

        if (CURSOR === 0) {
          UTILS.Link (ReleaseControl, _, that);
          UTILS.Link (ArrowLeft, _, that); 
          UTILS.Link (PressControl, _, that);
        }
        else {
          CURSOR = UTILS.Link (SkipWordMoveCursor, [LEFT], that);
          if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        }
      }
      else {
      if (CURSOR > 0) {
          CURSOR = CURSOR - 1;
          if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        }
        else {
          let scrollLockActive = SCROLLLOCK;

          if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }

          UTILS.Link (ArrowUp, _, that);

          if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }
        }
      }

      if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ArrowUp (event=__) {
    /************************************************************************************
    * The function which moves the cursor to the next line above 
    ************************************************************************************/
      let that = this;

      if (SCROLLLOCK && !CONTROLDOWN) {
        UTILS.Link (UTILS.MapKeyValue, [event, "deltaY", -3]);
        UTILS.Link (MouseWheelScrollHandler, [event], that);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
      }
      else if (SHIFTDOWN && CONTROLDOWN) {
        let tmpline      = __;
        let currentline  = LINE;
        let previousline = currentline - 1;

        if (previousline >= 0) {
          tmpline = FILE [previousline];

          UTILS.Link (UTILS.MapKeyValue, [FILE, previousline, FILE [currentline]]);
          UTILS.Link (UTILS.MapKeyValue, [FILE, currentline, tmpline]);

          LINE = previousline;

          if (LINE < FILESEGBEGIN) { FILESEGBEGIN = LINE; }
        }
      }
      else if (CONTROLDOWN && !SCROLLLOCK) {
        UTILS.Link (UTILS.MapKeyValue, [event, "deltaY", -3]);
        UTILS.Link (ReleaseControl, _, that);
        UTILS.Link (MouseWheelScrollHandler, [event], that);
        UTILS.Link (PressControl, _, that);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        if (LINE > (FILESEGBEGIN + FILESEGEND)) { LINE = FILESEGBEGIN + FILESEGEND; }
        if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }
        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        if (CURSOR < LINESTART) { LINESTART = CURSOR; }

        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);
      }
      else {
        if (LINE > 0) {
          LINE = LINE - 1;
          CURSOR = FILE [LINE].length;
        }

        if (LINE < FILESEGBEGIN) { FILESEGBEGIN = LINE; }
        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ArrowDown (event=__) {
    /************************************************************************************
    * The function which moves the cursor to the next line below
    ************************************************************************************/
      let that = this;

      if (SCROLLLOCK && !CONTROLDOWN) {
        UTILS.Link (UTILS.MapKeyValue, [event, "deltaY", 3]);
        UTILS.Link (MouseWheelScrollHandler, [event], that);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
      }
      else if (SHIFTDOWN && CONTROLDOWN) {
        let currentline = LINE;
        let nextline = currentline + 1;

        if (nextline < FILE.length) {
          let tmpline = FILE [nextline];

          UTILS.Link (UTILS.MapKeyValue, [FILE, nextline, FILE [currentline]]);
          UTILS.Link (UTILS.MapKeyValue, [FILE, currentline, tmpline]);

          LINE = nextline;

          if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
        }
      }
      else if (CONTROLDOWN && !SCROLLLOCK) {
        UTILS.Link (UTILS.MapKeyValue, [event, "deltaY", 3]);
        UTILS.Link (ReleaseControl, _, that);
        UTILS.Link (MouseWheelScrollHandler, [event], that);
        UTILS.Link (PressControl, _, that);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        if (LINE < FILESEGBEGIN) { LINE = FILESEGBEGIN; }
        if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }
        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        if (CURSOR < LINESTART) { LINESTART = CURSOR; }

        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);
      }
      else {
        if ((LINE + 1) < FILE.length) {
          LINE = LINE + 1; 
          CURSOR = FILE [LINE].length;
        }

        if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ArrowRight (event=__) {
    /************************************************************************************
    * The function which moves the cursor to the right 
    ************************************************************************************/
      let that = this;

      if (CONTROLDOWN) {
        let RIGHT = 1;

        if (CURSOR === FILE [LINE].length) {
          UTILS.Link (ReleaseControl, _, that);
          UTILS.Link (ArrowRight, _, that);
          UTILS.Link (PressControl, _, that);
        }
        else {
          CURSOR = UTILS.Link (SkipWordMoveCursor, [RIGHT], that);
          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        }
      }
      else {
        if (CURSOR < FILE [LINE].length) {
          CURSOR = CURSOR + 1;
          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        }
        else {
          let scrollLockActive = SCROLLLOCK;

          if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }

          UTILS.Link (ArrowDown, _, that);

          if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }

          UTILS.Link (Home, _, that);
        }
      }

      if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Backspace (event=__) {
      let that = this;

      if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }
      else if (SHIFTDOWN) {
        let DeleteLine = F9;

        UTILS.Link (ReleaseShift, _, that);
        UTILS.Link (DeleteLine, _, that);
        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);
        UTILS.Link (Backspace, _, that);
        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);
        UTILS.Link (PressShift, _, that);
      }
      else {
        let line = FILE [LINE];
        let leftbit = __;
        let midbit = __;
        let rightbit = __;

        if (CURSOR > 0) {
          line = FILE [LINE].substring (0, CURSOR - 1);
          line = line + FILE [LINE].substring (CURSOR, FILE [LINE].length);
          CURSOR = CURSOR - 1;

          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, line]);

          if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        }
        else if (LINE > 0) {
          if ((FILE.length) >= VIEWCAPACITY) {
            if (FILESEGBEGIN > 0) { FILESEGBEGIN = FILESEGBEGIN - 1; }
          }
          else if (FILESEGBEGIN == 0) { FILESEGEND = FILESEGEND - 1; }

          leftbit = FILE.splice (0, LINE);
          midbit = FILE.splice (0,1);
          rightbit = FILE.splice (0);
          FILE = leftbit.concat (rightbit);
          LINE = LINE - 1;
          CURSOR = FILE [LINE].length;

          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, FILE [LINE] + midbit]);

          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ContextMenu (event=__) {
      let that = this;

      UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", false]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PressControl (event=__) {
      let that = this;

      CONTROLDOWN = true;
      UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Delete (event=__) {
    /************************************************************************************
    * The function which removes one character to the right of the cursor
    ************************************************************************************/
      let that = this;
      let line = FILE [LINE];

      if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }
      else if (CURSOR < line.length) {
        line = FILE [LINE].substring (0, CURSOR);
        line = line + FILE [LINE].substring (CURSOR + 1, FILE [LINE].length);

        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, line]);

        if (CURSOR > FILE [LINE].length) { CURSOR -= 1; }
      }
      else if ((LINE + 1) < FILE.length) {
        let shiftKeyDown     = SHIFTDOWN;
        let scrollLockActive = SCROLLLOCK;

        if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }
        if (shiftKeyDown) { UTILS.Link (ReleaseShift, _, that); }

        UTILS.Link (ArrowDown, _, that);

        if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }

        UTILS.Link (Home, _, that);
        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);
        UTILS.Link (Backspace, _, that);

        if (shiftKeyDown) { UTILS.Link (PressShift, _, that); }
      }

      UTILS.Link (PersistClipboardCursor);
      UTILS.Link (PersistClipboardLine);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Enter () {
    /************************************************************************************
    * The function which moves the cursor to the next line
    ************************************************************************************/
      let that         = this;
      let leftbit      = __;
      let rightbit     = __;
      let leftsubline  = __;
      let rightsubline = __;
      let START        = 0;

      if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }

      leftbit  = FILE.splice (START, LINE);
      rightbit = FILE.splice (START);

      leftbit.push (UTILS.BLANKCHAR);

      leftsubline                  = rightbit [START].substring (START, CURSOR);
      rightsubline                 = rightbit [START].substring (CURSOR, rightbit [START].length);
      leftbit [leftbit.length - 1] = leftsubline;
      rightbit [START]             = rightsubline;
      FILE                         = leftbit.concat (rightbit);
      CURSOR                       = START;
      LINESTART                    = CURSOR;
      LINE                         = LINE + 1;

      if (FILE.length < VIEWCAPACITY) { FILESEGEND = FILESEGEND + 1; }
      else if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = FILESEGBEGIN + 1; }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F1 () {
      /************************************************************************************
      * The function which displays the help text for the paper process
      ************************************************************************************/
        let that     = this;
        let helper   = EXPLAIN + that.id;
        let NOTFOUND = -1;

        if (that.id.indexOf (EXPLAIN) === NOTFOUND) {
          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, FILE [LINE] + helper]);
        }

        CURSOR = FILE [LINE].length;

        UTILS.Link (PersistFile);
        UTILS.Link (PersistFileLine);
        UTILS.Link (PersistFileCursor);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F11 () {
      /************************************************************************************
      * The function which requests maximum screen for the paper process
      ************************************************************************************/
        let that = this;
        UTILS.Link (CalculateViewCapacity);
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function Tab (event=__) {
      /************************************************************************************
      * The function which adds a tab-equivalent-of-spaces to the current line
      ************************************************************************************/
        let that = this;
        let fakeEvent = Object.create (_);

        if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }

        UTILS.Link (UTILS.MapKeyValue, [fakeEvent, "key", UTILS.KBD.KEY.WHITESPACE]);

        for (let i = 0; i < TABSIZE; i ++) {
          UTILS.Link (PersistClipboardLine);
          UTILS.Link (PersistClipboardCursor)
          UTILS.Link (HandlePrint, [fakeEvent], that);
        }

        UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
        UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function PageDown (event=__) {
      /************************************************************************************
      * The function which increases the length of the kanvas
      ************************************************************************************/
        let that = this;

        if (ALTDOWN) { UTILS.Link (PAINTER.ChangeCanvasHeightBy, [2]); }
        else if (CONTROLDOWN) { UTILS.Link (PAINTER.HideCanvas); }
        else {
          let nextPage = (2 * VIEWCAPACITY) + 1;
          let i = __;

          UTILS.Link (JustifyViewport);

          for (i = 0; (i < nextPage) && (FILESEGBEGIN + 1 + FILESEGEND < FILE.length); i ++) {
            FILESEGBEGIN = FILESEGBEGIN + 1;
            LINE = LINE + 1;
          }

          if (i < nextPage) { LINE = FILESEGBEGIN + FILESEGEND; }

          if (CURSOR > FILE [LINE].length) {
            CURSOR = FILE [LINE].length;
            if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          }
          if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
        }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function PageUp (event=__) {
      /************************************************************************************
      * The function which increases the length of the kanvas
      ************************************************************************************/
        let that = this;

        if (ALTDOWN) { UTILS.Link (PAINTER.ChangeCanvasHeightBy, [-2]); }
        else if (CONTROLDOWN) { UTILS.Link (PAINTER.ShowCanvas); }
        else {
          let nextPage = (2 * VIEWCAPACITY) + 1;
          let i = __;

          UTILS.Link (JustifyViewport);

          for (i = 0; (i < nextPage) && (FILESEGBEGIN > 0); i ++) {
            FILESEGBEGIN = FILESEGBEGIN - 1;
            LINE = LINE - 1;
          }

          if (i < nextPage) { LINE = FILESEGBEGIN; }

          if (CURSOR > FILE [LINE].length) {
            CURSOR = FILE [LINE].length;
            if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          }
          if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
        }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function PressShift (event=__) {
        let that = this;

        SHIFTDOWN = true;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function OS () {
      /************************************************************************************
      * The function which ...
      ************************************************************************************/
        let that = this;

        UTILS.Link (FILEMANAGER.Read, [PROGRAMS], that);
        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ReleaseAlt (event) {
        let that = this;

        ALTDOWN = false;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ReleaseAltGraph (event) {
        let that = this;

        ALTGRAPHDOWN = false;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ReleaseControl (event) {
        let that = this;

        CONTROLDOWN = false;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function End (event=__) {
      /************************************************************************************
      * The function which moves the cursor to the end of the line
      ************************************************************************************/
        let that = this;

        if (CONTROLDOWN) {
          LINE = FILE.length - 1;

          if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
        }

        CURSOR = FILE [LINE].length;

        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F2 () {
        let that        = this;
        let filename    = UTILS.Link (FILEMANAGER.GetFileName);
        let ctrlKeyDown = CONTROLDOWN;

        if (!ctrlKeyDown) { UTILS.Link (PressControl, _, that); }

        UTILS.Link (End, _, that);

        if (!ctrlKeyDown) { UTILS.Link (ReleaseControl, _, that); }

        UTILS.Link (Enter, _, that);
        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, filename]);
        UTILS.Link (End, _, that);

        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        else { LINESTART = 0; }

        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);
        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", true]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F8 (event = __) {
        let that = this;

        if (CONTROLDOWN) {
          UTILS.Link (End, _, that);
          UTILS.Link (Enter, _, that);
          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, UTILS.WIN.SYS.location.href]);

          CURSOR = FILE [LINE].length;

          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          else { LINESTART = 0; }

          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);
        }
        else {
          let url     = __;
          let urlline = FILE [FILE.length - 1].trim ();

          urlline = urlline.split (UTILS.KBD.KEY.WHITESPACE);
          urlline = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, urlline]);
          urlline = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, urlline]);
          url     = urlline [0];

          UTILS.WIN.SYS.location.assign (url);
        }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F9 () {
        let that = this;
/*
        if  (CONTROLDOWN) {
          let index = FILE.length - 1;
          let lineheight = FILE [index].trim ();

          lineheight = UTILS.Link (UTILS.ToNumber, [__, lineheight]);

          UTILS.Link (SetLineHeight, [lineheight]);
//          UTILS.Link (CalculateViewCapacity);
        }
        else {
*/
          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, UTILS.BLANKCHAR]);

          CURSOR = 0;
          LINESTART = 0;
//        }

        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function F10 () {
        let that = this;
/*
        if (CONTROLDOWN && SHIFTDOWN) {
          let index = FILE.length - 1;
          let font = FILE [index].trim ();
          UTILS.Link (SetFont, [font]);
        }
        else if (ALTDOWN) {
          let fgcolor = UTILS.Link (GetFirstWordOnLastLine);
          UTILS.Link (SetFgColor, [fgcolor]);
        }
        else if (CONTROLDOWN) {
          let bgcolor = UTILS.Link (GetFirstWordOnLastLine);
          UTILS.Link (SetBgColor, [bgcolor]);
        }
        else {
*/
          CURSOR = 0;
          LINE = 0;
          FILESEGEND = 0;
          FILE = new Array (UTILS.BLANKCHAR);
//        }

        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);
        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function Home (event=__) {
      /************************************************************************************
      * The function which moves the cursor to the beginning of the line
      ************************************************************************************/
        let that = this;

        if (CONTROLDOWN) {
          LINE = 0;
          FILESEGBEGIN = 0;
        }

        CURSOR = 0;

        if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function Insert (event=__) {
        let that = this;

        if (!CONTROLDOWN) { INSERT = !INSERT; }
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ReleaseShift (event) {
        let that = this;

        SHIFTDOWN = false;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function ScrollLock (event=__) {
        let that = this;

        if (!CONTROLDOWN) { SCROLLLOCK = !SCROLLLOCK; }
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function MinusSign (event) {
        let that      = this;
        let deltaSize = -1;

        if (CONTROLDOWN) {
          UTILS.Link (UpdateFontSize, [deltaSize], that);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function PlusSign (event) {
        let that      = this;
        let deltaSize = 1;

        if (CONTROLDOWN) {
          UTILS.Link (UpdateFontSize, [deltaSize], that);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseC (event) {
        let that = this;

        if (CONTROLDOWN) {
          let inClipbardText= __;
          let updateExClipboard = __;

          UTILS.Link (CopyTextToClipboard);

          inClipbardText = UTILS.Link (CLIPBOARD.GetText);
          inClipbardText = inClipbardText.join (UTILS.NEWLINECHAR);
          updateExClipboard = navigator.clipboard.writeText (inClipbardText);

          UTILS.Link (updateExClipboard.then, [ReportUpdateSuccess], updateExClipboard);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseC (event) {
        let that = this;

        if (CONTROLDOWN) {
          UTILS.Link (CopyTextToClipboard);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseF (event) {
        let that = this;

        if (CONTROLDOWN) { UTILS.Link (SearchFile, [-1], that); }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseF (event) {
        let that = this;

        if (CONTROLDOWN) { UTILS.Link (SearchFile, [1], that); }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseI (event) {
        let that = this;

        if (CONTROLDOWN && SHIFTDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseI (event) {
        let that = this;

        if (CONTROLDOWN && SHIFTDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseK (event=__) {
        let that = this;

        if (CONTROLDOWN && (!SHIFTDOWN)) {
          let currententry = FILE [LINE];

          UTILS.Link (End, _, that);
          UTILS.Link (PersistClipboardCursor);
          UTILS.Link (PersistClipboardLine);
          UTILS.Link (Enter, _, that);
          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, currententry])
          UTILS.Link (End, _, that);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", true]);
        }
        else if (CONTROLDOWN && SHIFTDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseK (event=__) {
        let that = this;
        UTILS.Link (UppercaseK, [event], that);      
        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseO (event) {
        let that = this;

        if (CONTROLDOWN) {
          let lastline = FILE.length - 1;
          let filename = FILE [lastline].trim ();
          UTILS.Link (FILEMANAGER.Read, [filename], that);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseO (event) {
        let that = this;

        if (CONTROLDOWN) {
          let lastline = FILE.length - 1;
          let filename = FILE [lastline].trim ();
          UTILS.Link (FILEMANAGER.Read, [filename], that);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseP (event) {
        let that = this;
  
        if (CONTROLDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseP (event) {
        let that = this;

        if (CONTROLDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseS (event) {
        let that = this;

        if (CONTROLDOWN) {
          let ctrlKeyDown  = CONTROLDOWN;
          let shiftKeyDown = SHIFTDOWN;
          let newfile      = FILE [FILE.length - 1].trim ();

          UTILS.Link (End, _, that);
          UTILS.Link (PersistClipboardCursor);
          UTILS.Link (PersistClipboardLine);

          if (!shiftKeyDown) { UTILS.Link (PressShift, _, that); }

          UTILS.Link (Backspace, _, that);

          if (!shiftKeyDown) { UTILS.Link (ReleaseShift, _, that); }

          UTILS.Link (PersistFile);
          UTILS.Link (PersistFileLine);
          UTILS.Link (PersistFileCursor);
          UTILS.Link (FILEMANAGER.Write, [newfile], that);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseS (event) {
        let that = this;

        if (CONTROLDOWN) {
          UTILS.Link (FILEMANAGER.Write, _, that);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseV (event) {
        let that = this;

        if (CONTROLDOWN) { UTILS.Link (PasteTextFromClipboard); }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseV (event) {
        let that = this;

        if (CONTROLDOWN) { UTILS.Link (PasteTextFromClipboard); }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function UppercaseX (event) {
        let that = this;

        if (CONTROLDOWN) {
          let inClipbardText= __;
          let updateExClipboard = __;

          UTILS.Link (CopyTextToClipboard);
          UTILS.Link (DeleteSelectionFromFile);

          inClipbardText = UTILS.Link (CLIPBOARD.GetText);
          inClipbardText = inClipbardText.join (UTILS.NEWLINECHAR);
          updateExClipboard = navigator.clipboard.writeText (inClipbardText);

          UTILS.Link (updateExClipboard.then, [ReportUpdateSuccess], updateExClipboard);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

      function LowercaseX (event) {
        let that = this;

        if (CONTROLDOWN) {
          UTILS.Link (CopyTextToClipboard);
          UTILS.Link (DeleteSelectionFromFile);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return __;
      }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define arbitrary internal functions that form the class interface below
  ************************************************************************************/

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetAltState () { return ALTDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetAltGraphState () { return ALTGRAPHDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetControlState () { return CONTROLDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetBgColor () { return BGCOLOR; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFgColor () { return FGCOLOR; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFont () { return FONT; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetKeyFunction (key=__, index=__) {
      let that       = this;
      let keyHandler = __;

      if (UTILS.Link (NonPrintCharacter, [key])) {
        if (index === UTILS.RELEASE) { keyHandler = that.Release [key]; }
        else if (index === UTILS.PRESS) { keyHandler = that.Press [key]; }
      }
      else { keyHandler = that.Printable [key]; }

      return keyHandler;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetLineHeight () { return LINEHEIGHT; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetScrollLockState () { return SCROLLLOCK; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetShiftState () { return SHIFTDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetBgColor (color=__) {
      let that = this;
      BGCOLOR = color;
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetFgColor (color=__) {
      let that = this;
      FGCOLOR = color;
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetFont (font=__) {
      let that = this;
      FONT = font;
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetKeyFunction (key=__, keyHandler=__, index=__) {
      let that = this;

      if (UTILS.Link (NonPrintCharacter, [key])) {
        if (index === UTILS.RELEASE) {
          UTILS.Link (UTILS.MapKeyValue, [that.Release, key, keyHandler]);
        }
        else if (index === UTILS.PRESS) {
          UTILS.Link (UTILS.MapKeyValue, [that.Press, key, keyHandler]);
        }
      }
      else { UTILS.Link (UTILS.MapKeyValue, [that.Printable, key, keyHandler]); }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetLineHeight (height=__) {
      let that = this;
      LINEHEIGHT = height;
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFile () { UTILS.Link (FILEMANAGER.SetFile, [UTILS.WHOLE, FILE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFileCursor () { UTILS.Link (FILEMANAGER.SetFileCursor, [CURSOR]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFileLine () { UTILS.Link (FILEMANAGER.SetFileLine, [LINE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistViewportStart () { UTILS.Link (VIEWPORT.SetSegmentBegin, [FILESEGBEGIN]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistViewportLength () { UTILS.Link (VIEWPORT.SetSegmentEnd, [FILESEGEND]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistViewportLineStart () { UTILS.Link (VIEWPORT.SetLineStart, [LINESTART]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistClipboardCursor () { UTILS.Link (CLIPBOARD.SetCursor, [CURSOR]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistClipboardLine () { UTILS.Link (CLIPBOARD.SetLine, [LINE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFile () { FILE = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFileCursor () { CURSOR = UTILS.Link (FILEMANAGER.GetFileCursor); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFileLine () { LINE = UTILS.Link (FILEMANAGER.GetFileLine); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveViewportStart () { FILESEGBEGIN = UTILS.Link (VIEWPORT.GetSegmentBegin); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveViewportLength () { FILESEGEND = UTILS.Link (VIEWPORT.GetSegmentEnd); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveViewportLineStart () { LINESTART = UTILS.Link (VIEWPORT.GetLineStart); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ReWrite (somewords=__) {
      let that         = this;
      let currententry = __;
      let subline      = __;
      let filesize     = __;
      let words        = somewords;
      let thisline     = FILESEGBEGIN

      if (words === __) { words = FILE; }

      FILESEGSIZE = FILESEGEND;
      filesize = words.length - 1;

      UTILS.Link (PAINTER.BeginPath);
      UTILS.Link (PAINTER.SetFillColorTo, [BGCOLOR]);
      UTILS.Link (PAINTER.ClearPixels);
      UTILS.Link (PAINTER.PaintBackGround);
      UTILS.Link (PAINTER.SetFontTo, [FONT]);
      UTILS.Link (PAINTER.SetFillColorTo, [FGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [that, "x", LMARGIN]);
      UTILS.Link (UTILS.MapKeyValue, [that, "y", TMARGIN]);

      while (thisline <= (FILESEGBEGIN + FILESEGSIZE)) {
        currententry = words [thisline];
        subline = UTILS.Link (LeadWithSpaces, [thisline, filesize]);
        subline = subline + currententry.substring (LINESTART, LINESTART + LINESTOP);
        thisline = thisline + 1;

        UTILS.Link (PAINTER.FillText, [subline], that);
        UTILS.Link (NewLine, _, that);
      }

      UTILS.Link (PAINTER.SetFillColorTo, [BGCOLOR]);
      UTILS.Link (PAINTER.PaintBackGround, [RMARGIN]);
      UTILS.Link (PAINTER.ClosePath);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UpdateDocumentBgColor () {
      let that    = this;
      let html    = UTILS.Link (UTILS.WIN.DOC.querySelector, ["html"], UTILS.WIN.DOC);
      let center  = UTILS.Link (UTILS.WIN.DOC.querySelector, ["center"], UTILS.WIN.DOC);
      let head    = UTILS.Link (UTILS.WIN.DOC.querySelector, ["head"], UTILS.WIN.DOC);
      let body    = UTILS.Link (UTILS.WIN.DOC.querySelector, ["body"], UTILS.WIN.DOC);
      let bgcolor = "backgroundColor";

      UTILS.Link (UTILS.MapKeyValue, [COVER.style, bgcolor, BGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [html.style, bgcolor, BGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [center.style, bgcolor, BGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [head.style, bgcolor, BGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [body.style, bgcolor, BGCOLOR]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GenerateKeyFunctions (from=__, to=__, fn=__) {
      let that = this;
      let key  = __;

      if (from !== __) {
        if (to === __) { to = from; }

        for (let i = from; i <= to; i ++) {
          key = UTILS.Link (UTILS.ToChar, [i]);
          UTILS.Link (UTILS.MapKeyValue, [that, key, fn]);
        }
      }

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
    /************************************************************************************
    * The function which destroys the paper process
    ************************************************************************************/
      let that = this;

      while (that.stack.size > 0) {
        UTILS.Link (STACK.Pop, _, that.stack);
        UTILS.Link (that.stack.popped.abort, _, that.stack.popped);
      }

      UTILS.Link (UpdateDocumentBgColor);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.KBD.KEY.DOWN, UTILS.WIN.SYS], that.Press);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.KBD.KEY.UP, UTILS.WIN.SYS], that.Press);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.WIN.RESIZE, UTILS.WIN.SYS], that.Press);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.MWS.WHEEL, UTILS.Link (PAINTER.GetCanvas)], that.Press);
      UTILS.Link (PAINTER.Destroy, _, that.painter);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;

      LOADER = Loader;
      UTILS  = LOADER.UTILS;

      COVER       = UTILS.Link (LOADER.Import, [LOADER.COVER]);
      CLIPBOARD   = UTILS.Link (LOADER.Import, [LOADER.CLIPBOARD]);
      FILEMANAGER = UTILS.Link (LOADER.Import, [LOADER.FILEMANAGER]);
      PAINTER     = UTILS.Link (LOADER.Import, [LOADER.PAINTER]);
      STACK       = UTILS.Link (LOADER.Import, [LOADER.STACK]);
      VIEWPORT    = UTILS.Link (LOADER.Import, [LOADER.VIEWPORT]);

      Press         = Object.create (_);
      Printable     = Object.create (_);
      Release       = Object.create (_);
      ALTDOWN       = false;
      ALTGRAPHDOWN  = false;
      CONTROLDOWN   = false;
      EXPLAIN       = "explain";
      INSERT        = false;
      LINEHEIGHT    = 17;
      SCROLLLOCK    = false;
      SHIFTDOWN     = false;
      PROGRAMS      = "sys/doc/programs";
      TABSIZE       = 2;
      VIEWCAPACITY  = 0;

      UTILS.Link (DefineNonPrintKeyFunctions);
      UTILS.Link (DefinePrintKeyFunctions);
      UTILS.Link (UTILS.MapKeyValue, [that, "Create", Create]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Destroy", Destroy]);

      UTILS.Link (UTILS.MapKeyValue, [that, "GetAltState", GetAltState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetAltGraphState", GetAltGraphState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetControlState", GetControlState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetBgColor", GetBgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetFgColor", GetFgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetFont", GetFont]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetKeyFunction", GetKeyFunction]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetLineHeight", GetLineHeight]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetScrollLockState", GetScrollLockState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetShiftState", GetShiftState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetBgColor", SetFgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetFgColor", SetFgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetFont", SetFont]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetKeyFunction", SetKeyFunction]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetLineHeight", SetLineHeight]);

      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveFile", RetrieveFile]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveFileCursor", RetrieveFileCursor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveFileLine", RetrieveFileLine]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveViewportStart", RetrieveViewportStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveViewportLength", RetrieveViewportLength]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveViewportLineStart", RetrieveViewportLineStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistFile", PersistFile]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistFileCursor", PersistFileCursor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistFileLine", PersistFileLine]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistViewportStart", PersistViewportStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistViewportLength", PersistViewportLength]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistViewportLineStart", PersistViewportLineStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistClipboardCursor", PersistClipboardCursor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistClipboardLine", PersistClipboardLine]);

      UTILS.Link (UTILS.MapKeyValue, [that, "GenerateKeyFunctions", GenerateKeyFunctions]);
      UTILS.Link (UTILS.MapKeyValue, [that, "JustifyViewport", JustifyViewport]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Press", Press]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Printable", Printable]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Release", Release]);
      UTILS.Link (UTILS.MapKeyValue, [that, "ReWrite", ReWrite]);

      return Object.create (that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    return Loader.UTILS.Link (Objectify, _, paper);
  }

  return loader.UTILS.Link (MakePaperName, [loader], paperspace);
}