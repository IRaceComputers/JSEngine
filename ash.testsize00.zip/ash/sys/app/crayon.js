/****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeCrayonNameSpace (loader) {
  "use strict";

  let crayonspace = Object.create (null);

  function MakeCrayonName (Loader=undefined) {
    let crayon = this;
    let _      = null;
    let __     = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let BGCOLOR     = __;
    let BROWSER     = __;
    let COVER       = __;
    let DECIMAL     = __;
    let PAPER       = __;
    let EXIT        = __;
    let FGCOLOR     = __;
    let FILE        = __;
    let FILEMANAGER = __;
    let GEOMETER    = __;
    let GRID        = __;
    let LOADER      = __;
    let PAINTER     = __;
    let SCREEN      = __;
    let STACK       = __;
    let UTILS       = __;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=__) {
      let that = this;

      BGCOLOR     = info.bgcolor;
      EXIT        = info.escape;
      FGCOLOR     = info.fgcolor;

      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
      UTILS.Link (UTILS.MapKeyValue, [that, "paper", Object.create (_)]);
      UTILS.Link (PAPER.Create, [info], that.paper);
      UTILS.Link (GEOMETER.Create, [info], that);
      UTILS.Link (Customize, _, that);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatcrayon     = this;
      let that           = thatcrayon.paper;
      let commandHandler = Object.create (_);
      let ENTER          = UTILS.KBD.KEY.ENTER;
      let oldFunction    = UTILS.Link (PAPER.GetKeyFunction, [ENTER, UTILS.PRESS], that);
      let newFunction    = UTILS.Link (MakeNewEnter, [oldFunction], thatcrayon);

      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "command", ".create."]);
      UTILS.Link (UTILS.MapKeyValue, [commandHandler, "handler", Make.bind (thatcrayon)]);
      UTILS.Link (PAPER.SetKeyFunction, [ENTER, newFunction, UTILS.PRESS], that); 
      UTILS.Link (BROWSER.Create, [commandHandler], thatcrayon);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewEnter (oldEnter=__) {
      let thatcrayon = this;

      function Enter () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that    = this;
        let Command = __;
        let opline  = __;

        FILE    = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]);
        opline  = FILE [FILE.length - 1].trim (). split (UTILS.KBD.KEY.WHITESPACE);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, opline]);
        opline  = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, opline]);
        Command = UTILS.Link (BROWSER.Recorded, [opline[0]], thatcrayon);

        if (Command !== __) { UTILS.Link (Command, [FILE, UTILS.KBD.KEY.WHITESPACE]); }
        else { UTILS.Link (oldEnter, _, that); }

        return __;
      }

      return Enter;
    };
 
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Make () {
      let thatcrayon = this;
      let TYPE       = 0;
      let components = __;
      let structures = __;
      let type       = __;
      let Structure  = __;

      structures = UTILS.Link (GEOMETER.CloneStructures, [FILE], thatcrayon);
      structures = UTILS.Link (GEOMETER.CleanStructures, [structures]);
      BGCOLOR    = UTILS.Link (PAPER.GetBgColor);

      UTILS.Link (GEOMETER.SetBgColor, [BGCOLOR]);
      UTILS.Link (GEOMETER.ClearBackground, _, thatcrayon);

      for (let i =  0; i < structures.length; i ++) {
        components = structures [i];
        type       = components [TYPE];
        Structure  = UTILS.Link (GEOMETER.GetStructure, [type]);

        if (Structure !== __) {
          UTILS.Link (Structure, [components], thatcrayon);
        }
      }

      UTILS.Link (UTILS.MapKeyValue, [thatcrayon.paper, "requireRewrite", false]);

      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;
      UTILS.Link (PAPER.Destroy, _, that);
      return __;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;

      LOADER  = Loader;
      UTILS   = LOADER.UTILS;

      BROWSER     = UTILS.Link (LOADER.Import, [LOADER.BROWSER]);
      COVER       = UTILS.Link (LOADER.Import, [LOADER.COVER]);
      DECIMAL     = UTILS.Link (LOADER.Import, [LOADER.DECIMAL]);
      FILEMANAGER = UTILS.Link (LOADER.Import, [LOADER.FILEMANAGER]);
      GEOMETER    = UTILS.Link (LOADER.Import, [LOADER.GEOMETER]);
      GRID        = UTILS.Link (LOADER.Import, [LOADER.GRID]);
      PAINTER     = UTILS.Link (LOADER.Import, [LOADER.PAINTER]);
      PAPER       = UTILS.Link (LOADER.Import, [LOADER.PAPER]);
      SCREEN      = UTILS.Link (LOADER.Import, [LOADER.SCREEN]);
      STACK       = UTILS.Link (LOADER.Import, [LOADER.STACK]);

      UTILS.Link (UTILS.MapKeyValue, [crayon, "Create", Create]);
      UTILS.Link (UTILS.MapKeyValue, [crayon, "Destroy", Destroy]);

      return Object.create (that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    return Loader.UTILS.Link (Objectify, _, crayon);
  }

  return loader.UTILS.Link (MakeCrayonName, [loader], crayonspace);
}