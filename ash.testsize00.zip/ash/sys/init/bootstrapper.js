/****************************************************************
    Bootstrapper initiates the ASH suite when the window is ready for use.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/***********************************************************************************
* Well, we want to bootstrap the suite iff everything has been loaded ...
* ... it is not going to be _that_ great if it bootstraps prematurely.
/***********************************************************************************/
let bs = Object.create (null);

bs ["bubble"] = false;
bs ["event"]  = "DOMContentLoaded";
bs [bs.event] = Bootstrapper.bind (bs);

window.addEventListener (bs.event, bs [bs.event], bs.bubble);

/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/
/********************************************************************************************************************/

/****
* the bootstrapping function ...
**/
function Bootstrapper () {
  "use strict";

  let that = this;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  let loader    = Object.create (null);
  let info      = Object.create (null);
  let include   = new Array ();
  let UTILS     = MakeUtilityNameSpace ();
  let LOADER    = UTILS.Link (MakeLoaderNameSpace, [UTILS]);
  let ID        = "begin";
  let FSTABLE   = "/sys/doc/filerecords";
  let INIT      = undefined;
  let APP       = undefined;
  let PROCESS   = undefined;
  let DIRECTORY = undefined;

  include.push (1);
  include.push (2);
  include.push (3);
  include.push (6);
  include.push (8);
  include.push (9);
  include.push (10);
  include.push (11);
  include.push (12);
  include.push (13);
  include.push (14);

  UTILS.Link (UTILS.RemoveHandlerFor, [that.event, UTILS.WIN.SYS, that.bubble], that);
  UTILS.Link (UTILS.MapKeyValue, [info, "fstable", FSTABLE]);
  UTILS.Link (UTILS.MapKeyValue, [info, "id", ID]);
  UTILS.Link (UTILS.MapKeyValue, [info, "include", include]);
  UTILS.Link (LOADER.Create, [info], loader);

  INIT      = UTILS.Link (LOADER.Import, [LOADER.INITIATE]);
  APP       = UTILS.Link (LOADER.Import, [LOADER.APP]);
  PROCESS   = UTILS.Link (LOADER.Import, [LOADER.PROCESS]);
  DIRECTORY = APP [2];

  UTILS.Link (INIT [DIRECTORY], null, PROCESS [DIRECTORY]);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  return undefined;
}