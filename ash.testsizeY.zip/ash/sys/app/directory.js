/****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakeNullTermNameSpace (utils) {
  "use strict";

  let nulltermspace = Object.create (null);
  let NullTerm      = undefined;

  function MakeNullTermName (Utils=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    let nullterm       = Object.create (null);
    let BGCOLOR        = undefined;
    let COVER          = undefined;
    let CURSOR         = undefined;
    let PAPER          = undefined;
    let EXIT           = undefined;
    let FILE           = undefined;
    let FILEMANAGER    = undefined;
    let FGCOLOR        = undefined;
    let FONT           = undefined;
    let INITIATE       = undefined;
    let INITDATA       = undefined;
    let LINE           = undefined;
    let LOOP           = undefined;
    let PAINTER        = undefined;
    let PROCESS        = undefined;
    let PressControl   = undefined;
    let PressEnter     = undefined;
    let PressShift     = undefined;
    let ReleaseControl = undefined;
    let ReleaseShift   = undefined;
    let SCREEN         = undefined;
    let ScrollLock     = undefined;
    let SERVER         = undefined;
    let UTILS          = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/ 

    function Create (info=undefined) {
      let that = this;

      BGCOLOR        = info.bgcolor;
      COVER          = info.cover;
      PAPER          = info.paper;
      EXIT           = info.escape;
      FGCOLOR        = info.fgcolor;
      FILEMANAGER    = info.filemanager;
      INITDATA       = info.initdata;
      INITIATE       = info.initiate;
      PAINTER        = info.painter;
      PROCESS        = info.process;
      SERVER         = PROCESS [info.id];
      SCREEN         = info.screen;
      PressEnter     = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.ENTER, UTILS.PRESS], PAPER);
      PressControl   = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], PAPER);
      PressShift     = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.PRESS], PAPER);
      ReleaseControl = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], PAPER);
      ReleaseShift   = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.RELEASE], PAPER);
      ScrollLock     = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, UTILS.RELEASE], PAPER);

      if (info.font !== undefined) { FONT = info.font; }

      UTILS.Link (UTILS.MapKeyValue, [that, "paper", Object.create (null)]);
      UTILS.Link (UTILS.MapKeyValue, [that.paper, "exists", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
      UTILS.Link (PAPER.Create, [info], that.paper);
      UTILS.Link (Customize, null, that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Customize () {
      let thatnullterm = this;
      let that         = thatnullterm.paper;
      let ENTER        = UTILS.KBD.KEY.ENTER;
      let ESCAPE       = UTILS.KBD.KEY.ESCAPE;
      let HELP         = UTILS.KBD.KEY.F1;
      let RELOAD       = UTILS.KBD.KEY.F5;
      let oldFunction  = UTILS.Link (PAPER.GetKeyFunction, [HELP, UTILS.PRESS], that);
      let newFunction  = UTILS.Link (MakeNewHelp, [oldFunction], that);

      UTILS.Link (PAPER.SetKeyFunction, [HELP, newFunction, UTILS.PRESS], that);

      newFunction = UTILS.WIN.SYS.location.reload.bind (UTILS.WIN.SYS);

      UTILS.Link (PAPER.SetKeyFunction, [RELOAD, newFunction, UTILS.PRESS], that)

      newFunction = UTILS.Link (MakeNewEscape, null, thatnullterm);

      UTILS.Link (PAPER.SetKeyFunction, [ESCAPE, newFunction, UTILS.RELEASE], that);

      newFunction = CommandRecognition.bind (thatnullterm);

      UTILS.Link (PAPER.SetKeyFunction, [ENTER, newFunction, UTILS.PRESS], that)

      return undefined;
    }

  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/
  
    function MakeNewEscape () {
      let that          = this;
      let defaultEscape = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.ESCAPE, UTILS.RELEASE], that.paper);

      if (defaultEscape === undefined) { return LoopBack.bind (that); }
      else { return Escape.bind (that); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LoopBack () {
      let that             = this;
      let parent           = "nullterm";
      let End              = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], that.paper);
      let Enter            = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.ENTER, UTILS.PRESS], that.paper);
      let ScrollLock       = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, UTILS.RELEASE], that.paper);
      let ctrlKeyDown      = UTILS.Link (PAPER.GetControlState);
      let scrollLockActive = UTILS.Link (PAPER.GetScrollLockState);

      if (!ctrlKeyDown) { UTILS.Link (PressControl, null, that.paper); }

      UTILS.Link (End, null, that.paper);

      if (!ctrlKeyDown) { UTILS.Link (ReleaseControl, null, that.paper); }
      if (scrollLockActive) { UTILS.Link (ScrollLock, null, that.paper); }

      UTILS.Link (Enter, null, that.paper);

      if (scrollLockActive) { UTILS.Link (ScrollLock, null, that.paper); }

      if (LOOP) {
        UTILS.Link (PAPER.PersistFile);
        UTILS.Link (PAPER.PersistFileLine);

        FILE = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]);
        LINE = UTILS.Link (FILEMANAGER.GetFileLine);

        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, parent]);

        CURSOR = FILE [LINE].length;

        UTILS.Link (FILEMANAGER.SetFile, [UTILS.WHOLE, FILE]);
        UTILS.Link (FILEMANAGER.SetFileCursor, [CURSOR]);
        UTILS.Link (PAPER.RetrieveFile);
        UTILS.Link (PAPER.RetrieveFileCursor);
        UTILS.Link (CommandRecognition, null, that);
      }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Escape () {
      let that      = this;
      let date      = new Date ();
      let exitText  = new Array ();
      let finaltext = UTILS.BLANKCHAR;
      let bgcolor   = "backgroundColor";
      let p         = "p";
      let lb        = "br";
      let paragraph = undefined;
      let linebreak = undefined;

      exitText.push ("<br/><br/><br/><br/>");
      exitText.push ("<p>Press [F5] or [CTRL]+[R] to start</p>");
      exitText.push ("<br/><br/>");
      exitText.push ("<p>Press [CTRL]+[W] to exit.</p>");
      exitText.push ("<br/><br/>");
      exitText.push ("<p>Ancient Creations &trade;</p>");
      exitText.push ("<br/><br/>");
      exitText.push ("<p>ASH &copy; 2021</p>");

      for (let i = 0; i < exitText.length; i ++) { finaltext = finaltext + exitText [i]; }

      UTILS.Link (UTILS.MapKeyValue, [COVER, "innerHTML", finaltext]);

      paragraph = UTILS.Link (UTILS.WIN.DOC.querySelectorAll, [p], UTILS.WIN.DOC);
      linebreak = UTILS.Link (UTILS.WIN.DOC.querySelectorAll, [lb], UTILS.WIN.DOC);

      for (let i = 0; i < paragraph.length; i ++) {
        UTILS.Link (UTILS.MapKeyValue, [paragraph [i].style, bgcolor, UTILS.Link (PAPER.GetBgColor)]);
      }
      for (let i = 0; i < linebreak.length; i ++) {
        UTILS.Link (UTILS.MapKeyValue, [linebreak [i].style, bgcolor, UTILS.Link (PAPER.GetBgColor)]);
      }

      return UTILS.Link (Destroy, null, that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function fakeEscape () { return undefined; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=undefined) {
      let thatpaper = this;
      let End = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], PAPER);

      function Help (event=undefined) {
        let that             = this;
        let scrollLockActive = UTILS.Link (PAPER.GetScrollLockState);
        let ctrlKeyDown      = UTILS.Link (PAPER.GetControlState);

        if (scrollLockActive) { UTILS.Link (ScrollLock, null, that); }

        if (!ctrlKeyDown) { UTILS.Link (PressControl, null, that) }

        UTILS.Link (End, null, that);

        if (!ctrlKeyDown) { UTILS.Link (ReleaseControl, null, that) }

        UTILS.Link (PressEnter, null, that);
        UTILS.Link (Helper, [event, fakeEscape], that);
        UTILS.Link (CommandRecognition, null, SERVER);

        if (scrollLockActive) { UTILS.Link (ScrollLock, null, that); }

        return undefined;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function History () {
      let that             = this;
      let ellipsis         = "...";
      let ArrowUp          = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.ARROWUP, UTILS.PRESS], PAPER);
      let Backspace        = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, UTILS.PRESS], PAPER);
      let End              = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], PAPER);
      let Enter            = UTILS.Link (PAPER.GetKeyFunction, [UTILS.KBD.KEY.ENTER, UTILS.PRESS], PAPER);
      let ctrlKeyDown      = UTILS.Link (PAPER.GetControlState);
      let scrollLockActive = UTILS.Link (PAPER.GetScrollLockState);
      let shiftKeyDown     = UTILS.Link (PAPER.GetShiftState);
      let tmp              = undefined;

      UTILS.Link (Backspace, null, that.paper);

      if (!shiftKeyDown) { UTILS.Link (PressShift, null, that); }

      UTILS.Link (Backspace, null, that.paper);

      if (!shiftKeyDown) { UTILS.Link (ReleaseShift, null, that.paper); }

      UTILS.Link (Enter, null, that.paper);
      UTILS.Link (Enter, null, that.paper);

      if (ctrlKeyDown) { UTILS.Link (ReleaseControl, null, that.paper); }
      if (shiftKeyDown) { UTILS.Link (ReleaseShift, null, that.paper); }

      UTILS.Link (ArrowUp, null, that.paper);

      if (ctrlKeyDown) { UTILS.Link (PressControl, null, that); }
      if (shiftKeyDown) { UTILS.Link (PressShift, null, that); }

      UTILS.Link (PAPER.PersistFile);
      UTILS.Link (PAPER.PersistFileLine);
      UTILS.Link (PAPER.PersistFileCursor);

      FILE = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]);
      LINE = UTILS.Link (FILEMANAGER.GetFileLine);

      UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, ellipsis]);

      for (let i = 0; i < that.history.length; i ++) {
        tmp = FILE [LINE] + UTILS.KBD.KEY.WHITESPACE + that.history [i];
        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, tmp]);
      }

      UTILS.Link (FILEMANAGER.SetFile, [UTILS.WHOLE, FILE]);
      UTILS.Link (FILEMANAGER.SetFileLine, [FILE.length - 1]);
      UTILS.Link (FILEMANAGER.SetFileCursor, [0]);
      UTILS.Link (PAPER.RetrieveFile);
      UTILS.Link (PAPER.RetrieveFileLine);
      UTILS.Link (PAPER.RetrieveFileCursor);

      if (!ctrlKeyDown) { UTILS.Link (PressControl, null, that); }

      UTILS.Link (End, null, that.paper);

      if (!ctrlKeyDown) { UTILS.Link (ReleaseControl, null, that.paper); }

      UTILS.Link (PAPER.PersistViewportStart);
      UTILS.Link (PAPER.PersistViewportLength);
      UTILS.Link (PAPER.PersistViewportLineStart);
      UTILS.Link (PAPER.ReWrite, null, that.paper);

      if (scrollLockActive) { UTILS.Link (ScrollLock, null, that); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    /********************************************************
    * Command Recognition and Application Loader
    /*******************************************************/
    function CommandRecognition () {
      let that     = this;
      let command  = 0;
      let readfile = 1;
      let identity = "id";
      let lastline = UTILS.Link (FILEMANAGER.GetFileSize) - 1;

      FILE     = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]);
      lastline = FILE [lastline].trim ();
      lastline = lastline.split (UTILS.KBD.KEY.WHITESPACE);
      lastline = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, lastline]);
      lastline = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, lastline]);
      command  = lastline [command];
      readfile = lastline [readfile];
      LOOP     = true;

      if (PROCESS [command] !== undefined) {
        that.history.push (INITDATA [command][identity]);

        LOOP = false;

        if (that.exceptional [command] === undefined) { UTILS.Link (Destroy, null, that); }

        UTILS.Link (INITIATE [command], [readfile], PROCESS [command]);
      }
      else { UTILS.Link (PressEnter); }

      UTILS.Link (PAPER.PersistFile);
      UTILS.Link (PAPER.PersistFileLine);
      UTILS.Link (PAPER.PersistFileCursor);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
      let that = this;

      that.paper.exists = false;

      UTILS.Link (PAPER.Destroy, null, that.paper);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;

      UTILS = Utils;

      UTILS.Link (UTILS.MapKeyValue, [that, "Create", Create]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Destroy", Destroy]);
      UTILS.Link (UTILS.MapKeyValue, [that, "CommandRecognition", CommandRecognition]);
      UTILS.Link (UTILS.MapKeyValue, [that, "History", History]);

      return Object.create (that);
    }

    return Utils.Link (Objectify, null, nullterm);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  NullTerm = utils.Link (MakeNullTermName, [utils], nulltermspace);

  return NullTerm;
}
