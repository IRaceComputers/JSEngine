 /****************************************************************
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>.

    Copyright (C) 2021 Sbabalwe Mchasa gmeta07@gmail.com.

****************************************************************/
function MakePaperNameSpace (utils, viewport) {
  "use strict";

  let paperspace = Object.create (null);

  function MakePaperName (Utils=undefined, ViewPort=undefined) {

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
    let paper = this;
    /************************************************************************************
    * keyboard functions/objects
    ************************************************************************************/
    let _         = undefined;
    let Action    = undefined;
    let Printable = undefined;
    let Release   = undefined;
    let EXIT      = undefined;
    /************************************************************************************
    * keyboard key state modifiers
    ************************************************************************************/
    let ALTDOWN      = undefined;
    let ALTGRAPHDOWN = undefined;
    let CONTROLDOWN  = undefined;
    let INSERT       = undefined;
    let SCROLLLOCK   = undefined;
    let SHIFTDOWN    = undefined;
    /************************************************************************************
    * class objects
    ************************************************************************************/
    let CLIPBOARD   = undefined;
    let FILEMANAGER = undefined;
    let PAINTER     = undefined;
    let STACK       = undefined;
    let UTILS       = undefined;
    let VIEWPORT    = undefined;
    /************************************************************************************
    * filemanager states
    ************************************************************************************/
    let CURSOR = undefined;
    let FILE   = undefined;
    let LINE   = undefined;
    /************************************************************************************
    * viewport states
    ************************************************************************************/
    let FONT          = undefined;
    let LINEHEIGHT    = undefined;
    let FILESEGSIZE   = undefined;
    let FILESEGBEGIN  = undefined;
    let FILESEGEND    = undefined;
    let LINESTART     = undefined;
    let LINESTOP      = undefined;
    let TMARGIN       = undefined;
    let LMARGIN       = undefined;
    let BMARGIN       = undefined;
    let RMARGIN       = undefined;
    let VIEWCAPACITY  = undefined;
    /************************************************************************************
    * paper global variables
    ************************************************************************************/
    let COVER    = undefined;
    let EXPLAIN  = undefined;
    let BGCOLOR  = undefined;
    let FGCOLOR  = undefined;
    let HELP     = undefined;
    let PROGRAMS = undefined;
    let TABSIZE  = undefined;

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Create (info=undefined) {
    /************************************************************************************
    * The function which creates the paper process
    ************************************************************************************/
      let that = this;

      CLIPBOARD   = info.clipboard;
      FILEMANAGER = info.filemanager;
      PAINTER     = info.painter;
      STACK       = info.stack;
      EXIT        = info.escape;
      COVER       = info.cover;
      HELP        = info.help;
      CURSOR      = 0;
      LINE        = 0;
      TMARGIN     = 20;
      LMARGIN     = 20;
      BMARGIN     = info.height - TMARGIN;
      RMARGIN     = info.width - 10*LMARGIN;
      LINESTART   = 0;
      LINESTOP    = 120;

      if (BGCOLOR === undefined) { UTILS.Link (SetBgColor, [info.bgcolor]); }
      if (FGCOLOR === undefined) { UTILS.Link (SetFgColor, [info.fgcolor]); }
      if (FONT === undefined) { UTILS.Link (SetFont, [info.font]); }

      UTILS.Link (UTILS.MapKeyValue, [that, "id", info.id]);
    /************************************************************************************
    * create painter
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "painter", Object.create (_)]);
      UTILS.Link (UTILS.MapKeyValue, [info, "painterInfo", Object.create (_)]);
      UTILS.Link (UTILS.MapKeyValue, [info.painterInfo, "id", info.id]);
      UTILS.Link (UTILS.MapKeyValue, [info.painterInfo, "cover", info.cover]);
      UTILS.Link (UTILS.MapKeyValue, [info.painterInfo, "height", UTILS.WIN.SYS.innerHeight - 20]);
      UTILS.Link (UTILS.MapKeyValue, [info.painterInfo, "width", UTILS.WIN.SYS.innerWidth  - 20]);
      UTILS.Link (PAINTER.Create, [info.painterInfo], that.painter);
    /************************************************************************************
    * create stack
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "stack", Object.create (_)]);
      UTILS.Link (STACK.Create, _, that.stack);
    /************************************************************************************
    * initialize viewport
    ************************************************************************************/
      UTILS.Link (VIEWPORT.SetTopMargin, [TMARGIN]);
      UTILS.Link (VIEWPORT.SetLeftMargin, [LMARGIN]);
      UTILS.Link (VIEWPORT.SetBottomMargin, [BMARGIN]);
      UTILS.Link (VIEWPORT.SetRightMargin, [RMARGIN]);
      UTILS.Link (VIEWPORT.SetLineStop, [LINESTOP]);
    /************************************************************************************
    * customize paper
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "Action", Object.create (Action)]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Printable", Object.create (Printable)]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Release", Object.create (Release)]);
      UTILS.Link (Customize, _, that);
    /********************************************************************************************************************/
      UTILS.Link (CalculateViewCapacity);
    /************************************************************************************
    * read help file
    ************************************************************************************/
      UTILS.Link (FILEMANAGER.Read, [HELP], that);
    /********************************************************************************************************************/
    /************************************************************************************
    * set system flags
    ************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that, "editing", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
 
    function Customize () {
      let that    = this;
      let HELP    = UTILS.KBD.KEY.F1;
      let oldHelp = UTILS.Link (GetKeyFunction, [HELP, UTILS.PRESS], that);
      let newHelp = UTILS.Link (MakeNewHelp, [oldHelp], that);

      UTILS.Link (UpdateDocumentBgColor);
    /********************************************************************************************************************/
      UTILS.Link (SetKeyFunction, [UTILS.KBD.KEY.ESCAPE, EXIT, UTILS.RELEASE], that);
      UTILS.Link (SetKeyFunction, [HELP, newHelp, UTILS.PRESS], that);
      UTILS.Link (SetKeyFunction, [UTILS.KBD.KEY.INTERNALCALL, UseFileContents, UTILS.PRESS], that);
    /********************************************************************************************************************/
      UTILS.Link (UTILS.MapKeyValue, [that.Action, UTILS.KBD.KEY.DOWN, KeydownHandler.bind (that)]);
      UTILS.Link (UTILS.MapKeyValue, [that.Action, UTILS.KBD.KEY.UP, KeyupHandler.bind (that)]);
      UTILS.Link (UTILS.MapKeyValue, [that.Action, UTILS.WIN.RESIZE, ResizeHandler.bind (that)]);
      UTILS.Link (UTILS.MapKeyValue, [that.Action, UTILS.MWS.WHEEL, MouseWheelScrollHandler.bind (that)]);
    /********************************************************************************************************************/
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.KBD.KEY.DOWN, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.KBD.KEY.UP, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.WIN.RESIZE, UTILS.WIN.SYS] , that.Action);
      UTILS.Link (UTILS.AddHandlerFor, [UTILS.MWS.WHEEL, UTILS.Link (PAINTER.GetCanvas)], that.Action);

      return undefined;
     }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UseFileContents (event=undefined) {
      let that = this;

      UTILS.Link (RetrieveFile);
      UTILS.Link (RetrieveFileLine);
      UTILS.Link (RetrieveFileCursor);

      FILESEGBEGIN = 0;
      FILESEGEND = LINE;
      LINESTART = FILESEGBEGIN;

      if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
      if (LINE >= VIEWCAPACITY) {
        FILESEGBEGIN = LINE - VIEWCAPACITY;
        FILESEGEND = VIEWCAPACITY;
      }

      UTILS.Link (PersistClipboardCursor);
      UTILS.Link (PersistClipboardLine);
      UTILS.Link (PersistViewportStart);
      UTILS.Link (PersistViewportLength);
      UTILS.Link (PersistViewportLineStart);
      UTILS.Link (ReWrite, _, that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MakeNewHelp (Helper=undefined) {
      let thatpaper = this;

      function Help (event=undefined, otherEscape=undefined) {
        let that           = this;
        let End            = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], thatpaper);
        let Enter          = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ENTER, UTILS.PRESS], thatpaper);
        let Escape         = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ESCAPE, UTILS.RELEASE], thatpaper);
        let PressControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], thatpaper);
        let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], thatpaper);

        if (otherEscape !== undefined) { Escape = otherEscape; }

        UTILS.Link (PersistFile);
        UTILS.Link (PersistFileLine);
        UTILS.Link (PersistFileCursor);
        UTILS.Link (PressControl, _, that);
        UTILS.Link (End, _, that);
        UTILS.Link (ReleaseControl, _, that);
        UTILS.Link (Enter, _, that);
        UTILS.Link (Helper, _, that);
        UTILS.Link (Escape, _, that);

        return undefined;
      }

      return Help;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LeadWithSpaces (number=undefined, max=undefined) {
      let paddedValue = number + UTILS.KBD.KEY.WHITESPACE;
      let maxlength = (UTILS.BLANKCHAR + max).length;
      let blocks = 1 + maxlength - paddedValue.length;

      while (blocks > 0) {
        paddedValue = UTILS.KBD.KEY.WHITESPACE + paddedValue;
        blocks = blocks - 1;
      }

      return paddedValue;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ReWrite (somewords=undefined) {
      let that         = this;
      let currententry = undefined;
      let subline      = undefined;
      let filesize     = undefined;
      let words        = somewords;
      let thisline     = FILESEGBEGIN

      if (words === undefined) { words = FILE; }

      FILESEGSIZE = FILESEGEND;
      filesize = words.length - 1;

      UTILS.Link (PAINTER.BeginPath);
      UTILS.Link (PAINTER.SetFillColorTo, [BGCOLOR]);
      UTILS.Link (PAINTER.ClearPixels);
      UTILS.Link (PAINTER.PaintBackGround);
      UTILS.Link (PAINTER.SetFontTo, [FONT]);
      UTILS.Link (PAINTER.SetFillColorTo, [FGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [that, "x", LMARGIN]);
      UTILS.Link (UTILS.MapKeyValue, [that, "y", TMARGIN]);

      while (thisline <= (FILESEGBEGIN + FILESEGSIZE)) {
        currententry = words [thisline];
        subline = UTILS.Link (LeadWithSpaces, [thisline, filesize]);
        subline = subline + currententry.substring (LINESTART, LINESTART + LINESTOP);
        thisline = thisline + 1;

        UTILS.Link (PAINTER.FillText, [subline], that);
        UTILS.Link (NewLine, _, that);
      }

      UTILS.Link (PAINTER.SetFillColorTo, [BGCOLOR]);
      UTILS.Link (PAINTER.PaintBackGround, [RMARGIN]);
      UTILS.Link (PAINTER.ClosePath);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define arbitrary internal functions below
  ************************************************************************************/

    function NewLine () {
    /************************************************************************************
    * The function which moves the cursor to the next line on the kanvas 
    ************************************************************************************/
      let that = this;
      UTILS.Link (UTILS.MapKeyValue, [that, "y", that.y + LINEHEIGHT]);
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SkipWordMoveCursor (spaceCharSide=undefined) {
      let that  = this;
      let chars = undefined;
      let line  = undefined;
      let LEFT  = 0;
      let RIGHT = 1;

      line = FILE [LINE];

      if ((LEFT === spaceCharSide) || (spaceCharSide === RIGHT)) {
        if (spaceCharSide === RIGHT) {
          for (let o = CURSOR; o <= line.length - 2; o ++) {
            chars = line.substring (o, o+2);

            if ((chars.charAt (RIGHT) === UTILS.KBD.KEY.WHITESPACE) && (chars.charAt (LEFT) !== UTILS.KBD.KEY.WHITESPACE)) {
              return (o+1);
            }
          }

          return line.length;
        }
        else {
          for (let o = CURSOR; o >= 2; o --) {
            chars = line.substring (o-2, o);

            if ((chars.charAt (LEFT) === UTILS.KBD.KEY.WHITESPACE) && (chars.charAt (RIGHT) !== UTILS.KBD.KEY.WHITESPACE)) {
              return (o-1);
            }
          }

          return LEFT;
        }
      }

      return (-RIGHT);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function TextSelected () {
      let fromLine = UTILS.Link (CLIPBOARD.GetLine);
      let fromCursor = UTILS.Link (CLIPBOARD.GetCursor);
      let differentLines = (fromLine !== LINE);
      let differentCursors = (fromCursor !== CURSOR);

      return (differentLines || differentCursors);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DeleteSelectionFromFile () {
      let fromLine = UTILS.Link (CLIPBOARD.GetLine);
      let fromCursor = UTILS.Link (CLIPBOARD.GetCursor);
      let toLine = fromLine;
      let toCursor = fromCursor;
      let shorterFile = new Array ();
      let differentLines = undefined;
      let differentCursors = undefined;

      if (fromLine !== LINE) {
        if (fromLine > LINE) {
          fromLine = LINE;
          fromCursor = CURSOR;
        }
        else {
          toLine = LINE;
          toCursor = CURSOR;
        }

        FILE [fromLine] = FILE [fromLine].substring (0, fromCursor);
        FILE [toLine] = FILE [toLine].substring (toCursor, FILE [toLine].length);

        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, (FILE [fromLine] + FILE [toLine])]);
      }
      else {
        let sublineA = FILE [fromLine];
        let sublineB = FILE [toLine];

        toCursor = CURSOR;

        if (fromCursor > toCursor) {
          fromCursor = fromCursor + toCursor;
          toCursor = fromCursor - toCursor;
          fromCursor = fromCursor - toCursor;
        }

        sublineA = sublineA.substring (0, fromCursor);
        sublineB = sublineB.substring (toCursor, sublineB.length);

        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, (sublineA + sublineB)]);
      }

      LINE = fromLine;
      CURSOR = fromCursor;
      differentCursors = (fromCursor !== toCursor);
      differentLines = (fromLine !== toLine);

      if (differentLines || differentCursors) {
        for (let i = 0; i <FILE.length; i ++) {
          if ((i <= fromLine) || (i > toLine)) { shorterFile.push (FILE [i]); }
        }

        FILE = shorterFile;

        if (FILE.length < VIEWCAPACITY) { FILESEGEND = (FILESEGBEGIN + FILE.length) - 1; }
      }
//      console.table (FILE);
//      console.trace (FILE);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function InvisibleCharacter (key=undefined) {
    /************************************************************************************
    * The function which determines whether a character is non-printable 
    ************************************************************************************/
      let invisibility = false;

      switch (key) {
        case UTILS.KBD.KEY.ALT                : invisibility = true; break;
        case UTILS.KBD.KEY.ALTGRAPH           : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWDOWN          : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWLEFT          : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWRIGHT         : invisibility = true; break;
        case UTILS.KBD.KEY.ARROWUP            : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEDOWN    : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEMUTE    : invisibility = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEUP      : invisibility = true; break;
        case UTILS.KBD.KEY.BACKSPACE          : invisibility = true; break;
        case UTILS.KBD.KEY.CAPSLOCK           : invisibility = true; break;
        case UTILS.KBD.KEY.CONTROL            : invisibility = true; break;
        case UTILS.KBD.KEY.CONTEXTMENU        : invisibility = true; break;
        case UTILS.KBD.KEY.DELETE             : invisibility = true; break;
        case UTILS.KBD.KEY.END                : invisibility = true; break;
        case UTILS.KBD.KEY.ENTER              : invisibility = true; break;
        case UTILS.KBD.KEY.ESCAPE             : invisibility = true; break;
        case UTILS.KBD.KEY.F1                 : invisibility = true; break;
        case UTILS.KBD.KEY.F2                 : invisibility = true; break;
        case UTILS.KBD.KEY.F3                 : invisibility = true; break;
        case UTILS.KBD.KEY.F4                 : invisibility = true; break;
        case UTILS.KBD.KEY.F5                 : invisibility = true; break;
        case UTILS.KBD.KEY.F6                 : invisibility = true; break;
        case UTILS.KBD.KEY.F7                 : invisibility = true; break;
        case UTILS.KBD.KEY.F8                 : invisibility = true; break;
        case UTILS.KBD.KEY.F9                 : invisibility = true; break;
        case UTILS.KBD.KEY.F10                : invisibility = true; break;
        case UTILS.KBD.KEY.F11                : invisibility = true; break;
        case UTILS.KBD.KEY.F12                : invisibility = true; break;
        case UTILS.KBD.KEY.HOME               : invisibility = true; break;
        case UTILS.KBD.KEY.INSERT             : invisibility = true; break;
        case UTILS.KBD.KEY.INTERNALCALL       : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIAPLAY          : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIATRACKNEXT     : invisibility = true; break;
        case UTILS.KBD.KEY.MEDIATRACKPREVIOUS : invisibility = true; break;
        case UTILS.KBD.KEY.NUMLOCK            : invisibility = true; break;
        case UTILS.KBD.KEY.OS                 : invisibility = true; break;
        case UTILS.KBD.KEY.PAGEDOWN           : invisibility = true; break;
        case UTILS.KBD.KEY.PAGEUP             : invisibility = true; break;
        case UTILS.KBD.KEY.SHIFT              : invisibility = true; break;
        case UTILS.KBD.KEY.SCROLLLOCK         : invisibility = true; break;
        case UTILS.KBD.KEY.TAB                : invisibility = true; break;
        case UTILS.KBD.KEY.UNIDENTIFIED       : invisibility = true; break;
      }

      return invisibility;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CommandCharacter (key=undefined) {
    /************************************************************************************
    * The function which determines whether a character is treated as a command 
    ************************************************************************************/
      let status = false;

      switch (key) {
        case UTILS.KBD.KEY.ALT                : status = true; break;
        case UTILS.KBD.KEY.ALTGRAPH           : status = true; break;
        case UTILS.KBD.KEY.ARROWDOWN          : status = true; break;
        case UTILS.KBD.KEY.ARROWLEFT          : status = true; break;
        case UTILS.KBD.KEY.ARROWRIGHT         : status = true; break;
        case UTILS.KBD.KEY.ARROWUP            : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEDOWN    : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEMUTE    : status = true; break;
        case UTILS.KBD.KEY.AUDIOVOLUMEUP      : status = true; break;
        case UTILS.KBD.KEY.BACKSPACE          : status = true; break;
        case UTILS.KBD.KEY.CONTEXTMENU        : status = true; break;
        case UTILS.KBD.KEY.CONTROL            : status = true; break;
        case UTILS.KBD.KEY.DELETE             : status = true; break;
        case UTILS.KBD.KEY.ENTER              : status = true; break;
        case UTILS.KBD.KEY.F1                 : status = true; break;
        case UTILS.KBD.KEY.F5                 : status = true; break;
        case UTILS.KBD.KEY.F6                 : status = true; break;
        case UTILS.KBD.KEY.F11                : status = true; break;
        case UTILS.KBD.KEY.MEDIAPLAY          : status = true; break;
        case UTILS.KBD.KEY.MEDIATRACKNEXT     : status = true; break;
        case UTILS.KBD.KEY.MEDIATRACKPREVIOUS : status = true; break;
        case UTILS.KBD.KEY.PAGEDOWN           : status = true; break;
        case UTILS.KBD.KEY.PAGEUP             : status = true; break;
        case UTILS.KBD.KEY.TAB                : status = true; break;
        case UTILS.KBD.KEY.SHIFT              : status = true; break;
      // add cases to handle other command keys
      }

      return status;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandlePress (event=undefined) {
    /************************************************************************************
    * The function which handles command keys for the paper process 
    ************************************************************************************/
      let that = this;
      let Command = UTILS.Link (GetKeyFunction, [event.key, UTILS.PRESS], that);

      UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);
      UTILS.Link (Command, [event], that);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandleRelease (event=undefined) {
    /************************************************************************************
    * The function which handles release keys for the paper process 
    ************************************************************************************/
      let that    = this;
      let Command = UTILS.Link (GetKeyFunction, [event.key, UTILS.RELEASE], that);

      return UTILS.Link (Command, [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefineCommandKeyFunctions () {

      Action [UTILS.KBD.KEY.INTERNALCALL] = function () {
      /************************************************************************************
      * The function which performs arbitrary tasks wherever ...
      ************************************************************************************/
        let that = this;
        console.log ("[ internal call: ", FILE [0], " ]");
        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.ALT] = function (event=undefined) {
        let that = this;

        ALTDOWN = true;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.ALTGRAPH] = function (event=undefined) {
        let that = this;

        ALTGRAPHDOWN = true;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.ARROWLEFT] = function (event=undefined) {
      /************************************************************************************
      * The function which moves the cursor to the left
      ************************************************************************************/
        let that    = this;
        let ArrowUp = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWUP, UTILS.PRESS], that);
        let End     = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], that);

        if (CONTROLDOWN) {
          let LEFT = 0;

          if (CURSOR === 0) {
            let ArrowLeft      = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWLEFT, UTILS.PRESS], that);
            let PressControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], that);
            let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], that);

            UTILS.Link (ReleaseControl, _, that);
            UTILS.Link (ArrowLeft, _, that); 
            UTILS.Link (PressControl, _, that);
          }
          else {
            CURSOR = UTILS.Link (SkipWordMoveCursor, [LEFT], that);
            if (CURSOR < LINESTART) { LINESTART = CURSOR; }
          }
        }
        else {
          if (CURSOR > 0) {
            CURSOR = CURSOR - 1;
            if (CURSOR < LINESTART) { LINESTART = CURSOR; }
          }
          else {
            let scrollLockActive = SCROLLLOCK;
            let ScrollLock       = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, UTILS.RELEASE], that);

            if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }

            UTILS.Link (ArrowUp, _, that);

            if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }
          }
        }

        if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.ARROWUP] = function (event=undefined) {
      /************************************************************************************
      * The function which moves the cursor to the next line above 
      ************************************************************************************/
        let that = this;

        if (SCROLLLOCK && !CONTROLDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [event, "deltaY", -3]);
          UTILS.Link (MouseWheelScrollHandler, [event], that);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
        }
        else if (SHIFTDOWN && CONTROLDOWN) {
          let tmpline      = undefined;
          let currentline  = LINE;
          let previousline = currentline - 1;

          if (previousline >= 0) {
            tmpline = FILE [previousline];

            UTILS.Link (UTILS.MapKeyValue, [FILE, previousline, FILE [currentline]]);
            UTILS.Link (UTILS.MapKeyValue, [FILE, currentline, tmpline]);

            LINE = previousline;

            if (LINE < FILESEGBEGIN) { FILESEGBEGIN = LINE; }
          }
        }
        if (CONTROLDOWN && !SCROLLLOCK) {
          let PressControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], that);
          let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], that);

          UTILS.Link (UTILS.MapKeyValue, [event, "deltaY", -3]);
          UTILS.Link (ReleaseControl, _, that);
          UTILS.Link (MouseWheelScrollHandler, [event], that);
          UTILS.Link (PressControl, _, that);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

          if (LINE > (FILESEGBEGIN + FILESEGEND)) { LINE = FILESEGBEGIN + FILESEGEND; }
          if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }
          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          if (CURSOR < LINESTART) { LINESTART = CURSOR; }

          UTILS.Link (PersistClipboardCursor);
          UTILS.Link (PersistClipboardLine);
        }
        else {
          if (LINE > 0) {
            LINE = LINE - 1;
            CURSOR = FILE [LINE].length;
          }

          if (LINE < FILESEGBEGIN) { FILESEGBEGIN = LINE; }
          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          if (CURSOR < LINESTART) { LINESTART = CURSOR; }
          if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }
        }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.ARROWDOWN] = function (event=undefined) {
      /************************************************************************************
      * The function which moves the cursor to the next line below
      ************************************************************************************/
        let that = this;

        if (SCROLLLOCK && !CONTROLDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [event, "deltaY", 3]);
          UTILS.Link (MouseWheelScrollHandler, [event], that);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
        }
        else if (SHIFTDOWN && CONTROLDOWN) {
          let currentline = LINE;
          let nextline = currentline + 1;

          if (nextline < FILE.length) {
            let tmpline = FILE [nextline];

            UTILS.Link (UTILS.MapKeyValue, [FILE, nextline, FILE [currentline]]);
            UTILS.Link (UTILS.MapKeyValue, [FILE, currentline, tmpline]);

            LINE = nextline;

            if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
          }
        }
        if (CONTROLDOWN && !SCROLLLOCK) {
          let PressControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], that);
          let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], that);

          UTILS.Link (UTILS.MapKeyValue, [event, "deltaY", 3]);
          UTILS.Link (ReleaseControl, _, that);
          UTILS.Link (MouseWheelScrollHandler, [event], that);
          UTILS.Link (PressControl, _, that);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

          if (LINE < FILESEGBEGIN) { LINE = FILESEGBEGIN; }
          if (CURSOR > FILE [LINE].length) { CURSOR = FILE [LINE].length; }
          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          if (CURSOR < LINESTART) { LINESTART = CURSOR; }

          UTILS.Link (PersistClipboardCursor);
          UTILS.Link (PersistClipboardLine);
        }
        else {
          if ((LINE + 1) < FILE.length) {
            LINE = LINE + 1; 
            CURSOR = FILE [LINE].length;
          }

          if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          if (CURSOR < LINESTART) { LINESTART = CURSOR; }
          if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }
        }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.ARROWRIGHT] = function (event=undefined) {
      /************************************************************************************
      * The function which moves the cursor to the right 
      ************************************************************************************/
        let that      = this;
        let ArrowDown = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWDOWN, UTILS.PRESS], that);
        let Home      = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.HOME, UTILS.RELEASE], that);

        if (CONTROLDOWN) {
          let RIGHT = 1;

          if (CURSOR === FILE [LINE].length) {
            let ArrowRight     = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWRIGHT, UTILS.PRESS], that);
            let PressControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], that);
            let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], that);

            UTILS.Link (ReleaseControl, _, that);
            UTILS.Link (ArrowRight, _, that);
            UTILS.Link (PressControl, _, that);
          }
          else {
            CURSOR = UTILS.Link (SkipWordMoveCursor, [RIGHT], that);
            if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          }
        }
        else {
          if (CURSOR < FILE [LINE].length) {
            CURSOR = CURSOR + 1;
            if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          }
          else {
            let scrollLockActive = SCROLLLOCK;
            let ScrollLock       = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, UTILS.RELEASE], that);

            if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }

            UTILS.Link (ArrowDown, _, that);

            if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }

            UTILS.Link (Home, _, that);
          }
        }

        if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.BACKSPACE] = function (event=undefined) {
        let that = this;

        if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }
        else if (SHIFTDOWN) {
          let Backspace    = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, UTILS.PRESS], that);
          let DeleteLine   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.F9, UTILS.RELEASE], that);
          let PressShift   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.PRESS], that);
          let ReleaseShift = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.RELEASE], that);

          UTILS.Link (ReleaseShift, _, that);
          UTILS.Link (DeleteLine, _, that);
          UTILS.Link (Backspace, _, that);
          UTILS.Link (PersistClipboardCursor);
          UTILS.Link (PersistClipboardLine);
          UTILS.Link (PressShift, _, that);
        }
        else {
          let line = FILE [LINE];
          let leftbit = undefined;
          let midbit = undefined;
          let rightbit = undefined;

          if (CURSOR > 0) {
            line = FILE [LINE].substring (0, CURSOR - 1);
            line = line + FILE [LINE].substring (CURSOR, FILE [LINE].length);
            CURSOR = CURSOR - 1;

            UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, line]);

            if (CURSOR < LINESTART) { LINESTART = CURSOR; }
          }
          else if (LINE > 0) {

            if ((FILE.length) >= VIEWCAPACITY) {
              if (FILESEGBEGIN > 0) { FILESEGBEGIN = FILESEGBEGIN - 1; }
            }
            else if (FILESEGBEGIN == 0) { FILESEGEND = FILESEGEND - 1; }

            leftbit = FILE.splice (0, LINE);
            midbit = FILE.splice (0,1);
            rightbit = FILE.splice (0);
            FILE = leftbit.concat (rightbit);
            LINE = LINE - 1;
            CURSOR = FILE [LINE].length;

            UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, FILE [LINE] + midbit]);

            if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          }
        }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.CONTEXTMENU] = function (event=undefined) {
        let that = this;

        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", false]);

        return undefined;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.CONTROL] = function (event=undefined) {
        let that = this;

        CONTROLDOWN = true;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.DELETE] = function (event=undefined) {
      /************************************************************************************
      * The function which removes one character to the right of the cursor
      ************************************************************************************/
        let that = this;
        let line = FILE [LINE];

        if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }
        else if (CURSOR < line.length) {
          line = FILE [LINE].substring (0, CURSOR);
          line = line + FILE [LINE].substring (CURSOR + 1, FILE [LINE].length);

          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, line]);

          if (CURSOR > FILE [LINE].length) { CURSOR -= 1; }
        }
        else if ((LINE + 1) < FILE.length) {
          let shiftKeyDown     = SHIFTDOWN;
          let scrollLockActive = SCROLLLOCK;
          let ScrollLock       = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SCROLLLOCK, UTILS.RELEASE], that);
          let ArrowDown        = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ARROWDOWN, UTILS.PRESS], that);
          let Backspace        = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, UTILS.PRESS], that);
          let Home             = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.HOME, UTILS.RELEASE], that);
          let ReleaseShift     = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.RELEASE], that);
          let PressShift       = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.PRESS], that);

          if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }
          if (shiftKeyDown) { UTILS.Link (ReleaseShift, _, that); }

          UTILS.Link (ArrowDown, _, that);

          if (scrollLockActive) { UTILS.Link (ScrollLock, _, that); }

          UTILS.Link (Home, _, that);
          UTILS.Link (PersistClipboardCursor);
          UTILS.Link (PersistClipboardLine);
          UTILS.Link (Backspace, _, that);

          if (shiftKeyDown) { UTILS.Link (PressShift, _, that); }
        }

        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.ENTER] = function () {
      /************************************************************************************
      * The function which moves the cursor to the next line
      ************************************************************************************/
        let that         = this;
        let leftbit      = undefined;
        let rightbit     = undefined;
        let leftsubline  = undefined;
        let rightsubline = undefined;
        let START        = 0;

        if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }

        leftbit  = FILE.splice (START, LINE);
        rightbit = FILE.splice (START);

        leftbit.push (UTILS.BLANKCHAR);

        leftsubline                  = rightbit [START].substring (START, CURSOR);
        rightsubline                 = rightbit [START].substring (CURSOR, rightbit [START].length);
        leftbit [leftbit.length - 1] = leftsubline;
        rightbit [START]             = rightsubline;
        FILE                         = leftbit.concat (rightbit);
        CURSOR                       = START;
        LINESTART                    = CURSOR;
        LINE                         = LINE + 1;

        if (FILE.length < VIEWCAPACITY) { FILESEGEND = FILESEGEND + 1; }
        else if (LINE > FILESEGEND) { FILESEGBEGIN = FILESEGBEGIN + 1; }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.F1] = function () {
      /************************************************************************************
      * The function which displays the help text for the paper process
      ************************************************************************************/
        let that     = this;
        let helper   = EXPLAIN + that.id;
        let NOTFOUND = -1;

        if (that.id.indexOf (EXPLAIN) === NOTFOUND) {
          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, FILE [LINE] + helper]);
        }

        CURSOR = FILE [LINE].length;

        UTILS.Link (PersistFile);
        UTILS.Link (PersistFileLine);
        UTILS.Link (PersistFileCursor);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.F11] = function () {
      /************************************************************************************
      * The function which requests maximum screen for the paper process
      ************************************************************************************/
        let that = this;
        UTILS.Link (CalculateViewCapacity);
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.TAB] = function (event=undefined) {
      /************************************************************************************
      * The function which adds a tab-equivalent-of-spaces to the current line
      ************************************************************************************/
        let that = this;
        let fakeEvent = Object.create (_);

        if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }

        UTILS.Link (UTILS.MapKeyValue, [fakeEvent, "key", UTILS.KBD.KEY.WHITESPACE]);

        for (let i = 0; i < TABSIZE; i ++) {
          UTILS.Link (PersistClipboardLine);
          UTILS.Link (PersistClipboardCursor)
          UTILS.Link (HandlePrint, [fakeEvent], that);
        }

        UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
        UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.PAGEDOWN] = function (event=undefined) {
      /************************************************************************************
      * The function which increases the length of the kanvas
      ************************************************************************************/
        let that = this;

        if (ALTDOWN) { UTILS.Link (PAINTER.ChangeCanvasHeightBy, [2]); }
        else if (CONTROLDOWN) { UTILS.Link (PAINTER.HideCanvas); }
        else {
          let nextPage = (2 * VIEWCAPACITY) + 1;
          let i = undefined;

          UTILS.Link (JustifyViewport);

          for (i = 0; (i < nextPage) && (FILESEGBEGIN + 1 + FILESEGEND < FILE.length); i ++) {
            FILESEGBEGIN = FILESEGBEGIN + 1;
            LINE = LINE + 1;
          }

          if (i < nextPage) { LINE = FILESEGBEGIN + FILESEGEND; }

          if (CURSOR > FILE [LINE].length) {
            CURSOR = FILE [LINE].length;
            if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          }
          if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
        }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.PAGEUP] = function (event=undefined) {
      /************************************************************************************
      * The function which increases the length of the kanvas
      ************************************************************************************/
        let that = this;

        if (ALTDOWN) { UTILS.Link (PAINTER.ChangeCanvasHeightBy, [-2]); }
        else if (CONTROLDOWN) { UTILS.Link (PAINTER.ShowCanvas); }
        else {
          let nextPage = (2 * VIEWCAPACITY) + 1;
          let i = undefined;

          UTILS.Link (JustifyViewport);

          for (i = 0; (i < nextPage) && (FILESEGBEGIN > 0); i ++) {
            FILESEGBEGIN = FILESEGBEGIN - 1;
            LINE = LINE - 1;
          }

          if (i < nextPage) { LINE = FILESEGBEGIN; }

          if (CURSOR > FILE [LINE].length) {
            CURSOR = FILE [LINE].length;
            if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          }
          if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
        }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Action [UTILS.KBD.KEY.SHIFT] = function (event=undefined) {
        let that = this;

        SHIFTDOWN = true;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.OS] = function () {
      /************************************************************************************
      * The function which ...
      ************************************************************************************/
        let that = this;

        UTILS.Link (FILEMANAGER.Read, [PROGRAMS], that);
        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.ALT] = function (event) {
        let that = this;

        ALTDOWN = false;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.ALTGRAPH] = function (event) {
        let that = this;

        ALTGRAPHDOWN = false;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.CONTROL] = function (event) {
        let that = this;

        CONTROLDOWN = false;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.END] = function (event=undefined) {
      /************************************************************************************
      * The function which moves the cursor to the end of the line
      ************************************************************************************/
        let that = this;

        if (CONTROLDOWN) {
          LINE = FILE.length - 1;

          if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
        }

        CURSOR = FILE [LINE].length;

        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.ESCAPE] = EXIT;

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.F2] = function () {
        let that           = this;
        let filename       = UTILS.Link (FILEMANAGER.GetFileName);
        let End            = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], that);
        let Enter          = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ENTER, UTILS.PRESS], that);
        let PressControl   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], that);
        let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], that);
        let ctrlKeyDown    = UTILS.Link (GetControlState);

        if (!ctrlKeyDown) { UTILS.Link (PressControl, _, that); }

        UTILS.Link (End, _, that);

        if (!ctrlKeyDown) { UTILS.Link (ReleaseControl, _, that); }

        UTILS.Link (Enter, _, that);
        UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, filename]);
        UTILS.Link (End, _, that);

        if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
        else { LINESTART = 0; }

        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);
        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", true]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.F8] = function (event = undefined) {
        let that = this;

        if (CONTROLDOWN) {
          let End   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], that);
          let Enter = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ENTER, UTILS.PRESS], that);

          UTILS.Link (End, _, that);
          UTILS.Link (Enter, _, that);
          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, UTILS.WIN.SYS.location.href]);

          CURSOR = FILE [LINE].length;

          if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }
          else { LINESTART = 0; }

          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);
        }
        else {
          let url     = undefined;
          let urlline = FILE [FILE.length - 1].trim ();

          urlline = urlline.split (UTILS.KBD.KEY.WHITESPACE);
          urlline = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, urlline]);
          urlline = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, urlline]);
          url     = urlline [0];

          UTILS.WIN.SYS.location.assign (url);
        }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.F9] = function () {
        let that = this;

        if  (CONTROLDOWN) {
          let index = FILE.length - 1;
          let lineheight = FILE [index].trim ();

          lineheight = UTILS.Link (UTILS.ToNumber, [undefined, lineheight]);

          UTILS.Link (SetLineHeight, [lineheight]);
//          UTILS.Link (CalculateViewCapacity);
        }
        else {
          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, UTILS.BLANKCHAR]);

          CURSOR = 0;
          LINESTART = 0;
        }

        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.F10] = function () {
        let that = this;

        if (CONTROLDOWN && SHIFTDOWN) {
          let index = FILE.length - 1;
          let font = FILE [index].trim ();
          UTILS.Link (SetFont, [font]);
        }
        else if (ALTDOWN) {
          let fgcolor = UTILS.Link (GetFirstWordOnLastLine);
          UTILS.Link (SetFgColor, [fgcolor]);
        }
        else if (CONTROLDOWN) {
          let bgcolor = UTILS.Link (GetFirstWordOnLastLine);
          UTILS.Link (SetBgColor, [bgcolor]);
        }
        else {
          CURSOR = 0;
          LINE = 0;
          FILESEGEND = 0;
          FILE = new Array (UTILS.BLANKCHAR);
        }

        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);
        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function GetFirstWordOnLastLine () {
        let index = FILE.length - 1;
        let text = FILE [index].split (UTILS.KBD.KEY.WHITESPACE);

        text = UTILS.Link (UTILS.Filter, [UTILS.BLANKCHAR, text]);
        text = UTILS.Link (UTILS.Filter, [UTILS.KBD.KEY.WHITESPACE, text]);
        text = text [0];

        return text;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.HOME] = function (event=undefined) {
      /************************************************************************************
      * The function which moves the cursor to the beginning of the line
      ************************************************************************************/
        let that = this;

        if (CONTROLDOWN) {
          LINE = 0;
          FILESEGBEGIN = 0;
        }

        CURSOR = 0;

        if (CURSOR < LINESTART) { LINESTART = CURSOR; }
        if (SHIFTDOWN) { UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]); }

        UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.INSERT] = function (event=undefined) {
        let that = this;

        if (!CONTROLDOWN) { INSERT = !INSERT; }
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.SHIFT] = function (event) {
        let that = this;

        SHIFTDOWN = false;
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Release [UTILS.KBD.KEY.SCROLLLOCK] = function (event=undefined) {
        let that = this;

        if (!CONTROLDOWN) { SCROLLLOCK = !SCROLLLOCK; }
        UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function HandlePrint (event=undefined) {
    /************************************************************************************
    * The function which handles printable character keys for the paper process 
    ************************************************************************************/
      let that = this;
      let PrintKey = UTILS.Link (GetKeyFunction, [event.key], that);

      UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", true]);

      return UTILS.Link (PrintKey, [event], that);
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

   function PrintCharacter (key=undefined) {
      let that          = this;
      let currentline   = undefined;
      let endOfThisLine = undefined;
      let subline       = undefined;

      if (INSERT && (CURSOR < FILE [LINE].length)) {
        let Delete = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.DELETE, UTILS.PRESS], that);
        UTILS.Link (Delete, _, that);
      }
      else if (UTILS.Link (TextSelected)) { UTILS.Link (DeleteSelectionFromFile); }

      currentline = FILE [LINE];
      endOfThisLine = currentline.length;
      subline = currentline.substring (0, CURSOR);

      UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, subline + key]);

      subline = currentline.substring (CURSOR, endOfThisLine);

      UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, FILE [LINE] + subline]);

      CURSOR = CURSOR + key.length;

      if (CURSOR > (LINESTART + LINESTOP)) { LINESTART = CURSOR - LINESTOP; }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function DefinePrintKeyFunctions () {

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      let startPrintKeys = 32;
      let stopPrintKeys  = 126;

      UTILS.Link (GenerateKeyFunctions, [startPrintKeys, stopPrintKeys, PrintKey], Printable);

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function PrintKey (event) {
        let that = this;
        UTILS.Link (PrintCharacter, [event.key], that);
        return undefined;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.MINUS_SIGN] = function (event) {
        let that      = this;
        let deltaSize = -1;

        if (CONTROLDOWN) {
          UTILS.Link (UpdateFontSize, [deltaSize], that);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.PLUS_SIGN] = function (event) {
        let that      = this;
        let deltaSize = 1;

        if (CONTROLDOWN) {
          UTILS.Link (UpdateFontSize, [deltaSize], that);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.UPPERCASE_C] = function (event) {
        let that = this;

        if (CONTROLDOWN) {
          let inClipbardText= undefined;
          let updateExClipboard = undefined;

          UTILS.Link (CopyTextToClipboard);

          inClipbardText = UTILS.Link (CLIPBOARD.GetText);
          inClipbardText = inClipbardText.join (UTILS.NEWLINECHAR);
          updateExClipboard = navigator.clipboard.writeText (inClipbardText);

          UTILS.Link (updateExClipboard.then, [ReportUpdateSuccess], updateExClipboard);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function ReportUpdateSuccess (evt=undefined) {
        let that = this;
        console.log ("External clipboard updated sucessfully!");
        return undefined;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function CopyTextToClipboard () {
        let that = this;
        let fromLine = UTILS.Link (CLIPBOARD.GetLine);
        let toLine = fromLine + 1;
        let fromCursor = UTILS.Link (CLIPBOARD.GetCursor);
        let toCursor = fromCursor;
        let clippedText = undefined;
        let clippedLine = undefined;

        if (fromLine < LINE) {
          toLine = LINE + 1;
          toCursor = CURSOR;
        }
        else if (fromLine > LINE) {
          fromLine = LINE;
          fromCursor = CURSOR;
        }

        if ((fromLine + 1) === toLine) {
          toCursor = CURSOR;

          if (fromCursor > toCursor) {
            fromCursor = fromCursor + toCursor;
            toCursor = fromCursor - toCursor;
            fromCursor = fromCursor - toCursor;
          }

          clippedText = FILE.slice (fromLine, toLine);
          fromLine = clippedText [0];
          clippedLine = fromLine.substring (fromCursor, toCursor);

          UTILS.Link (UTILS.MapKeyValue, [clippedText, 0, clippedLine]);
        }
        else {
          clippedText = FILE.slice (fromLine, toLine);
          fromLine = clippedText [0];
          clippedLine = fromLine.substring (fromCursor, fromLine.length);

          UTILS.Link (UTILS.MapKeyValue, [clippedText, 0, clippedLine]);

          toLine = clippedText [clippedText.length - 1];
          clippedLine = toLine.substring (0, toCursor);
          toCursor = clippedText.length - 1;

          UTILS.Link (UTILS.MapKeyValue, [clippedText, toCursor, clippedLine]);
        }

        UTILS.Link (CLIPBOARD.SetText, [clippedText]);

        return undefined;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.LOWERCASE_C] = function (event) {
        let that = this;

        if (CONTROLDOWN) {
          UTILS.Link (CopyTextToClipboard);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.UPPERCASE_F] = function (event) {
        let that = this;

        if (CONTROLDOWN) { UTILS.Link (SearchFile, [-1], that); }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function SearchFile (direction=undefined) {
        let that = this;
        let filesize = FILE.length;
        let keyword = FILE [filesize - 1];
        let initCursor = CURSOR;
        let initLine = LINE;
        let currentCursor = initCursor;
        let currentLine = initLine;
        let EOF = undefined;
        let delta = undefined;

        if (direction < 0) {
          EOF = -1;
          delta = -1;
        }
        else if (direction > 0) {
          EOF = filesize;
          delta = 1;
        }

        UTILS.Link (SearchLine, [keyword, currentLine, currentCursor, initLine], that);

        if ((LINE === initLine) && (CURSOR === initCursor)) {

          currentLine = initLine + delta;
          currentCursor = 0;

          while (currentLine !== initLine) {
            if (currentLine === EOF) { 
              if (direction < 0) { currentLine = filesize - 1; }
              else if (direction > 0) { currentLine = 0; }
            }

            currentLine = UTILS.Link (SearchLine, [keyword, currentLine, currentCursor, initLine], that);

            if (currentLine !== initLine) {
              currentCursor = 0;
              currentLine = currentLine + delta;
            }
          }
        }

        return undefined;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function SearchLine (keyword=undefined, linenumber=undefined, cursorPosition=undefined, eoc=undefined) {
        let that        = this;
        let sentence    = FILE [linenumber];
        let k           = keyword.length;
        let textSegment = undefined;

        for (let j = cursorPosition; (sentence.length >= k) && (j + k <= sentence.length); j ++) {
          textSegment = sentence.substring (j, j + k);

          if (keyword === textSegment) {
            LINE       = linenumber;
            CURSOR     = j + k;
            j          = sentence.length;
            linenumber = eoc;
          }
        }

        return linenumber;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.LOWERCASE_F] = function (event) {
        let that = this;

        if (CONTROLDOWN) { UTILS.Link (SearchFile, [1], that); }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.UPPERCASE_I] = function (event) {
        let that = this;

        if (CONTROLDOWN && SHIFTDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.LOWERCASE_I] = function (event) {
        let that = this;

        if (CONTROLDOWN && SHIFTDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.UPPERCASE_K] = function (event=undefined) {
        let that = this;

        if (CONTROLDOWN && (!SHIFTDOWN)) {
          let currententry = FILE [LINE];
          let End = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], that);
          let Enter = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.ENTER, UTILS.PRESS], that);
          let PressControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.PRESS], that);
          let ReleaseControl = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.CONTROL, UTILS.RELEASE], that);
          let ctrlKeyDown = UTILS.Link (GetControlState);

          if (!ctrlKeyDown) { UTILS.Link (PressControl, _, that); }

          UTILS.Link (End, _, that);

          if (!ctrlKeyDown) { UTILS.Link (ReleaseControl, _, that); }

          UTILS.Link (Enter, _, that);
          UTILS.Link (UTILS.MapKeyValue, [FILE, LINE, currententry])
          UTILS.Link (End, _, that);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", true]);
        }
        else if (CONTROLDOWN && SHIFTDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.LOWERCASE_K] = function (event=undefined) {
        let that = this;
        let UppercaseK = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.UPPERCASE_K], that);

        UTILS.Link (UppercaseK, [event], that);
      
        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.UPPERCASE_O] = function (event) {
        let that = this;

        if (CONTROLDOWN) {
          let lastline = FILE.length - 1;
          let filename = FILE [lastline].trim ();
          UTILS.Link (FILEMANAGER.Read, [filename], that);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.LOWERCASE_O] = function (event) {
        let that = this;

        if (CONTROLDOWN) {
          let lastline = FILE.length - 1;
          let filename = FILE [lastline].trim ();
          UTILS.Link (FILEMANAGER.Read, [filename], that);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.UPPERCASE_P] = function (event) {
        let that = this;
  
        if (CONTROLDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.LOWERCASE_P] = function (event) {
        let that = this;

        if (CONTROLDOWN) {
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "justifyViewport", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
          UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.UPPERCASE_S] = function (event) {
        let that = this;

        if (CONTROLDOWN) {
          let ctrlKeyDown  = CONTROLDOWN;
          let shiftKeyDown = SHIFTDOWN;
          let newfile      = FILE [FILE.length - 1].trim ();
          let Backspace    = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.BACKSPACE, UTILS.PRESS], that);
          let End          = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.END, UTILS.RELEASE], that);
          let PressShift   = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.PRESS], that);
          let ReleaseShift = UTILS.Link (GetKeyFunction, [UTILS.KBD.KEY.SHIFT, UTILS.RELEASE], that);

          UTILS.Link (End, _, that);
          UTILS.Link (PersistClipboardCursor);
          UTILS.Link (PersistClipboardLine);

          if (!shiftKeyDown) { UTILS.Link (PressShift, _, that); }

          UTILS.Link (Backspace, _, that);

          if (!shiftKeyDown) { UTILS.Link (ReleaseShift, _, that); }

          UTILS.Link (PersistFile);
          UTILS.Link (PersistFileLine);
          UTILS.Link (PersistFileCursor);
          UTILS.Link (FILEMANAGER.Write, [newfile], that);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.LOWERCASE_S] = function (event) {
        let that = this;

        if (CONTROLDOWN) {
          UTILS.Link (FILEMANAGER.Write, _, that);
          UTILS.Link (UTILS.MapKeyValue, [that, "editing", false]);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.UPPERCASE_V] = function (event) {
        let that = this;

        if (CONTROLDOWN) { UTILS.Link (PasteTextFromClipboard); }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      function PasteTextFromClipboard () {
        let that = this;
        let preCut = FILE.slice (0, LINE + 1);
        let postCut = FILE.slice (LINE, FILE.length);
        let clippedText = UTILS.Link (CLIPBOARD.GetText);
        let splitLine = preCut [LINE];

        if (clippedText.length === 1) {
          splitLine = splitLine.substring (0, CURSOR);
          splitLine = splitLine + clippedText [0];
          clippedText = postCut [0];
          clippedText = clippedText.substring (CURSOR, clippedText.length);
          CURSOR = splitLine.length;
          splitLine = splitLine + clippedText;

          preCut.pop ();

          preCut = preCut.concat (postCut);

          UTILS.Link (UTILS.MapKeyValue, [preCut, LINE, splitLine]);

          FILE = preCut;
        }
        else {
          splitLine = splitLine.substring (0, CURSOR);
          splitLine = splitLine + clippedText [0];
          UTILS.Link (UTILS.MapKeyValue, [preCut, LINE, splitLine]);

          splitLine = postCut [0];
          splitLine = splitLine.substring (CURSOR, splitLine.length);
          CURSOR = clippedText.length - 1;
          splitLine = clippedText [CURSOR] + splitLine;
          UTILS.Link (UTILS.MapKeyValue, [postCut, 0, splitLine]);

          CURSOR = clippedText [CURSOR].length;
          LINE = (LINE + clippedText.length) - 1;
          clippedText = clippedText.slice (1, clippedText.length - 1);
          clippedText = preCut.concat (clippedText);
          FILE = clippedText.concat (postCut);

        /*
          account for file lengths exceeding view capacity and file lengths within view capacity
        */
          if (FILE.length < VIEWCAPACITY) { FILESEGBEGIN = 0; FILESEGEND = FILE.length - 1; }
          else {
            FILESEGEND = VIEWCAPACITY - 1;

            if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
          }
        }

        return undefined;
      }

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.LOWERCASE_V] = function (event) {
        let that = this;

        if (CONTROLDOWN) { UTILS.Link (PasteTextFromClipboard); }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.UPPERCASE_X] = function (event) {
        let that = this;

        if (CONTROLDOWN) {
          let inClipbardText= undefined;
          let updateExClipboard = undefined;

          UTILS.Link (CopyTextToClipboard);
          UTILS.Link (DeleteSelectionFromFile);

          inClipbardText = UTILS.Link (CLIPBOARD.GetText);
          inClipbardText = inClipbardText.join (UTILS.NEWLINECHAR);
          updateExClipboard = navigator.clipboard.writeText (inClipbardText);

          UTILS.Link (updateExClipboard.then, [ReportUpdateSuccess], updateExClipboard);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      Printable [UTILS.KBD.KEY.LOWERCASE_X] = function (event) {
        let that = this;

        if (CONTROLDOWN) {
          UTILS.Link (CopyTextToClipboard);
          UTILS.Link (DeleteSelectionFromFile);
        }
        else { UTILS.Link (PrintCharacter, [event.key], that); }

        return undefined;
      };

    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/
    /********************************************************************************************************************/

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  /************************************************************************************
  * Define event handlers below
  ************************************************************************************/

    function KeydownHandler (event=undefined) {
      let that = this;

      UTILS.Link (UTILS.MapKeyValue, [that, "editing", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
      UTILS.Link (RetrieveFile);
      UTILS.Link (RetrieveFileLine);
      UTILS.Link (RetrieveFileCursor);
      UTILS.Link (RetrieveViewportStart);
      UTILS.Link (RetrieveViewportLength);
      UTILS.Link (RetrieveViewportLineStart);

      if (UTILS.Link (InvisibleCharacter, [event.key], _)) {
        if (UTILS.Link (CommandCharacter, [event.key], _)) {
          UTILS.Link (HandlePress, [event], that);
        }
      }
      else { UTILS.Link (HandlePrint, [event], that); }
      if (that.justifyViewport) { UTILS.Link (JustifyViewport); }

      UTILS.Link (PersistViewportStart);
      UTILS.Link (PersistViewportLength);
      UTILS.Link (PersistViewportLineStart);

      if (that.editing) {
//        console.log ("update clipboard: [", LINE, CURSOR,"]");
        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);
      }
      if (that.requireRewrite) { UTILS.Link (ReWrite, _, that); }
      if (that.preventDefault) { UTILS.Link (event.preventDefault, _, event); }
      if (that.stopPropagation) { UTILS.Link (event.stopPropagation, _, event); }

      UTILS.Link (PersistFile);
      UTILS.Link (PersistFileLine);
      UTILS.Link (PersistFileCursor);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function KeyupHandler (event=undefined) {
      let that = this;
      let executableCommand = false;

      UTILS.Link (UTILS.MapKeyValue, [that, "preventDefault", true]);
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", false]);
      UTILS.Link (UTILS.MapKeyValue, [that, "stopPropagation", true]);
      UTILS.Link (RetrieveFile);
      UTILS.Link (RetrieveFileLine);
      UTILS.Link (RetrieveFileCursor);
      UTILS.Link (RetrieveViewportStart);
      UTILS.Link (RetrieveViewportLength);
      UTILS.Link (RetrieveViewportLineStart);

      switch (event.key) {
        case UTILS.KBD.KEY.ALT       : executableCommand = true; break;
        case UTILS.KBD.KEY.ALTGRAPH  : executableCommand = true; break;
        case UTILS.KBD.KEY.CONTROL   : executableCommand = true; break;
        case UTILS.KBD.KEY.END       : executableCommand = true; break;
        case UTILS.KBD.KEY.ESCAPE    : executableCommand = true; break;
        case UTILS.KBD.KEY.F2        : executableCommand = true; break;
        case UTILS.KBD.KEY.F8        : executableCommand = true; break;
        case UTILS.KBD.KEY.F9        : executableCommand = true; break;
        case UTILS.KBD.KEY.F10       : executableCommand = true; break;
        case UTILS.KBD.KEY.HOME      : executableCommand = true; break;
        case UTILS.KBD.KEY.INSERT    : executableCommand = true; break;
        case UTILS.KBD.KEY.OS        : executableCommand = true; break;
        case UTILS.KBD.KEY.SHIFT     : executableCommand = true; break;
        case UTILS.KBD.KEY.SCROLLLOCK: executableCommand = true; break;
      }

      if (executableCommand) { UTILS.Link (HandleRelease, [event], that); }
      if (that.justifyViewport) { UTILS.Link (JustifyViewport); }

      UTILS.Link (PersistViewportStart);
      UTILS.Link (PersistViewportLength);
      UTILS.Link (PersistViewportLineStart);

      if (that.editing) {
//        console.log ("update clipboard: [", LINE, CURSOR,"]");
        UTILS.Link (PersistClipboardCursor);
        UTILS.Link (PersistClipboardLine);
      }
      if (that.requireRewrite) { UTILS.Link (ReWrite, _, that); }
      if (that.preventDefault) { UTILS.Link (event.preventDefault, _, event); }
      if (that.stopPropagation) { UTILS.Link (event.stopPropagation, _, event); }

      UTILS.Link (PersistFile);
      UTILS.Link (PersistFileLine);
      UTILS.Link (PersistFileCursor);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ResizeHandler (event) {
      let that = this;

      UTILS.Link (PAINTER.SetCanvasHeightTo, [UTILS.WIN.SYS.innerHeight - 20]);
      UTILS.Link (PAINTER.SetCanvasWidthTo, [UTILS.WIN.SYS.innerWidth - 20]);

      RMARGIN = UTILS.Link (PAINTER.GetCanvasWidth) - 10*LMARGIN;

      UTILS.Link (VIEWPORT.SetRightMargin, [RMARGIN]);
      UTILS.Link (ReWrite, _, that);
    }


  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function LaunchFullscreen () {
      let that    = this;
      let element = UTILS.WIN.DOC.documentElement;

      if (element.requestFullscreen      ) { element.requestFullscreen      (); } else
      if (element.mozRequestFullScreen   ) { element.mozRequestFullScreen   (); } else
      if (element.webkitRequestFullscreen) { element.webkitRequestFullscreen(); } else
      if (element.msRequestFullscreen    ) { element.msRequestFullscreen    (); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function ExitFullscreen () {
      let that = this;

      if (UTILS.WIN.DOC.exitFullscreen      ) { UTILS.WIN.DOC.exitFullscreen      (); } else
      if (UTILS.WIN.DOC.mozCancelFullScreen ) { UTILS.WIN.DOC.mozCancelFullScreen (); } else
      if (UTILS.WIN.DOC.webkitExitFullscreen) { UTILS.WIN.DOC.webkitExitFullscreen(); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function MouseWheelScrollHandler (event=undefined) {
      let that         = this;
      let SCROLLAMOUNT = 3;
      let deltaSize    = -event.deltaY;

      //if (SCROLLLOCK && !CONTROLDOWN) { SCROLLAMOUNT = 1; }
      if (CONTROLDOWN) { UTILS.Link (UpdateFontSize, [deltaSize], that); }
      else if (FILE.length >= VIEWCAPACITY) {
        if (deltaSize < 0) {
          for (let o = 0; (o < SCROLLAMOUNT); o ++) {
            if ((FILESEGBEGIN + 1 + FILESEGEND) < FILE.length) {
              FILESEGBEGIN = FILESEGBEGIN + 1;
            }
          }
        }
        else {
          for (let o = 0; (o < SCROLLAMOUNT); o ++) {
            if (FILESEGBEGIN > 0) { FILESEGBEGIN = FILESEGBEGIN - 1; }
          }
        }
      }
      if (that.requireRewrite) { UTILS.Link (ReWrite, _, that); }

      UTILS.Link (event.preventDefault, _, event);
      UTILS.Link (event.stopPropagation, _, event );
      UTILS.Link (UTILS.MapKeyValue, [that, "requireRewrite", true]);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UpdateFontSize (amount=undefined) {
      let that      = this;
      let fontUnits = UTILS.BLANKCHAR;
      let fontArray = FONT.split (UTILS.KBD.KEY.WHITESPACE);
      let fontSize  = fontArray [0].split (UTILS.BLANKCHAR);
      let deltaSize = amount / amount;
      let tmpFont   = undefined;

      fontUnits = fontSize.pop () + fontUnits;
      fontUnits = fontSize.pop () + fontUnits;
      fontSize  = fontSize.join (UTILS.BLANKCHAR);
      fontSize  = UTILS.Link (UTILS.ToNumber, [undefined, fontSize]);

      if (amount < 0) { deltaSize = -1 * deltaSize; }

      fontSize   = fontSize + deltaSize;
      tmpFont    = fontSize + fontUnits + UTILS.KBD.KEY.WHITESPACE + fontArray [1];

      UTILS.Link (SetLineHeight, [LINEHEIGHT + deltaSize]);
      UTILS.Link (SetFont, [tmpFont]);
      UTILS.Link (CalculateViewCapacity);//console.log (VIEWCAPACITY, LINEHEIGHT);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function JustifyViewport () {
      let that = this;

      if (LINE > (FILESEGBEGIN + FILESEGEND)) { FILESEGBEGIN = LINE - FILESEGEND; }
      if (LINE < FILESEGBEGIN) { FILESEGBEGIN = LINE; }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetBgColor (color=undefined) {
      let that = this;
      BGCOLOR = color;
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetFgColor (color=undefined) {
      let that = this;
      FGCOLOR = color;
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetFont (font=undefined) {
      let that = this;
      FONT = font;
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetKeyFunction (key=undefined, keyHandler=undefined, index=undefined) {
      let that = this;

      if (UTILS.Link (InvisibleCharacter, [key])) {
        if (index === UTILS.RELEASE) {
          UTILS.Link (UTILS.MapKeyValue, [that.Release, key, keyHandler]);
        }
        else if (index === UTILS.PRESS) {
          UTILS.Link (UTILS.MapKeyValue, [that.Action, key, keyHandler]);
        }
      }
      else { UTILS.Link (UTILS.MapKeyValue, [that.Printable, key, keyHandler]); }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function SetLineHeight (height=undefined) {
      let that = this;
      LINEHEIGHT = height;
      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetAltState () { return ALTDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetAltGraphState () { return ALTGRAPHDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetControlState () { return CONTROLDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetBgColor () { return BGCOLOR; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFgColor () { return FGCOLOR; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetFont () { return FONT; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetKeyFunction (key=undefined, index=undefined) {
      let that       = this;
      let keyHandler = undefined;

      if (UTILS.Link (InvisibleCharacter, [key])) {
        if (index === UTILS.RELEASE) { keyHandler = that.Release [key]; }
        else if (index === UTILS.PRESS) { keyHandler = that.Action [key]; }
      }
      else { keyHandler = that.Printable [key]; }

      return keyHandler;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetLineHeight () { return LINEHEIGHT; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetScrollLockState () { return SCROLLLOCK; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GetShiftState () { return SHIFTDOWN; }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function CalculateViewCapacity () {
      let that = this;

      BMARGIN      = UTILS.Link (PAINTER.GetCanvasHeight) - 2 * LINEHEIGHT;
      VIEWCAPACITY = (BMARGIN - (BMARGIN % LINEHEIGHT)) / LINEHEIGHT;

      return undefined;
    }    

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFile () { UTILS.Link (FILEMANAGER.SetFile, [UTILS.WHOLE, FILE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFileCursor () { UTILS.Link (FILEMANAGER.SetFileCursor, [CURSOR]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistFileLine () { UTILS.Link (FILEMANAGER.SetFileLine, [LINE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistViewportStart () { UTILS.Link (VIEWPORT.SetSegmentBegin, [FILESEGBEGIN]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistViewportLength () { UTILS.Link (VIEWPORT.SetSegmentEnd, [FILESEGEND]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistViewportLineStart () { UTILS.Link (VIEWPORT.SetLineStart, [LINESTART]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistClipboardCursor () { UTILS.Link (CLIPBOARD.SetCursor, [CURSOR]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function PersistClipboardLine () { UTILS.Link (CLIPBOARD.SetLine, [LINE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFile () { FILE = UTILS.Link (FILEMANAGER.GetFile, [UTILS.WHOLE]); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFileCursor () { CURSOR = UTILS.Link (FILEMANAGER.GetFileCursor); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveFileLine () { LINE = UTILS.Link (FILEMANAGER.GetFileLine); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveViewportStart () { FILESEGBEGIN = UTILS.Link (VIEWPORT.GetSegmentBegin); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveViewportLength () { FILESEGEND = UTILS.Link (VIEWPORT.GetSegmentEnd); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function RetrieveViewportLineStart () { LINESTART = UTILS.Link (VIEWPORT.GetLineStart); }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function UpdateDocumentBgColor () {
      let that    = this;
      let html    = UTILS.Link (UTILS.WIN.DOC.querySelector, ["html"], UTILS.WIN.DOC);
      let center  = UTILS.Link (UTILS.WIN.DOC.querySelector, ["center"], UTILS.WIN.DOC);
      let head    = UTILS.Link (UTILS.WIN.DOC.querySelector, ["head"], UTILS.WIN.DOC);
      let body    = UTILS.Link (UTILS.WIN.DOC.querySelector, ["body"], UTILS.WIN.DOC);
      let bgcolor = "backgroundColor";

      UTILS.Link (UTILS.MapKeyValue, [COVER.style, bgcolor, BGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [html.style, bgcolor, BGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [center.style, bgcolor, BGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [head.style, bgcolor, BGCOLOR]);
      UTILS.Link (UTILS.MapKeyValue, [body.style, bgcolor, BGCOLOR]);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function GenerateKeyFunctions (from=undefined, to=undefined, fn=undefined) {
      let that = this;
      let key  = undefined;

      if (from !== undefined) {
        if (to === undefined) { to = from; }

        for (let i = from; i <= to; i ++) {
          key = UTILS.Link (UTILS.ToChar, [i]);
          UTILS.Link (UTILS.MapKeyValue, [that, key, fn]);
        }
      }

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Destroy () {
    /************************************************************************************
    * The function which destroys the paper process
    ************************************************************************************/
      let that = this;

      while (that.stack.size > 0) {
        UTILS.Link (STACK.Pop, _, that.stack);
        UTILS.Link (that.stack.popped.abort, _, that.stack.popped);
      }

      UTILS.Link (UpdateDocumentBgColor);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.KBD.KEY.DOWN, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.KBD.KEY.UP, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.WIN.RESIZE, UTILS.WIN.SYS], that.Action);
      UTILS.Link (UTILS.RemoveHandlerFor, [UTILS.MWS.WHEEL, UTILS.Link (PAINTER.GetCanvas)], that.Action);
      UTILS.Link (PAINTER.Destroy, _, that.painter);

      return undefined;
    }

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

    function Objectify () {
      let that = this;

      _             = null;
      Action        = Object.create (_);
      Printable     = Object.create (_);
      Release       = Object.create (_);
      ALTDOWN       = false;
      ALTGRAPHDOWN  = false;
      CONTROLDOWN   = false;
      EXPLAIN       = "explain";
      INSERT        = false;
      LINEHEIGHT    = 17;
      SCROLLLOCK    = false;
      SHIFTDOWN     = false;
      PROGRAMS      = "sys/doc/programs";
      TABSIZE       = 2;
      UTILS         = Utils;
      VIEWCAPACITY  = 0;
      VIEWPORT      = ViewPort;

      UTILS.Link (DefineCommandKeyFunctions);
      UTILS.Link (DefinePrintKeyFunctions);
      UTILS.Link (UTILS.MapKeyValue, [that, "Create", Create]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Action", Action]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Destroy", Destroy]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GenerateKeyFunctions", GenerateKeyFunctions]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistFile", PersistFile]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistFileCursor", PersistFileCursor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistFileLine", PersistFileLine]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistViewportStart", PersistViewportStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistViewportLength", PersistViewportLength]);
      UTILS.Link (UTILS.MapKeyValue, [that, "PersistViewportLineStart", PersistViewportLineStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Printable", Printable]);
      UTILS.Link (UTILS.MapKeyValue, [that, "Release", Release]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveFile", RetrieveFile]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveFileCursor", RetrieveFileCursor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveFileLine", RetrieveFileLine]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveViewportStart", RetrieveViewportStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveViewportLength", RetrieveViewportLength]);
      UTILS.Link (UTILS.MapKeyValue, [that, "RetrieveViewportLineStart", RetrieveViewportLineStart]);
      UTILS.Link (UTILS.MapKeyValue, [that, "JustifyViewport", JustifyViewport]);
      UTILS.Link (UTILS.MapKeyValue, [that, "ReWrite", ReWrite]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetBgColor", SetFgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetFgColor", SetFgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetFont", SetFont]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetKeyFunction", SetKeyFunction]);
      UTILS.Link (UTILS.MapKeyValue, [that, "SetLineHeight", SetLineHeight]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetAltState", GetAltState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetAltGraphState", GetAltGraphState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetControlState", GetControlState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetBgColor", GetBgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetFgColor", GetFgColor]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetFont", GetFont]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetKeyFunction", GetKeyFunction]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetLineHeight", GetLineHeight]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetScrollLockState", GetScrollLockState]);
      UTILS.Link (UTILS.MapKeyValue, [that, "GetShiftState", GetShiftState]);

      return Object.create (that);
    }

    return Utils.Link (Objectify, null, paper);

  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/
  /********************************************************************************************************************/

  }

  return utils.Link (MakePaperName, [utils, viewport], paperspace);
}